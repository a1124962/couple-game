/* Original cinematic portraits; kept separate from full-body action atlases. */
function heroPortrait(id,extra=''){
 const cls=['blade','weaver','warden','seer'].includes(id)?id:'blade';
 const name=typeof GD==='function'?GD().classes.find(c=>c.id===cls)?.name:cls;
 return `<span class="hero-portrait hero-portrait-${cls} ${extra}" role="img" aria-label="${esc(name||cls)}肖像"></span>`;
}
