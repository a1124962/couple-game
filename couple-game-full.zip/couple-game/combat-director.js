/* Authoritative combat presentation events; safe to serialize to the other player.
 * This layer never rolls the combat RNG or changes HP, energy, rewards or cooldowns. */
let battleCapture=null;
function battlePresentation(a){const c=a.combat;if(!c)return null;return c.presentation??={id:a.id+':'+a.stats.turns+':'+a.map.cur,seq:0,events:[],counts:{},transcript:[]};}
function battleIdentity(a,key){const p=a.players[key];return p?{name:p.name,id:p.cls,hero:true}:Object.assign({hero:false},a.combat.enemies.find(e=>e.uid===key));}
function battleLine(a,key,kind){const who=battleIdentity(a,key),cast=who.hero?COMBAT_CAST.heroes[who.id]:COMBAT_CAST.monsters[who.id],p=battlePresentation(a),lines=cast?.lines[kind]||[],counter=key+':'+kind;if(!lines.length)return '';const index=p.counts[counter]||0;p.counts[counter]=index+1;return lines[index%lines.length];}
function battleEmit(a,event){const p=battlePresentation(a);if(!p)return;event={...event,seq:++p.seq};p.events.push(event);p.events=p.events.slice(-64);if(event.line){const who=battleIdentity(a,event.speaker||event.actor);p.transcript.push({speaker:who.name||'骨城',text:event.line});p.transcript=p.transcript.slice(-40);}return event;}
function battleSay(a,actor,kind,type='say',extra={}){return battleEmit(a,{type,actor,line:battleLine(a,actor,kind),...extra});}
function battleEnemyAction(a,e,it,targets){if(!battleCapture)return;battleCapture.actor=e.uid;const attack=['attack','multi','debuff','special'].includes(it.type);battleSay(a,e.uid,attack?'attack':'guard',attack?'attack':'guard',{label:it.text,targets:targets.filter(Boolean),enemy:true});}
(function(){
const originalStart=combatStart,originalUse=combatUseSkill,originalEnd=combatEndTurn,originalDamage=damage;
combatStart=function(a,ids,tier){originalStart(a,ids,tier);battlePresentation(a);for(const e of a.combat.enemies)battleSay(a,e.uid,'enter');if(a.stats.kills%2===1){const pair=COMBAT_CAST.pairs[ROLES.map(r=>a.players[r].cls).sort().join(':')];for(const text of pair||[]){const [name,...rest]=text.split('：');const actor=ROLES.find(r=>COMBAT_CAST.heroes[a.players[r].cls].name===name);battleEmit(a,{type:'say',actor,line:rest.join('：')});}}else for(const r of ROLES)battleSay(a,r,'enter');};
damage=function(target,n){const before={hp:target.hp,block:target.block||0},dealt=originalDamage(target,n);if(battleCapture){const a=battleCapture.a,key=ROLES.find(r=>a.players[r]===target)||a.combat.enemies.find(e=>e===target)?.uid;if(key){const pres=battlePresentation(a),reaction=key+':reaction:'+a.combat.turn,react=dealt>0&&target.hp>0&&target.hp/target.maxhp>.3&&!pres.counts[reaction];if(react)pres.counts[reaction]=1;battleEmit(a,{line:react?battleLine(a,key,'hurt'):'',speaker:key,type:'hit',actor:battleCapture.actor,target:key,value:before.hp-target.hp,blocked:before.block-(target.block||0),dead:target.hp<=0});}}return dealt;};
function conclude(a,before){const c=a.combat;for(const r of ROLES){const p=a.players[r];if(p.hp<=0&&before[r].hp>0)battleSay(a,r,'down','down');else if(p.hp>0&&p.hp/p.maxhp<=.3&&before[r].hp/p.maxhp>.3)battleSay(a,r,'low');}
for(const e of c.enemies){const old=before[e.uid];if(!old)continue;if(e.hp<=0&&old.hp>0)battleSay(a,e.uid,'win','defeat');else if(COMBAT_CAST.monsters[e.id]?.boss&&e.hp/e.maxhp<=.5&&old.hp/e.maxhp>.5)battleSay(a,e.uid,'hurt');}
if(c.result==='win'&&!before.result)for(const r of ROLES)battleSay(a,r,'win','victory');}
function snapshot(a){return {result:a.combat.result,...Object.fromEntries([...ROLES.map(r=>[r,{hp:a.players[r].hp,block:a.players[r].block||0}]),...a.combat.enemies.map(e=>[e.uid,{hp:e.hp,block:e.block||0}])])};}
combatUseSkill=function(a,r,id,target){const p=a.players[r],c=a.combat,sk=findSkill(id);if(a.phase!=='combat'||!c||c.result||!p||!sk||p.down||c.ended[r]||p.status.stun)return originalUse(a,r,id,target);const bond=sk.cls==='bond';if(bond?(!a.bondSkills.includes(id)||c.bondUsed||c.spark<(sk.bondCost||0)):(!p.skills.includes(id)||p.energy<(sk.cost||0)||p.cd[id]>0||(sk.oncePerTurn&&p.used?.[id])))return originalUse(a,r,id,target);
const before=snapshot(a),coop=c.coopAwarded.length,kind=bond?'coop':sk.effects.some(e=>e.op==='dmg'||e.target==='enemy'||e.target==='all')?'attack':sk.effects.some(e=>e.op==='heal')?'heal':'guard';battleSay(a,r,kind,kind==='heal'?'cast':kind==='guard'?'guard':'attack',{label:sk.name,targets:[target].filter(Boolean),bond});battleCapture={a,actor:r};try{originalUse(a,r,id,target);}finally{battleCapture=null;}
for(const role of ROLES){const x=a.players[role],hp=x.hp-before[role].hp,block=(x.block||0)-before[role].block;if(hp>0&&c.result!=='win')battleEmit(a,{type:'heal',actor:r,target:role,value:hp});if(block>0)battleEmit(a,{type:'shield',actor:r,target:role,value:block});}if(c.coopAwarded.length>coop)battleSay(a,otherRole(r),'coop','coop');conclude(a,before);};
combatEndTurn=function(a,r){if(a.phase!=='combat'||a.combat.result||a.combat.ended[r])return originalEnd(a,r);const before=snapshot(a);battleCapture={a,actor:null};try{originalEnd(a,r);}finally{battleCapture=null;}conclude(a,before);};
})();

/* DOM rendering. Original art atlases are referenced in CSS so the offline builder
 * can embed them. No gameplay waits for these short visual animations. */
function castGeometry(sheet,index){const g=window.CAST_FRAMES?.[sheet]?.[index];return g?`background-size:${g.sizeX}% ${g.sizeY}%;background-position:${g.posX}% ${g.posY}%;aspect-ratio:${g.w/g.h};--art-width:${Math.min(1,g.w/g.h)*100}%;clip-path:${g.clip}`:'';}
function castSprite(id,hero=false,pose='idle'){const cfg=hero?{sheet:id,row:0,rows:2}:COMBAT_CAST.monsters[id];if(!cfg)return '';const m=hero||cfg.boss?{idle:[0,0],prepare:[1,0],attack:[2,0],hurt:[0,1],guard:[1,1],victory:[2,1],defeat:[hero?0:2,1]}:{idle:[0,cfg.row],prepare:[0,cfg.row],attack:[1,cfg.row],hurt:[2,cfg.row],guard:[0,cfg.row],victory:[0,cfg.row],defeat:[2,cfg.row]};const xy=m[pose]||m.idle;return `<span class="cast-art sheet-${cfg.sheet} ${hero?'hero-art':'monster-art'}" data-cast="${id}" data-hero="${hero}" data-pose="${pose}" style="--frame-x:${xy[0]*50}%;--frame-y:${cfg.height?cfg.start/(1-cfg.height)*100:xy[1]*100/(cfg.rows-1)}%;${castGeometry(cfg.sheet,xy[1]*3+xy[0])}" role="img" aria-label="${esc(hero?COMBAT_CAST.heroes[id].name:GD().enemies.find(e=>e.id===id)?.name)} · ${esc(({idle:'待机',attack:'出招',hurt:'受击',guard:'防御',victory:'胜利',defeat:'败退'})[pose]||'蓄力')}"></span>`;}
function battleStage(a){const c=a.combat,pres=c.presentation,latest=pres?.transcript.at(-1);return `<section class="battle-stage ${c.tier==='boss'?'boss-stage':''}" aria-label="双人战场"><div class="battle-stage-top"><span>${c.tier==='boss'?'首领对峙':'骨城遭遇'} · 第 ${c.turn} 回合</span><label><input type="checkbox" id="battleMotion" ${settings.motion===false?'':'checked'}> 战斗动作</label></div><div class="battle-field"><div class="battle-party">${ROLES.map(r=>{const p=a.players[r];return `<div class="battle-actor hero-actor ${p.down?'is-down':''}" data-actor="${r}"><div class="actor-sprite">${castSprite(p.cls,true,p.down?'hurt':'idle')}</div><div class="actor-caption"><b>${esc(p.name)}</b><small>${COMBAT_CAST.heroes[p.cls].name} · ${p.hp}/${p.maxhp}</small><div class="progress-track hp"><span style="width:${p.hp/p.maxhp*100}%"></span></div></div></div>`;}).join('')}</div><div class="battle-versus" aria-hidden="true">✧</div><div class="battle-foes">${c.enemies.map(e=>`<button class="battle-actor foe-actor ${e.hp<=0?'is-defeated':''} ${ui.target===e.uid?'is-target':''}" data-actor="${e.uid}" data-action="target" data-target="${e.uid}" aria-label="选择目标：${esc(e.name)}" aria-pressed="${ui.target===e.uid}" ${e.hp<=0?'disabled':''}><div class="actor-sprite">${castSprite(e.id,false,e.hp<=0?'defeat':'idle')}</div><div class="actor-caption"><b>${esc(e.name)}</b><small>${e.hp<=0?'已败退':`${e.hp}/${e.maxhp} · 护盾 ${e.block}`}</small><div class="progress-track hp"><span style="width:${e.hp/e.maxhp*100}%"></span></div></div></button>`).join('')}</div></div><div class="battle-subtitle" role="status" aria-live="polite"><b>${esc(latest?.speaker||'同行者')}</b><span>${esc(latest?.text||'两个人都在，就有下一步。')}</span></div><details class="battle-transcript"><summary>战斗对白 · ${pres?.transcript.length||0} 句</summary>${(pres?.transcript||[]).map(x=>`<p><b>${esc(x.speaker)}</b> ${esc(x.text)}</p>`).join('')}</details></section>`;}
const battleVisual={id:null,seen:0,queue:[],playing:false,active:null,poses:{},token:0,speechSeen:0,speechQueue:[],speaking:false,speech:null};
function battlePose(actor,pose){battleVisual.poses[actor]=pose;const node=document.querySelector(`[data-actor="${actor}"] .cast-art`);if(!node)return;const hero=node.dataset.hero==='true',cfg=hero?{row:0,rows:2}:COMBAT_CAST.monsters[node.dataset.cast];const poses=hero||cfg.boss?{idle:[0,0],prepare:[1,0],attack:[2,0],hurt:[0,1],guard:[1,1],victory:[2,1],defeat:[hero?0:2,1]}:{idle:[0,cfg.row],prepare:[0,cfg.row],attack:[1,cfg.row],hurt:[2,cfg.row],guard:[0,cfg.row],victory:[0,cfg.row],defeat:[2,cfg.row]};const xy=poses[pose]||poses.idle;node.dataset.pose=pose;if(window.CAST_FRAMES){node.style.cssText=castGeometry(cfg.sheet||node.dataset.cast,xy[1]*3+xy[0]);return;}node.style.setProperty('--frame-x',xy[0]*50+'%');node.style.setProperty('--frame-y',(cfg.height?cfg.start/(1-cfg.height)*100:xy[1]*100/(cfg.rows-1))+'%');}
function paintBattleSubtitle(){const e=battleVisual.speech,box=document.querySelector('.battle-subtitle');if(!e||!box)return;const who=battleIdentity(S.adv,e.speaker||e.actor);box.querySelector('b').textContent=who.name||'骨城';box.querySelector('span').textContent=e.line;}
function battleSubtitle(e){if(!e.line||e.seq<=battleVisual.speechSeen)return;battleVisual.speechSeen=e.seq;battleVisual.speechQueue.push(e);if(battleVisual.speechQueue.length>4)battleVisual.speechQueue=battleVisual.speechQueue.slice(-4);playBattleSpeech();}
function playBattleSpeech(){if(battleVisual.speaking||!battleVisual.speechQueue.length)return;const token=battleVisual.token;battleVisual.speaking=true;battleVisual.speech=battleVisual.speechQueue.shift();paintBattleSubtitle();setTimeout(()=>{if(token!==battleVisual.token)return;battleVisual.speaking=false;playBattleSpeech();},2000);}
function battlePop(e){const root=document.querySelector(`[data-actor="${e.target}"] .actor-sprite`);if(!root)return;const node=document.createElement('span');node.className='battle-number '+e.type;node.textContent=e.type==='heal'?'+'+e.value:e.type==='shield'?'护盾 +'+e.value:e.value?'−'+e.value:'格挡';root.appendChild(node);setTimeout(()=>node.remove(),850);}
function mountBattlePresentation(){const stage=document.querySelector('.battle-stage'),p=S.adv?.combat?.presentation;if(!stage||!p){if(battleVisual.id){battleVisual.token++;battleVisual.id=null;battleVisual.queue=[];battleVisual.playing=false;battleVisual.poses={};battleVisual.speaking=false;battleVisual.speechQueue=[];battleVisual.speech=null;}return;}if(battleVisual.id!==p.id){battleVisual.token++;Object.assign(battleVisual,{id:p.id,seen:p.seq>12?p.seq:0,queue:[],playing:false,active:null,poses:{},speechSeen:0,speechQueue:[],speaking:false,speech:null});}for(const e of p.events)if(e.seq>battleVisual.seen){battleVisual.queue.push(e);battleVisual.seen=e.seq;}for(const [actor,pose] of Object.entries(battleVisual.poses))battlePose(actor,pose);paintBattleSubtitle();stage.classList.toggle('static-battle',settings.motion===false);if(battleVisual.queue.length>24)battleVisual.queue=battleVisual.queue.slice(-24);playBattleQueue();}
function battleImpact(e,motion,later){
 if(e.type==='hit'&&e.value<=0&&!e.blocked)return;
 battlePop(e);
 if(e.type==='heal'||e.type==='shield'){if(motion)battlePose(e.target,'guard');return;}
 const blocked=e.value<=0,tier=blocked?'blocked':e.value>=12?'heavy':'light';
 if(settings.sound&&typeof playImpact==='function')playImpact(tier);
 if(!motion)return;
 battlePose(e.target,blocked?'guard':'hurt');
 const target=document.querySelector(`[data-actor="${e.target}"]`),field=document.querySelector('.battle-field');
 if(target){target.dataset.impact=tier;target.style.setProperty('--recoil',ROLES.includes(e.target)?'-1':'1');const mark=document.createElement('span');mark.className='impact-mark '+tier;mark.setAttribute('aria-hidden','true');target.querySelector('.actor-sprite')?.appendChild(mark);later(()=>{delete target.dataset.impact;mark.remove();},360);}
 if(tier==='heavy'&&field){field.classList.add('impact-heavy');later(()=>field.classList.remove('impact-heavy'),240);}
}
function playBattleQueue(){
 if(battleVisual.playing||!battleVisual.queue.length)return;
 const e=battleVisual.queue.shift(),token=battleVisual.token,motion=settings.motion!==false&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
 battleVisual.playing=true;battleVisual.active=e;battleSubtitle(e);
 const later=(fn,ms)=>setTimeout(()=>{if(token===battleVisual.token)fn();},ms),actor=e.actor,reactions=[];
 const action=['attack','cast','guard'].includes(e.type);
 if(action)while(battleVisual.queue.length&&['hit','heal','shield'].includes(battleVisual.queue[0].type)&&battleVisual.queue[0].actor===actor)reactions.push(battleVisual.queue.shift());
 let duration=e.type==='say'?40:180;
 if(action){
  const heavy=e.bond||reactions.some(x=>x.type==='hit'&&x.value>=12),windup=heavy?140:100;
  duration=motion?(heavy?490:390):50;
  if(motion)battlePose(actor,'prepare');
  later(()=>{
   if(motion){battlePose(actor,e.type==='guard'?'guard':'attack');const n=document.querySelector(`[data-actor="${actor}"]`);n?.classList.add('actor-strike');later(()=>n?.classList.remove('actor-strike'),220);}
   for(const hit of reactions){battleSubtitle(hit);battleImpact(hit,motion,later);}
  },motion?windup:0);
 }
 if(['hit','heal','shield'].includes(e.type)){battleImpact(e,motion,later);duration=motion?360:50;}
 if(e.type==='coop'){document.querySelector('.battle-stage')?.classList.add('is-coop');later(()=>document.querySelector('.battle-stage')?.classList.remove('is-coop'),600);duration=motion?600:60;}
 if(['victory','defeat','down'].includes(e.type)){battlePose(actor,e.type==='victory'?'victory':e.type==='down'?'hurt':'defeat');duration=motion?600:60;}
 later(()=>{
  if(!['victory','defeat','down'].includes(e.type)&&actor)battlePose(actor,'idle');
  for(const key of new Set([e.target,...reactions.map(x=>x.target)].filter(Boolean))){const who=S.adv?.players[key]||S.adv?.combat?.enemies.find(x=>x.uid===key);if(who?.hp>0)battlePose(key,'idle');}
  battleVisual.playing=false;battleVisual.active=null;playBattleQueue();
 },duration);
}
