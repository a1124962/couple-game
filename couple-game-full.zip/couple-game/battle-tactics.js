/* Optional, once-per-battle cooperation. Each player chooses independently. */
const BATTLE_PLANS=[
 {name:'我来猛攻',desc:'搭猛攻：伤害18，双方易伤+1；搭牵制：伤害12，目标易伤+1；搭照应：伤害8，双方回血6。'},
 {name:'我来牵制',desc:'搭猛攻：伤害12，目标易伤+1；搭牵制：全体敌人虚弱+2，星火+12；搭照应：目标眩晕1回合，双方护盾+8。'},
 {name:'我来照应',desc:'搭猛攻：伤害8，双方回血6；搭牵制：目标眩晕1回合，双方护盾+8；搭照应：双方回血8、护盾+5。'}
];
function enemyTrick(id){
 // Legacy IDs do not describe every creature: sea_rat and drowned_sailor are crabs.
 const voices={
  sea_rat:['敲响空壳','它冲着回声转了半圈，露出壳底。'],
  crab:['撬开壳缝','咔。壳边翘起，钳子立刻缩了回去。'],
  drowned_sailor:['拽住背上的钟','钟绳绷紧，蟹王翘起一侧甲壳。'],
  clockwork_puppet:['拔出卡住的铜板','铜板弹出来，护壳跟着松了一块。'],
  mirror_clone:['照它的壳底','它忙着翻身找倒影，背壳磕在地上。'],
  fog_wraith:['朝它身后打招呼','它急忙回头找人，身上的雾散开了一截。'],
  memory_thief:['问它借笔','它摸出笔，刚写一笔便忘了要写什么。'],
  star_revenant:['指向岸灯','她探头去看岸上的光，露出了护在胸前的灯。'],
  forgotten_shade:['叫它回头','它转了身，停了一下，又转回来。'],
  chain_wraith:['踩住链尾','它往前一飘，链条猛地绷直。'],
  mask_dancer:['拿影子逗它','它扑向地上的影子，一头贴在石板上。'],
  sky_parasite:['假装投喂','它张开嘴等了半天，慢慢塌了下去。'],
  glass_soldier:['敲它的接缝','镜片歪了一块。它伸手去扶，又碰歪一块。'],
  city_guard:['扯歪倒影','它跟着倒影甩钩，钓线缠住了自己的脚。'],
  reflection_knight:['反握武器','它照着反握，护手卡住了手腕。'],
  mirror:['停在半拍','你停了手，镜影还朝前迈了一步。'],
  siren:['敲错一个节拍','她跟着唱了半句，发觉不对，猛地闭了嘴。'],
  god:['追问漏掉的记录','它翻回前一页，指尖停在一处空白。'],
  firststar:['喊出彼此的名字','两点星光分别转向你们，中间空出了一线。'],
  fog_fisherman:['扯住袖口','它还在往前抓，袖口先拉住了胳膊。'],
  smuggler:['说看见了蓝船','他急忙回头，鱼叉慢了一拍。'],
  dockhand:['拨乱钥匙','几条胳膊同时伸向钥匙，挤在一处。'],
  harbor_captain:['假装掏过路钱','他摊开手等着。等了会儿，手还摊着。'],
  faceless_judge:['请它查页码','它开始数页，数到一半，又翻回开头。'],
  gate_guardian:['问它门关没关','它急忙回头检查，武器也跟着偏了。'],
  star_hound:['朝旁边扔石子','它追了两步，鼻尖碰到一块石头。'],
  celestial_executioner:['喊停查账','它把武器夹在腋下，先找账上的名字。'],
  astral_colossus:['敲动脚边石块','巨像低头找声音，拳头砸在了自己脚边。']
 };
 let kind='feint';
 if(['sea_rat','crab','drowned_sailor','clockwork_puppet','mirror_clone'].includes(id))kind='shell';
 else if(['fog_wraith','memory_thief','star_revenant','forgotten_shade','chain_wraith'].includes(id))kind='name';
 else if(['mask_dancer','sky_parasite'].includes(id))kind='slime';
 else if(['glass_soldier','city_guard','reflection_knight','mirror'].includes(id))kind='mirror';
 else if(['siren','god','firststar'].includes(id))kind='listen';
 const hints={shell:'清空目标护盾，施加2层易伤。',name:'施加2层虚弱、1层易伤。',slime:'清空目标力量，施加2层虚弱。',mirror:'施加2层易伤。',listen:'施加2层虚弱，羁绊+2。',feint:'施加2层虚弱。'};
 const [label,reply]=Object.hasOwn(voices,id)?voices[id]:['虚晃一步','它追着假动作出手，打了个空。'];
 return {kind,label,hint:hints[kind],reply};
}
(function(){const begin=combatStart,reduce=advReduce;combatStart=function(a,ids,tier){begin(a,ids,tier);a.combat.tactics={picks:{host:null,guest:null},done:false,result:'',target:null};for(const e of a.combat.enemies)e.trick={...enemyTrick(e.id),used:false};};
advReduce=function(a,ac,r,names){if(!['battlePlan','enemyTrick'].includes(ac.type))return reduce(a,ac,r,names);const c=a.combat,p=a.players[r];if(a.phase!=='combat'||!c||c.result||!ROLES.includes(r)||!p||p.down)return;
if(ac.type==='enemyTrick'){if(c.ended[r])return;const e=c.enemies.find(e=>e.uid===ac.target&&e.hp>0);if(!e||e.trick?.used||p.energy<1)return;e.trick??={...enemyTrick(e.id),used:false};p.energy--;e.trick.used=true;const kind=e.trick.kind;if(kind==='shell'){e.block=0;e.status.vuln=(e.status.vuln||0)+2;}else if(kind==='mirror')e.status.vuln=(e.status.vuln||0)+2;else{e.status.weak=(e.status.weak||0)+2;if(kind==='name')e.status.vuln=(e.status.vuln||0)+1;if(kind==='slime')e.status.str=0;if(kind==='listen')advBondAdd(a,2);}advLog(a,p.name+'利用了'+e.name+'的破绽：'+e.trick.label+'。');if(typeof battleEmit==='function'){battleEmit(a,{type:'cast',actor:r,line:'等下，试试这招。',label:e.trick.label});battleEmit(a,{type:'say',actor:e.uid,line:e.trick.reply});}return;}
c.tactics??={picks:{host:null,guest:null},done:false,result:'',target:null};const t=c.tactics;if(t.done||t.picks[r]!==null||!Number.isInteger(ac.idx)||ac.idx<0||ac.idx>2)return;t.picks[r]=ac.idx;if(!t.target)t.target=c.enemies.find(e=>e.uid===ac.target&&e.hp>0)?.uid||c.enemies.find(e=>e.hp>0)?.uid;if(ROLES.some(role=>t.picks[role]===null))return;t.done=true;const pair=Object.values(t.picks).sort().join(''),enemy=c.enemies.find(e=>e.uid===t.target&&e.hp>0)||c.enemies.find(e=>e.hp>0);let amount=0,heal=0,shield=0;
if(pair==='00'){amount=18;for(const role of ROLES)a.players[role].status.vuln=(a.players[role].status.vuln||0)+1;t.result='两人一起出手，没留空当防守。攻击目标：18点伤害；双方易伤+1。';}
if(pair==='01'){amount=12;if(enemy)enemy.status.vuln=(enemy.status.vuln||0)+1;t.result='一人招手引开视线，另一人从侧面出手。攻击目标：12点伤害，目标易伤+1。';}
if(pair==='02'){amount=8;heal=6;t.result='一人压住攻势，另一人抽空包扎。攻击目标：8点伤害；双方各恢复6点生命。';}
if(pair==='11'){for(const e of c.enemies.filter(e=>e.hp>0))e.status.weak=(e.status.weak||0)+2;c.spark=Math.min(100,c.spark+12);t.result='你们轮流出假招，敌人的动作乱了。全体敌人虚弱+2，星火+12。';}
if(pair==='12'){shield=8;if(enemy)enemy.status.stun=(enemy.status.stun||0)+1;t.result='一人引它出招，另一人趁空当截住。目标眩晕1回合；双方各获得8点护盾。';}
if(pair==='22'){heal=8;shield=5;t.result='你们腾出手包扎，再互相检查护具。双方各恢复8点生命、获得5点护盾。';}
if(typeof battleEmit==='function')battleEmit(a,{type:'coop',actor:r,line:t.result});if(amount&&enemy){const before=enemy.hp,dealt=damage(enemy,amount);if(typeof battleEmit==='function')battleEmit(a,{type:'hit',actor:r,target:enemy.uid,value:before-enemy.hp,dead:enemy.hp<=0});advLog(a,'双人配合 → '+enemy.name+' −'+dealt);}
for(const role of ROLES){const x=a.players[role];if(x.down)continue;const before=x.hp;x.hp=Math.min(x.maxhp,x.hp+heal);x.block+=shield;if(typeof battleEmit==='function'){if(x.hp>before)battleEmit(a,{type:'heal',actor:r,target:role,value:x.hp-before});if(shield)battleEmit(a,{type:'shield',actor:r,target:role,value:shield});}}advLog(a,t.result);const won=checkCombat(a);if(won&&c.result==='win'&&typeof battleSay==='function'){if(enemy)battleSay(a,enemy.uid,'win','defeat');for(const role of ROLES)battleSay(a,role,'win','victory');}};
})();
function battleTacticsView(a,r){const c=a.combat,t=c.tactics||{picks:{host:null,guest:null},done:false},p=a.players[r],e=c.enemies.find(e=>e.uid===ui.target&&e.hp>0)||c.enemies.find(e=>e.hp>0),trick=e&&(e.trick||enemyTrick(e.id));return `<section class="battle-tactics"><div class="tactics-heading"><h3>双人配合</h3><small>每场一次 · 不耗能量 · 各自锁定后揭晓</small></div>${t.done?`<p class="tactics-result">${esc(t.result)}</p>`:`<div class="tactics-picks">${BATTLE_PLANS.map((plan,i)=>`<button class="choice ${t.picks[r]===i?'selected':''}" data-action="adv" data-type="battlePlan" data-idx="${i}" data-target="${ui.target}" ${t.picks[r]!==null||p.down?'disabled':''}><span><strong>${plan.name}</strong><small>${plan.desc}</small></span></button>`).join('')}</div><p class="vote-status">${t.picks[r]!==null?'你已锁定，等旅伴选择。':t.picks[otherRole(r)]!==null?'旅伴已锁定，轮到你选。':'两人各选一项，组合效果见按钮说明。'}</p>`}${e?`<details class="enemy-trick"><summary>${esc(e.name)}的破绽 · ${trick.used?'本场已用':'每只敌人限一次'}</summary><p>${esc(trick.hint)}</p>${button(esc(trick.label)+' · 1 能量','adv',`data-type="enemyTrick" data-target="${e.uid}" ${trick.used||p.energy<1||p.down||c.ended[r]?'disabled':''}`,'small secondary')}</details>`:''}</section>`;}
