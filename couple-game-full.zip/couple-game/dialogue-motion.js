/* Local portrait motion only. No shared state, RNG, votes or reading progress. */
(function(){
'use strict';
if(window.DIALOGUE_MOTION)return;
const HEROES=new Set(['blade','warden','weaver','seer']);
const motion={scene:null,enabled:false,token:0,timers:new Set(),actors:[]};
const preference=typeof matchMedia==='function'?matchMedia('(prefers-reduced-motion: reduce)'):null;
function allowed(){return !document.hidden&&!preference?.matches&&(typeof settings==='undefined'||settings.motion!==false)&&!document.body?.classList.contains('reduced-motion');}
function later(fn,ms){
 const token=motion.token,id=setTimeout(()=>{
  motion.timers.delete(id);
  if(token===motion.token&&motion.enabled&&motion.scene?.isConnected&&allowed())fn();
 },ms);
 motion.timers.add(id);return id;
}
function frame(art,value){art.style.setProperty('--dialogue-frame',String(value));art.dataset.motionFrame=String(value);}
function cancel(){
 motion.token++;
 for(const timer of motion.timers)clearTimeout(timer);
 motion.timers.clear();
 motion.scene?.classList.remove('dialogue-motion-enabled');
 for(const actor of motion.actors){
  actor.classList.remove('dialogue-gesturing');
  const art=actor.querySelector('[data-dialogue-atlas]');
  if(art&&HEROES.has(art.dataset.dialogueAtlas))frame(art,0);
 }
 motion.scene=null;motion.actors=[];motion.enabled=false;
}
function cadence(id){return [...id].reduce((n,c)=>n+c.charCodeAt(0),0);}
function blink(actor,art,seed,index,cycle=0){
 later(()=>{
  // The closed-eye frame is never shown over an authored speaking gesture.
  if(!actor.classList.contains('dialogue-gesturing')){
   frame(art,1);
   later(()=>frame(art,0),125);
  }
  blink(actor,art,seed,index,cycle+1);
 },cycle===0?2400+seed%700+index*610:4200+(seed+cycle*431)%1700);
}
function mount(){
 const scene=document.querySelector('.vn-scene'),enabled=!!scene&&allowed();
 if(scene===motion.scene&&enabled===motion.enabled)return;
 cancel();motion.scene=scene;motion.enabled=enabled;
 if(!scene||!enabled)return;
 scene.classList.add('dialogue-motion-enabled');
 motion.actors=[...scene.querySelectorAll('.dialogue-person,.vn-npc,.vn-traveler,.vn-boss')];
 motion.actors.forEach((actor,index)=>{
  const art=actor.querySelector('[data-dialogue-atlas]');
  // Existing NPC sheets contain emotional poses, not blink frames. Keep them intact.
  if(!art||!HEROES.has(art.dataset.dialogueAtlas))return;
  const seed=cadence(art.dataset.dialogueAtlas);frame(art,0);
  if(actor.classList.contains('is-speaking')){
   later(()=>{
    actor.classList.add('dialogue-gesturing');frame(art,2);
    later(()=>{actor.classList.remove('dialogue-gesturing');frame(art,0);},760);
   },180);
  }
  blink(actor,art,seed,index);
 });
}
const app=document.getElementById('app');
if(app&&typeof MutationObserver!=='undefined')new MutationObserver(mount).observe(app,{childList:true});
if(document.body&&typeof MutationObserver!=='undefined')new MutationObserver(mount).observe(document.body,{attributes:true,attributeFilter:['class']});
document.addEventListener('visibilitychange',mount);
if(preference?.addEventListener)preference.addEventListener('change',mount);
else if(preference?.addListener)preference.addListener(mount);
window.addEventListener('pagehide',cancel);
window.addEventListener('pageshow',mount);
window.DIALOGUE_MOTION={mount,cancel,get active(){return motion.enabled;},get pending(){return motion.timers.size;}};
mount();
})();
