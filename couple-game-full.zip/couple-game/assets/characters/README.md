# 骨城人物立绘

使用内置 image_gen 工具生成；原始透明 PNG 保留，无像素级后期处理。由 CSS 裁切三栏，不修改文件。

| 文件 | 人物 | 左 / 中 / 右 |
|---|---|---|
| mara.png | 玛拉，铁钩手臂的渔夫 | 冷静 / 调侃微笑 / 难过 |
| quill.png | 奎尔，戴手套的图书馆员 | 冷静 / 会心微笑 / 含泪 |
| pip.png | 皮普，穿过大渔夫外套的孩子 | 迟疑 / 开心 / 担忧 |
| holt.png | 赫尔特，潮汐石左眼的守门人 | 疲惫 / 温和 / 低头伤感 |
| quiet.png | 静默者，面具与石板 | 戴面具 / 戴面具微笑 / 摘下面具 |

静默者的第三栏仅用于明确摘下面具的剧情节点。手机端使用同一张图的上半身裁切。

## 生成提示词集

共同规格：`Use case: illustration-story. One transparent 1536×1024 PNG sprite sheet with exactly three equal-width columns; identical full-body character and scale, aligned foot baseline. Left composed, center warm/amused, right vulnerable/sad. Elegant hand-painted dark fantasy storybook, fine ink contours, detailed fabric, deep teal / bone ivory / antique gold. No text, logo, borders, scenery or other characters.`

人物规格：

- Mara: `Rugged Chinese fisherwoman, late 40s; tan skin, greying bun, worn teal coat, ochre scarf, same-side iron hook prosthesis, dried fish in paper. Sardonic, affectionate grin, grief.`
- Quill: `Chinese female archivist, 30s; dark bob, brass hairpin, glasses, ivory shirt, dark teal waistcoat and long skirt coat, ink-stained white gloves, ledger and pen. Reserved, dry smile, glistening eyes.`
- Pip: `Chinese boy age 10; messy hair, oversized patched fisher coat, large boots, half a bun. Wary, delighted, worried.`
- Holt: `Elderly Chinese man, 70s; grey hair and stubble, sea-glass stone left eye, patched grey-green coat, embroidered sleeve without legible text, keys and staff. Tired, kindly, wistful.`
- Quiet: `Adult androgynous Chinese male priest; ivory robe with teal layers, slate and chalk. First two columns masked, third unmasked holding the same mask. Neutral, warm eyes, vulnerable.`
