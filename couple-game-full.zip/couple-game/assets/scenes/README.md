# 骨城 Galgame 环境图

由内置图像生成完成；用于三幕场景背景，WebP 仅作网页压缩。

## harbor

Use case: stylized-concept. Production background artwork for a Chinese dark-fairytale galgame, Echoes & Bones. Landscape 1536x1024 composition, usable as 16:9 cover crop. Act I, a quiet strange seaside harbor at blue hour. Foreground wide worn stone quay and puddles with enough empty space for character sprites; weathered fishing cottages and a lantern stall on the left; an elegant immense bridge made of ivory rib-like arches leading into mist center; distant half-submerged clocktower and crescent moon, moored little boats. Warm amber windows against muted jade teal fog, intimate melancholic but welcoming and slightly whimsical, refined painterly visual novel background with detailed hand-inked lines, harmonious muted colors. No people or creatures. No text, no letters, no UI panels, no borders, no logos. The lower third is calm and dark enough to place readable dialogue; main architectural focal points in upper two thirds. Cohesive hand-painted storybook visual style, high quality background illustration.

## archive

Use case: stylized-concept. Production background artwork for a Chinese dark-fairytale galgame, Echoes & Bones. Landscape 1536x1024 composition, usable as 16:9 cover crop. Act II, the Hall of Missing Names in an impossible coastal city. Foreground wide polished dark stone floor open for character sprites; towering elegant archive shelves full of old parchment folios, hanging brass labels, graceful arches and antique oval mirrors; an enormous round clock window above the center shows a muted violet dusk sky. Shallow water reflecting lamplight at far edge of room. Warm ochre lamps and desaturated blue-violet shadows, magical and quietly absurd, refined painterly hand-inked visual novel environment. No people or creatures. No text, no letters, no UI panels, no borders, no logos. The lower third is calm and dark enough to place readable dialogue; main architectural focal points in upper two thirds. Cohesive hand-painted storybook visual style, high quality background illustration.

## stair

Use case: stylized-concept. Production background artwork for a Chinese dark-fairytale galgame, Echoes & Bones. Landscape 1536x1024 composition, usable as 16:9 cover crop. Act III, a monumental staircase above the midnight tide leading to the open door of a sunken observatory. Foreground broad stone terrace empty for character sprites; carved ivory balustrades, pale wildflowers between steps, a line of tiny brass lamps; gigantic blue-black sea and a golden constellation ring suspended behind the distant observatory. Two small stars in the sky, tender hope amid ancient melancholy. Muted teal, ink blue, parchment gold, elegant painterly hand-inked visual novel environment. No people or creatures. No text, no letters, no UI panels, no borders, no logos. The lower third is calm and dark enough to place readable dialogue; main architectural focal points in upper two thirds. Cohesive hand-painted storybook visual style, high quality background illustration.


