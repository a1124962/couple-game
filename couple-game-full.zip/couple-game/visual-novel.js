/* Scenic presentation; local reading does not change shared votes or rewards. */
function prologueAtArchive(a){if(a.phase!=='intro')return false;const pages=storyPages(GD().intro.text),landing=pages.findIndex(p=>p.includes('你们落在'));return ui.fullText||landing<0||(ui.readPages?.[readerKey(a)]||0)<landing;}
function scenePortrait(id,mood,a){
 const expression={neutral:0,smile:1,annoyed:2}[mood]||0;
 if(['innkeeper','porter','laundress'].includes(id))return `<div class="dialogue-portrait dialogue-portrait-${id}" data-character="${id}" data-expression="${expression}" style="--expression:${expression}" role="img" aria-label="${esc(dialogueSpeaker(id))}的立绘：${['平静','微笑','不满'][expression]}"></div>`;
 const npc=GD().npcs.find(n=>n.id===id);
 if(!npc)return '';
 // Quiet's third frame reveals his face. A generic mood must never reveal it.
 const current=a.phase==='npc'&&a.npc?.id===id;
 if(current&&!ui.readerCurrent?.tagged)return characterPortrait(npc,a);
 const safeMood=id==='quiet'?(current?characterMood(a):Math.min(expression,1)):(expression===2?0:expression);
 return `<figure class="character-stage" data-character="${id}" data-expression="${safeMood}"><div class="character-art character-${id}" style="--expression:${safeMood}" role="img" aria-label="${esc(npc.name)}的立绘"></div></figure>`;
}
function dialogueHeroPortrait(player,role){
 const cls=player?.cls;if(!['blade','warden','weaver','seer'].includes(cls))return '';
 return `<div class="dialogue-hero-art dialogue-hero-${cls}" data-dialogue-atlas="${cls}" role="img" aria-label="${esc(dialogueSpeaker(role))}的立绘"></div>`;
}
function dialogueCast(a,scene,npc){
 const state=ui.readerCurrent||{},speaking=ui.fullText?null:state.tagged?state.speaker:npc?.id||null;
 const declared=(scene?.stage?.cast||[npc?.id]).filter(id=>Object.prototype.hasOwnProperty.call(DIALOGUE_SPEAKERS,id)&&!['host','guest','stage'].includes(id));
 const speakerNpc=speaking&&!['host','guest','stage','unknown'].includes(speaking)?speaking:null;
 const partner=speakerNpc||declared[0];
 if(partner){
  const lastPlayer=['host','guest'].includes(speaking)?speaking:state.playerSpeaker||'host';
  const role=a.players?.[lastPlayer]?lastPlayer:otherRole(lastPlayer);
  return [{id:role,type:'player'},{id:partner,type:'npc'}].filter(person=>person.type==='npc'||a.players?.[person.id]).map(person=>({...person,speaking:person.id===speaking,mood:person.id===speaking?state.mood:'neutral'}));
 }
 // The two protagonists retain their sides when the speaker changes.
 return ['host','guest'].filter(role=>a.players?.[role]).map((role,i)=>({id:role,type:i?'partner':'player',speaking:role===speaking,mood:role===speaking?state.mood:'neutral'}));
}
function dialogueStage(a,scene,npc){
 return `<div class="vn-cast dialogue-stage" aria-label="场景中的人物">${dialogueCast(a,scene,npc).map(person=>`<div class="dialogue-person dialogue-person-${person.type} ${person.speaking?'is-speaking':''}" data-person="${person.id}">${person.type==='npc'?scenePortrait(person.id,person.mood,a):dialogueHeroPortrait(a.players[person.id],person.id)}</div>`).join('')}</div>`;
}
const textStoryView=storyView;
storyView=function(a){
 let body=textStoryView(a);if(!body||a.phase==='map')return body;
 const archive=prologueAtArchive(a),n=a.phase==='npc'?GD().npcs.find(n=>n.id===a.npc.id):null,boss=a.phase==='encounter'?['siren','mirror','god'][a.act-1]:null;
 if(n)body=body.replace(characterPortrait(n,a),'');
 const daily=GD().dailyScenes?.sceneFor(a),tagged=ui.readerCurrent?.tagged;
 const scene=daily||(a.phase==='intro'?GD().intro:a.phase==='actIntro'?GD().actIntros[a.act-1]:a.phase==='interlude'?GD().interludes.find(d=>d.id===a.interlude.id):a.phase==='event'?GD().events.find(d=>d.id===a.event.id):n?n.meetings[a.npc.meeting]:null);
 const place=['bathhouse','kitchen','laundry','workshop'].includes(scene?.stage?.background)?scene.stage.background:'';
 const places={bathhouse:'长明澡堂 · 前厅',kitchen:'长明澡堂 · 夜灶',laundry:'长明澡堂 · 洗衣房',workshop:'长明澡堂 · 后院'};
 const title=a.phase==='intro'?GD().intro.title:n?n.meetings[a.npc.meeting].title:a.phase==='event'?GD().events.find(e=>e.id===a.event.id)?.title:a.phase==='interlude'?GD().interludes.find(e=>e.id===a.interlude.id)?.title:a.phase==='encounter'?GD().bossScenes[a.act-1].title:a.phase==='ending'?a.ending.title:GD().chapters[a.act-1].place;
 const legacyCast=boss?`<div class="vn-cast" aria-label="场景中的人物"><div class="vn-boss" data-person="${boss}">${castSprite(boss,false)}</div><div class="vn-travelers with-speaker">${ROLES.map(r=>a.players[r]?`<div class="vn-traveler" data-person="${r}">${dialogueHeroPortrait(a.players[r],r)}</div>`:'').join('')}</div></div>`:dialogueStage(a,scene,n);
 const label=tagged?(ui.fullText?'对话回看':dialogueSpeaker(ui.readerCurrent.speaker)):n?'与 '+n.name+' 对话':boss?(GD().enemies.find(e=>e.id===boss)?.name||'')+' · 对峙':'眼前';
 return `<section class="vn-scene vn-act-${a.act} ${n?'vn-conversation':''} ${readDone()?'vn-decision':'vn-reading'} ${archive?'vn-prologue':''} ${boss?'vn-encounter':''} ${tagged?'vn-dialogue-scene':''} ${place?'vn-place-'+place:''}"><div class="vn-backdrop" aria-hidden="true"></div><div class="vn-location"><small>第 ${a.act} 幕 · ${esc(places[place]||(archive?'零号档案馆':GD().chapters[a.act-1].place))}</small><h2>${esc(title||'零号档案')}</h2></div>${tagged?dialogueStage(a,scene,n):legacyCast}<div class="vn-textbox"><div class="vn-reading-hint" aria-hidden="true">${ui.fullText?'可滚动回读全文':readDone()?'已读完':'轻点文字继续 · ← → 翻页'}</div><div class="vn-nameplate" data-speaker="${esc(tagged?ui.readerCurrent.speaker||'stage':n?.id||'stage')}">${esc(label)}</div>${body}</div></section>`;
};
