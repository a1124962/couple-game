/* Scenic presentation; local reading does not change shared votes or rewards. */
function prologueAtArchive(a){if(a.phase!=='intro')return false;const pages=storyPages(GD().intro.text),landing=pages.findIndex(p=>p.includes('你们落在'));return ui.fullText||landing<0||(ui.readPages?.[readerKey(a)]||0)<landing;}
function scenePortrait(id,mood,a){
 const expression={neutral:0,smile:1,annoyed:2}[mood]||0;
 if(['innkeeper','porter','laundress'].includes(id))return `<div class="dialogue-portrait dialogue-portrait-${id}" data-character="${id}" data-expression="${expression}" style="--expression:${expression}" role="img" aria-label="${esc(dialogueSpeaker(id))}的立绘：${['平静','微笑','不满'][expression]}"></div>`;
 const npc=GD().npcs.find(n=>n.id===id);
 if(!npc)return '';
 // Quiet's third frame reveals his face. A generic mood must never reveal it.
 const current=a.phase==='npc'&&a.npc?.id===id;
 const safeMood=id==='quiet'?(current?characterMood(a):Math.min(expression,1)):(expression===2?0:expression);
 return `<figure class="character-stage" data-character="${id}" data-expression="${safeMood}"><div class="character-art character-${id}" style="--expression:${safeMood}" role="img" aria-label="${esc(npc.name)}的立绘"></div></figure>`;
}
function dialogueStage(a,scene,npc){
 const state=ui.readerCurrent||{},speaking=ui.fullText?null:state.speaker;
 const declared=(scene?.stage?.cast||[npc?.id]).filter(id=>Object.prototype.hasOwnProperty.call(DIALOGUE_SPEAKERS,id)&&!['host','guest','stage'].includes(id));
 const guestSpeaker=speaking&&!['host','guest','stage','unknown'].includes(speaking)?speaking:declared[0];
 const role=['host','guest'].includes(speaking)?speaking:(session.role==='guest'?'guest':'host');
 const hero=a.players?.[role],other=otherRole(role),heroOther=a.players?.[other];
 const person=guestSpeaker?`<div class="dialogue-person dialogue-person-npc ${speaking===guestSpeaker?'is-speaking':''}" data-person="${guestSpeaker}">${scenePortrait(guestSpeaker,speaking===guestSpeaker?state.mood:'neutral',a)}</div>`:heroOther?`<div class="dialogue-person dialogue-person-partner" data-person="${other}">${castSprite(heroOther.cls,true)}</div>`:'';
 return `<div class="vn-cast dialogue-stage" aria-label="场景中的人物">${hero?`<div class="dialogue-person dialogue-person-player ${speaking===role?'is-speaking':''}" data-person="${role}">${castSprite(hero.cls,true)}</div>`:''}${person}</div>`;
}
const textStoryView=storyView;
storyView=function(a){
 let body=textStoryView(a);if(!body||a.phase==='map')return body;
 const archive=prologueAtArchive(a),n=a.phase==='npc'?GD().npcs.find(n=>n.id===a.npc.id):null,boss=a.phase==='encounter'?['siren','mirror','god'][a.act-1]:null;
 if(n)body=body.replace(characterPortrait(n,a),'');
 const daily=GD().dailyScenes?.sceneFor(a),tagged=ui.readerCurrent?.tagged;
 const scene=daily||(a.phase==='intro'?GD().intro:a.phase==='actIntro'?GD().actIntros[a.act-1]:a.phase==='interlude'?GD().interludes.find(d=>d.id===a.interlude.id):a.phase==='event'?GD().events.find(d=>d.id===a.event.id):n?n.meetings[a.npc.meeting]:null);
 const place=['bathhouse','kitchen','laundry','workshop'].includes(scene?.stage?.background)?scene.stage.background:'';
 const places={bathhouse:'长明澡堂 · 前厅',kitchen:'长明澡堂 · 夜灶',laundry:'长明澡堂 · 洗衣房',workshop:'长明澡堂 · 后院'};
 const title=a.phase==='intro'?GD().intro.title:n?n.meetings[a.npc.meeting].title:a.phase==='event'?GD().events.find(e=>e.id===a.event.id)?.title:a.phase==='interlude'?GD().interludes.find(e=>e.id===a.interlude.id)?.title:a.phase==='encounter'?GD().bossScenes[a.act-1].title:a.phase==='ending'?a.ending.title:GD().chapters[a.act-1].place;
 const legacyCast=`<div class="vn-cast" aria-label="场景中的人物">${n?`<div class="vn-npc">${characterPortrait(n,a)}</div>`:boss?`<div class="vn-boss">${castSprite(boss,false)}</div>`:''}<div class="vn-travelers ${n||boss?'with-speaker':''}">${ROLES.map(r=>a.players[r]?`<div class="vn-traveler">${castSprite(a.players[r].cls,true)}<span>${esc(a.players[r].name)}</span></div>`:'').join('')}</div></div>`;
 const label=tagged?(ui.fullText?'对话回看':dialogueSpeaker(ui.readerCurrent.speaker)):n?'与 '+n.name+' 对话':boss?(GD().enemies.find(e=>e.id===boss)?.name||'')+' · 对峙':'眼前';
 return `<section class="vn-scene vn-act-${a.act} ${n?'vn-conversation':''} ${readDone()?'vn-decision':'vn-reading'} ${archive?'vn-prologue':''} ${boss?'vn-encounter':''} ${tagged?'vn-dialogue-scene':''} ${place?'vn-place-'+place:''}"><div class="vn-backdrop" aria-hidden="true"></div><div class="vn-location"><small>第 ${a.act} 幕 · ${esc(places[place]||(archive?'零号档案馆':GD().chapters[a.act-1].place))}</small><h2>${esc(title||'零号档案')}</h2></div>${tagged?dialogueStage(a,scene,n):legacyCast}<div class="vn-textbox"><div class="vn-reading-hint" aria-hidden="true">${ui.fullText?'可滚动回读全文':readDone()?'已读完':'轻点文字继续 · ← → 翻页'}</div><div class="vn-nameplate" data-speaker="${esc(tagged?ui.readerCurrent.speaker||'stage':n?.id||'stage')}">${esc(label)}</div>${body}</div></section>`;
};
