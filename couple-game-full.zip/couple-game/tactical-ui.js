/* A small, touch-friendly front end for authoritative cooperative board actions. */
const BOARD_UI_TERRAIN={
 wall:{label:'墙',detail:'挡住去路；把怪推上去会撞疼。'},
 oil:{label:'油',detail:'被推到油上会再滑一格。'},
 trap:{label:'陷阱',detail:'把怪推进去，触发伤害与眩晕。'},
 barrel:{label:'炸桶',detail:'碰撞或点燃会爆炸，也会波及身边的旅人。'},
 fire:{label:'火',detail:'经过会受伤，小心脚下。'}
};
function boardUiCoordinate(p){return p?String.fromCharCode(65+p.x)+(p.y+1):'—';}
function boardUiName(a,key){return a.players[key]?.name||a.combat.enemies.find(e=>e.uid===key)?.name||'空地';}
function boardUiSkill(a,r){const p=a.players[r],chosen=ui.boardSkill;return chosen&&p.skills.includes(chosen)?chosen:boardDefaultSkill(a,r);}
function boardUiSkillAim(sk){
 const effects=sk?.effects||[],enemy=effects.some(e=>e.op==='dmg'||e.target==='enemy'||e.target==='all');
 if(enemy)return {enemy:true,scope:'enemy',label:'点怪物',who:'怪物'};
 const targets=effects.filter(e=>['status','block','heal','energy','maxhp'].includes(e.op)).map(e=>e.target||'self');
 const scope=targets.includes('both')||(targets.includes('self')&&targets.includes('ally'))?'both':targets.includes('ally')?'ally':'self';
 return {enemy:false,scope,label:'直接施放',who:scope==='both'?'双方':scope==='ally'?'旅伴':'自己'};
}
function boardUiRecipient(aim,r,key){return ROLES.includes(key)&&(aim.scope==='both'||(aim.scope==='ally'?key===otherRole(r):key===r));}
function boardUiTactics(a,r){const html=battleTacticsView(a,r);return boardUiLocked(a,r)?html.replace(/<button(?![^>]*\bdisabled\b)/g,'<button disabled'):html;}
function boardUiTool(){return ['attack','push','move'].includes(ui.boardTool)?ui.boardTool:'attack';}
function boardUiLocked(a,r){return !!(a.players[r].down||a.combat.board.locked[r]);}
function boardUiAction(a,action){if(!action)return '还没选好';if(action.kind==='skill'){const sk=findSkill(action.skill),aim=boardUiSkillAim(sk);if(sk&&!aim.enemy)return sk.name+' · 给'+aim.who;}return boardActionLabel(action,a);}
function boardUiSetup(a,r){const identity=a.id+':'+a.combat.presentation?.id+':'+a.combat.turn+':'+r;if(ui.boardFocus!==identity){ui.boardFocus=identity;ui.boardTool=a.practice&&a.combat.turn===1&&r==='host'?'push':'attack';ui.boardSkill=null;ui.boardTip='';}const alive=a.combat.enemies.filter(e=>e.hp>0);if(!alive.some(e=>e.uid===ui.target))ui.target=alive[0]?.uid;}
function boardUiPushPreview(a,r,target){
 if(!target)return null;const check=clone(a),before=check.combat.enemies.find(e=>e.uid===target.uid);check.combat.board.queues={host:[],guest:[]};check.combat.board.queues[r]=[{kind:'push',target:target.uid}];
 const result=boardPreview(check),step=result.steps.find(s=>s.role===r),after=result.enemies.find(e=>e.uid===target.uid),position=result.board.positions[target.uid];
 if(!step?.ok)return null;const damage=Math.max(0,before.hp-after.hp),shield=Math.max(0,(before.block||0)-(after.block||0)),stun=(after.status.stun||0)>(before.status.stun||0),from=a.combat.board.positions[target.uid];
 return {position,moved:position.x!==from.x||position.y!==from.y,text:'预计 '+boardUiCoordinate(position)+' · '+damage+' 伤害'+(shield?' · 破盾 '+shield:'')+(stun?' · 眩晕':'')};
}
function boardUiCell(a,r,x,y,preview,pushPreview){
 const b=a.combat.board,unit=boardAt(a,x,y),hero=ROLES.includes(unit),who=hero?a.players[unit]:a.combat.enemies.find(e=>e.uid===unit),terrain=b.tiles.find(t=>t.x===x&&t.y===y),kind=terrain?.kind,info=BOARD_UI_TERRAIN[kind],coord=boardUiCoordinate({x,y});
 const threats=(b.threats||[]).filter(t=>(t.cells||[]).some(p=>p.x===x&&p.y===y)),danger=threats.length>0;
 const future=preview?.board?.positions?.[r],now=b.positions[r],arrival=future&&now&&(future.x!==now.x||future.y!==now.y)&&future.x===x&&future.y===y;
 const tool=boardUiTool(),aim=boardUiSkillAim(findSkill(boardUiSkill(a,r))),selected=tool==='attack'&&!aim.enemy?boardUiRecipient(aim,r,unit):unit&&unit===ui.target,roleMark=hero?(unit===r?'你':'伴'):'敌',from=b.positions[r];const available=!boardUiLocked(a,r)&&!a.players[r].status.stun&&(tool==='move'?!!boardPath(a,r,{x,y},2)?.length:tool==='push'?!!(who&&!hero&&from&&(from.x===x||from.y===y)&&Math.abs(from.x-x)+Math.abs(from.y-y)<=2):aim.enemy?!!(who&&!hero):boardUiRecipient(aim,r,unit));
 const pushArrival=pushPreview?.moved&&pushPreview.position.x===x&&pushPreview.position.y===y;const label=[coord,who?boardUiName(a,unit):'空地',who?'生命'+who.hp+'，护盾'+(who.block||0):'',info?.label,danger?'敌人将在这里出招':'',arrival?'你的预计落点':'',pushArrival?'怪物的预计落点':''].filter(Boolean).join('，');
 return `<button type="button" id="board-cell-${x}-${y}" class="board-cell ${hero?'is-hero':who?'is-enemy':''} ${kind?'terrain-'+kind:''} ${danger?'is-danger':''} ${selected?'is-selected':''} ${arrival?'is-arrival':''} ${available?'is-available':''} ${pushArrival?'is-push-arrival':''}" data-action="tacticalCell" data-x="${x}" data-y="${y}" ${who?`data-board-actor="${unit}"`:''} aria-label="${esc(label)}" aria-pressed="${!!selected}" title="${esc(label)}"><span class="board-coord" aria-hidden="true">${coord}</span>${danger?'<span class="board-danger-mark" aria-hidden="true">!</span>':''}${info?`<span class="board-terrain" aria-hidden="true">${info.label}</span>`:''}${who?`<span class="board-unit actor-sprite">${castSprite(hero?who.cls:who.id,hero,'idle')}</span><span class="board-unit-label"><b>${roleMark}</b><span>${who.hp}<small>♥</small>${who.block?'<i>＋'+who.block+'盾</i>':''}</span></span>`:''}${arrival?'<span class="board-arrival" aria-hidden="true">落点</span>':''}${available&&tool==='move'?'<span class="board-move-mark" aria-hidden="true"></span>':''}${pushArrival?'<span class="board-push-arrival" aria-hidden="true">怪落点</span>':''}</button>`;
}
function boardUiCommit(a,r,preview){
 const b=a.combat.board,own=b.queues[r]?.[0],other=otherRole(r),locked=boardUiLocked(a,r),step=preview?.steps?.find(s=>s.role===r),both=ROLES.every(role=>boardUiLocked(a,role));
 let status=a.players[r].down?'你暂时倒下了，TA 仍能继续。':locked?'你已选好。等 TA 一起出手。':'选一个动作，再点棋盘上的目标。';
 if(!locked&&b.locked[other])status='TA 已选好，轮到你接招。';
 if(step?.ok===false&&own)status=step.text||'这一招目前做不到，可以撤回重选。';
 return `<section class="board-ready" aria-label="双人行动"><div class="board-ready-pair">${ROLES.map(role=>{const p=a.players[role],ready=boardUiLocked(a,role),action=b.queues[role]?.[0];return `<div class="board-ready-person ${ready?'is-ready':''} ${role===r?'is-you':''}"><span class="board-ready-dot" aria-hidden="true">${p.down?'—':ready?'好':'…'}</span><div><small>${esc(p.name)}${role===r?' · 你':''}</small><strong>${p.down?'暂时倒下':esc(boardUiAction(a,action))}</strong></div></div>`;}).join('')}</div><div class="board-ready-bottom"><p class="${step?.ok===false?'board-warning':''}" role="status">${esc(status)}</p>${locked&&!a.players[r].down&&!both?button('撤回重选','adv','data-type="boardUnlock"','secondary small'):''}</div></section>`;
}
function boardUiSkills(a,r){
 const c=a.combat,b=c.board,p=a.players[r],locked=boardUiLocked(a,r),chosen=boardUiSkill(a,r),skills=p.skills.map(findSkill).filter(Boolean);
 return `<details class="board-more" ${ui.boardMore?'open':''}><summary>换个招式 <span>${esc(findSkill(chosen)?.name||'暂时没有可用招式')} · ${p.energy} 能量<br><small>余力自动护盾</small></span></summary><div class="board-skill-list">${skills.map(sk=>{const unavailable=locked||p.energy<(sk.cost||0)||p.cd[sk.id]>0||(sk.oncePerTurn&&p.used?.[sk.id])||p.status.stun;return `<button class="board-skill ${sk.id===chosen?'is-selected':''}" data-action="tacticalSkill" data-skill="${sk.id}" aria-pressed="${sk.id===chosen}" ${unavailable?'disabled':''}><span class="board-skill-top"><b>${esc(sk.name)}</b><small>${sk.cost||0} 能量${p.cd[sk.id]>0?' · 冷却 '+p.cd[sk.id]:''}</small></span><span>${esc(sk.desc)}${sk.effects?.some(e=>e.op==='energy')?' 剩余能量自动变护盾。':''}</span></button>`;}).join('')}<button class="board-skill" data-action="tacticalGuard" ${locked||p.energy<1||p.status.stun?'disabled':''}><span class="board-skill-top"><b>护住自己</b><small>1 能量</small></span><span>自己获得 6 护盾；紧挨着的旅伴也获得 3 护盾。</span></button></div>${a.bondSkills.length?`<div class="board-bond"><span>共鸣 · ${c.spark} 星火</span>${a.bondSkills.map(id=>{const sk=findSkill(id);return button(esc(sk.name)+' · '+sk.bondCost,'adv',`data-type="useSkill" data-skill="${id}" ${boardUiSkillAim(sk).enemy?`data-target="${ui.target}"`:""} ${locked||c.bondUsed||c.spark<sk.bondCost||p.status.stun?'disabled':''}`,'small secondary');}).join('')}</div>`:''}</details>`;
}
function boardCombatView(a,r){
 boardUiSetup(a,r);const c=a.combat,b=c.board,p=a.players[r],tool=boardUiTool(),locked=boardUiLocked(a,r),skill=boardUiSkill(a,r),sk=findSkill(skill),aim=boardUiSkillAim(sk),preview=boardPreview(a),foes=c.enemies.filter(e=>e.hp>0),target=foes.find(e=>e.uid===ui.target)||foes[0];const intent=target?(b.threats.find(t=>t.enemy===target.uid)?.intent||enemyIntent(a,target)):null,next=p.cls==='seer'&&target?enemyIntent(a,target,1):null;
 const tip=locked?'想换一招？趁 TA 还没出手，可以撤回。':tool==='move'?'点空格走过去；标红的地方，等会儿会挨打。':tool==='push'?'点直线两格内的怪，把它往机关里推。':aim.enemy?`${sk?sk.name+'：':''}点棋盘上的怪物，就把这招交给它。`:`${sk?sk.name+'：':''}按“出招”给${aim.who}施放，也可点对应的己方格。`;
 const disabled=locked||p.status.stun,mustWait=p.status.stun||(!sk&&p.energy<1),pushPreview=tool==='push'&&!locked&&!p.status.stun?boardUiPushPreview(a,r,target):null;
 return `<div class="tactical-combat"><div class="board-title"><div><div class="chapter-kicker">一起出手 · 第 ${c.turn} 回合</div><h2>你一招，我接上。</h2></div><span class="board-round-tag">${c.tier==='boss'?'首领战':'双人连锁'}</span></div>${localSwitcher()}<div class="board-showcase">${battleStage(a)}<p class="board-stage-note">演出舞台 · 在下方棋盘出招</p></div><section class="board-arena" aria-label="机关棋盘"><div class="board-arena-top"><span><i class="board-danger-key" aria-hidden="true">!</i> 红格是敌人这轮要打的地方</span><details class="board-rules"><summary aria-label="查看棋盘规则">规则</summary><div class="board-rule-pop"><p>每人选一招，双方选好就一起出手。走位先结算，再推怪，最后使用技能。</p><p>双方行动后，每剩余 1 点能量自动转成 3 护盾，再清空能量。</p><p>走位最多 2 格；直线 2 格内可以推怪。职业技能不限棋盘距离。</p><p>撞墙或撞人：4 伤害。陷阱：8 伤害并眩晕。油地：被推时多滑一格。炸桶：8 伤害，也会炸到旁边的自己人。</p></div></details></div>${mustWait&&!p.down?`<div class="board-stunned"><span>${p.status.stun?'头还有点晕，这轮先稳住。':'没力气了，缓一轮再接着来。'}</span><button type="button" class="btn" data-action="tacticalWait" ${locked?'disabled':''}>稳住这一轮</button></div>`:`<div class="board-tools" role="group" aria-label="选择动作">${[['attack','出招',classIcon[p.cls]||'sword',sk?.cost||0],['push','推怪','arrow',1],['move','走位','people',1]].map(([key,label,art,cost])=>{const unavailable=disabled||p.energy<cost||(key==='attack'&&(!sk||p.cd[sk.id]>0));return `<button type="button" id="board-tool-${key}" class="board-tool ${tool===key?'is-active':''}" data-action="tacticalTool" data-tool="${key}" aria-pressed="${tool===key}" ${unavailable?'disabled':''}>${icon(art)}<span><b>${label}</b><small>${key==='attack'?aim.label:key==='push'?'点怪物':'点空格'}</small></span></button>`;}).join('')}</div><p class="board-tool-hint" role="status">${esc(ui.boardTip||tip)}</p>`}${pushPreview?`<p class="board-push-preview">${esc(pushPreview.text)}</p>`:''}<div class="tactical-board" role="group" aria-label="五列四行棋盘">${Array.from({length:b.height},(_,y)=>Array.from({length:b.width},(_,x)=>boardUiCell(a,r,x,y,preview,pushPreview)).join('')).join('')}</div><div class="board-target-info">${tool==='attack'&&sk&&!aim.enemy?`<span>作用于：<b>${esc(aim.who)}</b> · ${esc(sk.name)}</span>`:target?`<span>目标：<b>${esc(target.name)}</b> · ${target.hp}/${target.maxhp} 生命${target.block?' · '+target.block+' 护盾':''}</span><span>${statusChips(target.status)}</span><span class="board-target-intent">意图：${esc(intent?.text||intentLabel(intent||{}))}${next?' · 随后：'+esc(next.text||intentLabel(next)):''}</span>`:''}</div></section>${boardUiCommit(a,r,preview)}${boardUiSkills(a,r)}<details class="board-more board-extra"><summary>双人即兴与怪物破绽 <span>每场一次的小配合</span></summary>${boardUiTactics(a,r)}</details>${b.last?.length?`<details class="board-more board-report"><summary>刚才发生了什么 <span>${b.last.length} 条战况</span></summary><div>${b.last.map(row=>`<p>${esc(typeof row==='string'?row:row.text||'')}</p>`).join('')}</div></details>`:''}</div>`;
}
function boardUiSend(action){const a=S.adv,r=session.role;if(action.type==='boardQueue'&&action.kind!=='wait'){const check=clone(a);check.combat.board.queues[r]=[action];const step=boardPreview(check).steps.find(s=>s.role===r);if(step?.ok===false){const solo=clone(a);solo.combat.ended[r]=false;const current=boardRunAction(solo,r,action);if(!current.ok){toast(current.text||step.text||'这一步行不通，换个目标试试。');return;}}}dispatch({type:'adv',a:action});}
document.addEventListener('click',event=>{
 const el=event.target.closest('[data-action]');if(!el||el.disabled||!['tacticalTool','tacticalCell','tacticalSkill','tacticalGuard','tacticalWait'].includes(el.dataset.action)||document.getElementById('dialog')?.open)return;
 const a=S.adv;if(ui.screen!=='play'||S.mode!=='adventure'||a?.phase!=='combat'||!a.combat?.board)return;const r=session.role,p=a.players[r];
 if(boardUiLocked(a,r)){toast('你已选好，先撤回才能换一招。');return;}
 if(session.kind==='online'&&!net.connected){toast('连上旅伴后，再一起出手。');return;}
 const d=el.dataset;ui.boardTip='';if(d.action==='tacticalWait'){boardUiSend({type:'boardQueue',kind:'wait'});return;}if(p.status.stun){toast('这轮先稳住，下一轮再出招。');return;}
 if(d.action==='tacticalTool'){ui.boardTool=d.tool;const skill=boardUiSkill(a,r);if(d.tool==='attack'&&skill&&!boardUiSkillAim(findSkill(skill)).enemy){boardUiSend({type:'boardQueue',kind:'skill',skill});return;}render();document.getElementById('board-tool-'+d.tool)?.focus({preventScroll:true});return;}
 if(d.action==='tacticalSkill'){ui.boardSkill=d.skill;ui.boardTool='attack';ui.boardMore=false;render();document.getElementById('board-tool-attack')?.focus({preventScroll:true});document.querySelector('.board-arena')?.scrollIntoView({block:'nearest',behavior:'smooth'});return;}
 if(d.action==='tacticalGuard'){boardUiSend({type:'boardQueue',kind:'guard'});return;}
 const x=Number(d.x),y=Number(d.y),key=boardAt(a,x,y),enemy=a.combat.enemies.find(e=>e.uid===key&&e.hp>0),tool=boardUiTool(),skill=boardUiSkill(a,r),aim=boardUiSkillAim(findSkill(skill));
 if(tool==='attack'&&skill&&!aim.enemy){if(boardUiRecipient(aim,r,key))boardUiSend({type:'boardQueue',kind:'skill',skill});else toast('这招给'+aim.who+'，按“出招”或点对应的己方格。');return;}if(enemy)ui.target=enemy.uid;
 if(tool==='move'){
  if(key||a.combat.board.tiles.some(t=>t.x===x&&t.y===y&&t.kind==='wall')){toast('这里站不下，换个空格。');return;}
  boardUiSend({type:'boardQueue',kind:'move',x,y});
 }else if(!enemy){toast(tool==='push'?'点一下你想推的怪物。':'点一个怪物，把这一招排进去。');}
 else if(tool==='push')boardUiSend({type:'boardQueue',kind:'push',target:enemy.uid});
 else{const skill=boardUiSkill(a,r);if(!skill){toast('这轮没有可用招式，试试走位或推怪。');return;}boardUiSend({type:'boardQueue',kind:'skill',skill,target:enemy.uid});}
});
document.addEventListener('toggle',event=>{if(event.target.matches?.('.board-more:not(.board-extra):not(.board-report)'))ui.boardMore=event.target.open;},true);
