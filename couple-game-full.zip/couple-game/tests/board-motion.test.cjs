'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const assert = require('node:assert/strict');
const {test} = require('node:test');

const root = path.join(__dirname, '..');
function fixture() {
 const context = {console, Math, Date: class extends Date {static now() {return 1000;}}};
 context.window = context;
 vm.createContext(context);
 for (const file of ['data/core.js', 'data/corpus.js', 'data/minigames.js', 'data/rules-copy.js', 'data/full-story.js', 'data/continuity.js', 'data/combat-cast.js', 'engine.js', 'battle-tactics.js', 'combat-director.js', 'tactical-board.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, {filename: file});
 }
 const run = code => vm.runInContext(code, context);
 run(`var S={players:{host:{name:'一'},guest:{name:'二'}}};var a=advInit(72);
  for(const [role,cls] of [['host','blade'],['guest','weaver']]){
   advReduce(a,{type:'pickClass',cls},role);advReduce(a,{type:'ready'},role,S.players);
  }
  genMap(a);combatStart(a,['siren'],'boss');
  a.combat.board.positions={host:{x:0,y:3},guest:{x:4,y:3},e0:{x:4,y:0}};
  a.combat.board.tiles=[];a.combat.board.threats=[];
  a.combat.enemies[0].hp=500;a.combat.enemies[0].maxhp=500;
  for(const role of ROLES){a.players[role].block=0;a.players[role].status={};}
  a.combat.presentation.events=[];a.combat.presentation.seq=0;a.combat.presentation.transcript=[];
 `);
 return {run, json: code => JSON.parse(run(`JSON.stringify(${code})`))};
}
function action(h, role, value) {
 return h.json(`boardRunAction(a,${JSON.stringify(role)},${JSON.stringify(value)})`);
}
function queue(h, role, value) {
 h.run(`advReduce(a,${JSON.stringify({type:'boardQueue', ...value})},${JSON.stringify(role)},S.players)`);
}
function events(h) {return h.json('a.combat.presentation.events');}
function pushArena(h, landing) {
 h.run(`a.combat.board.positions={host:{x:0,y:1},guest:{x:4,y:3},e0:{x:1,y:1}};
  a.combat.board.tiles=${JSON.stringify(landing)};`);
}

test('走两格逐格发出移动事件，每次落地先移动再受火焰伤害', () => {
 const h = fixture();
 h.run(`a.combat.board.tiles=[{kind:'fire',x:0,y:2,ttl:2,owner:'guest'},{kind:'fire',x:0,y:1,ttl:2,owner:'guest'}];`);
 const before = h.run('a.players.host.hp');
 assert.equal(action(h, 'host', {kind:'move', x:0, y:1}).ok, true);
 const list = events(h);
 assert.deepEqual(list.map(e => e.type), ['move', 'hit', 'move', 'hit']);
 assert.deepEqual(list.filter(e => e.type === 'move').map(e => ({actor:e.actor, from:e.from, to:e.to, path:e.path, motion:e.motion})), [
  {actor:'host', from:{x:0,y:3}, to:{x:0,y:2}, path:[{x:0,y:2}], motion:'walk'},
  {actor:'host', from:{x:0,y:2}, to:{x:0,y:1}, path:[{x:0,y:1}], motion:'walk'}
 ]);
 assert.deepEqual(list.filter(e => e.type === 'hit').map(e => e.value), [6, 6]);
 assert.equal(h.run('a.players.host.hp'), before - 12);
 assert.equal(h.run('a.players.host.energy'), 2, 'A two-cell walk still costs only one energy');
});

test('途中火焰致命时停在受伤格，不再播放尚未走到的下一格', () => {
 const h = fixture();
 h.run(`a.players.host.hp=4;a.combat.board.tiles=[{kind:'fire',x:0,y:2,ttl:2}];`);
 action(h, 'host', {kind:'move', x:0, y:1});
 assert.deepEqual(events(h).map(e => e.type), ['move', 'hit', 'down']);
 assert.deepEqual(h.json('a.combat.board.positions.host'), {x:0,y:2});
 assert.equal(h.run('a.players.host.down'), true);
 assert.equal(h.run('a.players.host.energy'), 2);
});

test('推上油地再滑进陷阱，推和滑两段事件都先于陷阱命中', () => {
 const h = fixture();
 pushArena(h, [{kind:'oil',x:2,y:1}, {kind:'trap',x:3,y:1,owner:'guest'}]);
 action(h, 'host', {kind:'push', target:'e0'});
 const list = events(h), moves = list.filter(e => e.type === 'move');
 assert.deepEqual(list.map(e => e.type), ['attack', 'move', 'move', 'hit', 'say']);
 assert.deepEqual(moves.map(e => ({actor:e.actor, from:e.from, to:e.to, motion:e.motion, source:e.source})), [
  {actor:'e0', from:{x:1,y:1}, to:{x:2,y:1}, motion:'push', source:'host'},
  {actor:'e0', from:{x:2,y:1}, to:{x:3,y:1}, motion:'slide', source:'host'}
 ]);
 assert.equal(list[3].value, 8);
 assert.equal(h.run('a.combat.enemies[0].hp'), 492);
 assert.equal(h.run('a.combat.enemies[0].status.stun'), 1);
 assert.equal(h.run('a.combat.board.tiles.some(t=>t.kind==="trap")'), false);
 assert.equal(h.run('a.players.host.energy'), 2);
});

test('撞墙只播放碰撞再命中，不伪造移动或改变站位', () => {
 const h = fixture();
 pushArena(h, [{kind:'wall',x:2,y:1}]);
 action(h, 'host', {kind:'push', target:'e0'});
 const list = events(h);
 assert.deepEqual(list.map(e => e.type), ['attack', 'bump', 'hit']);
 assert.deepEqual({actor:list[1].actor, from:list[1].from, to:list[1].to, direction:list[1].direction, source:list[1].source},
  {actor:'e0', from:{x:1,y:1}, to:{x:1,y:1}, direction:{x:1,y:0}, source:'host'});
 assert.deepEqual(h.json('a.combat.board.positions.e0'), {x:1,y:1});
 assert.equal(list[2].value, 4);
 assert.equal(h.run('a.combat.enemies[0].hp'), 496);
 assert.equal(h.run('a.players.host.energy'), 2);
});

test('敌人前进也先记录移动，再记录落地陷阱伤害', () => {
 const h = fixture();
 h.run(`a.combat.board.positions={host:{x:2,y:3},guest:{x:4,y:3},e0:{x:2,y:0}};
  a.combat.board.tiles=[{kind:'trap',x:2,y:1,owner:'host'}];boardEnemyRound(a);`);
 const list = events(h);
 assert.deepEqual(list.map(e => e.type), ['move', 'hit', 'say']);
 assert.deepEqual({actor:list[0].actor, from:list[0].from, to:list[0].to, motion:list[0].motion},
  {actor:'e0', from:{x:2,y:0}, to:{x:2,y:1}, motion:'enemy'});
 assert.equal(list[1].value, 8);
 assert.equal(h.run('a.combat.enemies[0].hp'), 492);
 assert.equal(h.run('a.combat.enemies[0].status.stun'), 1);
 assert.equal(h.run('a.combat.turn'), 2);
});

test('破盾标记仅表示护盾耗尽，完全格挡和穿盾伤害仍保留原数值规则', () => {
 for (const row of [
  {block:3, damage:5, hpLoss:2, remaining:0, broken:true},
  {block:3, damage:3, hpLoss:0, remaining:0, broken:true},
  {block:3, damage:1, hpLoss:0, remaining:2, broken:false},
  {block:0, damage:5, hpLoss:5, remaining:0, broken:false},
  {block:3, damage:5, piercing:true, hpLoss:5, remaining:3, broken:false}
 ]) {
  const h = fixture();
  h.run(`a.combat.enemies[0].block=${row.block};boardDamage(a,'e0',${row.damage},'host',${!!row.piercing});`);
  const hit = events(h).find(e => e.type === 'hit');
  assert.equal(hit.shieldBreak, row.broken, JSON.stringify(row));
  assert.equal(hit.value, row.hpLoss);
  assert.equal(hit.blocked, row.block - row.remaining);
  assert.equal(h.run('a.combat.enemies[0].hp'), 500 - row.hpLoss);
  assert.equal(h.run('a.combat.enemies[0].block'), row.remaining);
 }
});

test('事件保留动作发生时的站位快照，后续移动和存档重载不会改写历史', () => {
 const h = fixture();
 pushArena(h, [{kind:'oil',x:2,y:1}]);
 action(h, 'host', {kind:'push', target:'e0'});
 const list = events(h);
 assert.deepEqual(list.map(e => e.positions.e0), [{x:1,y:1}, {x:2,y:1}, {x:3,y:1}]);
 assert.deepEqual(list.map(e => e.seq), [1, 2, 3]);
 h.run(`a.combat.board.positions.e0.x=4;a.combat.board.positions.host.y=2;`);
 assert.deepEqual(events(h), list, 'Historical positions must not share live position objects');
 h.run('a=JSON.parse(JSON.stringify(a))');
 assert.deepEqual(events(h), list);
});

test('包含位移、火伤和技能随机数的重复预览，不污染真实演出队列或 RNG', () => {
 const h = fixture();
 h.run(`a.combat.board.tiles=[{kind:'fire',x:0,y:2,ttl:2,owner:'guest'}];
  a.combat.board.queues.host=[{kind:'move',x:0,y:1}];
  a.combat.board.queues.guest=[{kind:'skill',skill:'weaver_thornstitch',target:'e0'}];`);
 const before = h.run('JSON.stringify(a)'), first = h.json('boardPreview(a)'), second = h.json('boardPreview(a)');
 assert.deepEqual(first, second);
 assert.deepEqual(first.board.positions.host, {x:0,y:1});
 assert.equal(first.players.host.hp, h.run('a.players.host.hp') - 6);
 assert.equal(first.enemies[0].hp, 495);
 assert.equal(h.run('JSON.stringify(a)'), before);
 assert.equal(h.run('battleCapture'), null);
});

test('开关演出事件不影响自动结算的生命、能量、状态、回合、随机数或奖励', () => {
 const live = fixture(), muted = fixture();
 for (const h of [live, muted]) {
  pushArena(h, [{kind:'oil',x:2,y:1}, {kind:'trap',x:3,y:1,owner:'host'}]);
  h.run('boardForecast(a);');
 }
 muted.run('battleEmit=function(){return null;};');
 for (const h of [live, muted]) {
  queue(h, 'host', {kind:'push',target:'e0'});
  queue(h, 'guest', {kind:'skill',skill:'weaver_thornstitch',target:'e0'});
 }
 assert.ok(events(live).some(e => e.type === 'move'));
 assert.equal(events(muted).length, 0);
 const state = h => h.json('(()=>{const value=clone(a);delete value.combat.presentation;return value;})()');
 assert.deepEqual(state(live), state(muted));
 assert.equal(live.run('a.combat.enemies[0].hp'), 484, 'Trap 8 + skill 5 + push-to-partner relay 3');
 assert.equal(live.run('a.combat.turn'), 2);
 assert.equal(live.run('a.combat.enemies[0].status.stun'), 0);
});
