const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..');
const clone = value => JSON.parse(JSON.stringify(value));
function load() {
  const context = { console, Date, Math, interludeView() { return ''; }, prose() { return ''; } };
  context.window = context;
  vm.createContext(context);
  for (const file of [
    'data/core.js', 'data/corpus.js', 'data/minigames.js', 'data/rules-copy.js',
    'data/full-story.js', 'data/continuity.js', 'engine.js', 'data/lively-city.js'
  ]) vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, { filename: file });
  const before = clone(context.GAME_DATA.npcs);
  vm.runInContext(fs.readFileSync(path.join(root, 'data/npc-voices-scholar.js'), 'utf8'), context);
  return { context, before, after: clone(context.GAME_DATA.npcs) };
}
const fixture = load();
function structure(npcs) {
  const copy = clone(npcs);
  for (const npc of copy) for (const meeting of npc.meetings) for (const node of Object.values(meeting.nodes)) {
    delete node.text;
    for (const choice of node.choices || []) {
      delete choice.label;
      delete choice.hint;
    }
  }
  return copy;
}
function start(context, npcId, act, node, bond = 100) {
  vm.runInContext(`
    var a=advInit(7123);
    advReduce(a,{type:'pickClass',cls:'blade'},'host');
    advReduce(a,{type:'pickClass',cls:'seer'},'guest');
    advReduce(a,{type:'ready'},'host');
    advReduce(a,{type:'ready'},'guest');
  `, context);
  context.a.act = act;
  context.a.bond = bond;
  context.enterNode(context.a, { id: 'scholar-test', type: 'npc', npcId });
  context.a.npc.node = node;
  return context.a;
}
function choose(context, index) {
  context.advReduce(context.a, { type: 'npcChoice', idx: index }, 'host');
  context.advReduce(context.a, { type: 'npcChoice', idx: index }, 'guest');
}

test('78 dialogue revisions preserve all 213 nodes, conditions, effects and other NPCs', () => {
  const { context, before, after } = fixture;
  const count = npcs => npcs.reduce((total, npc) => total + npc.meetings.reduce((sum, meeting) => sum + Object.keys(meeting.nodes).length, 0), 0);
  assert.equal(count(before), 213);
  assert.equal(count(after), 213);
  assert.deepEqual(structure(after), structure(before));
  assert.equal(context.NPC_SCHOLAR_REVISION.nodes, 78);
  assert.deepEqual(after.filter(npc => !['quill', 'quiet'].includes(npc.id)), before.filter(npc => !['quill', 'quiet'].includes(npc.id)));
  let revised = 0;
  for (const npc of after.filter(npc => ['quill', 'quiet'].includes(npc.id))) {
    for (const meeting of npc.meetings) for (const [id, node] of Object.entries(meeting.nodes)) {
      const original = before.find(item => item.id === npc.id).meetings.find(item => item.act === meeting.act).nodes[id];
      assert.notEqual(node.text, original.text, `${npc.id}/${meeting.act}/${id} must be revised`);
      assert.deepEqual(clone(context.NPC_SCHOLAR_ORIGINALS[npc.id][meeting.act][id]), original);
      assert.deepEqual(node.text.match(/\{CITY:[^}]+\}/g), original.text.match(/\{CITY:[^}]+\}/g));
      assert.ok(node.text.trim().length > 40);
      assert.ok(node.choices.every(choice => choice.label.trim().length > 0));
      revised++;
    }
  }
  assert.equal(revised, 78);
});

test('every revised branch resolves within its act and can reach a dialogue exit', () => {
  for (const npc of fixture.after.filter(npc => ['quill', 'quiet'].includes(npc.id))) {
    for (const meeting of npc.meetings) {
      const reachable = new Set(['start']);
      const pending = ['start'];
      while (pending.length) {
        const id = pending.shift();
        for (const choice of meeting.nodes[id].choices) {
          if (!choice.next) continue;
          assert.ok(meeting.nodes[choice.next], `${npc.id}/${meeting.act}/${id} references ${choice.next}`);
          if (!reachable.has(choice.next)) { reachable.add(choice.next); pending.push(choice.next); }
        }
      }
      assert.equal(reachable.size, Object.keys(meeting.nodes).length);
      const exits = new Set(Object.entries(meeting.nodes).filter(([, node]) => !node.choices.length || node.choices.some(choice => !choice.next)).map(([id]) => id));
      let changed = true;
      while (changed) {
        changed = false;
        for (const [id, node] of Object.entries(meeting.nodes)) if (!exits.has(id) && node.choices.some(choice => exits.has(choice.next))) {
          exits.add(id); changed = true;
        }
      }
      assert.equal(exits.size, Object.keys(meeting.nodes).length, `${npc.id}/${meeting.act} contains a dead-end cycle`);
    }
  }
});

test('name trade still requires both players and keeps its permanent consequence', () => {
  const { context } = load();
  const a = start(context, 'quiet', 2, 'mirror_offer', 60);
  context.advReduce(a, { type: 'npcChoice', idx: 1 }, 'host');
  assert.equal(a.npc.node, 'mirror_offer');
  assert.equal(a.flags.includes('name_sold'), false);
  context.advReduce(a, { type: 'npcChoice', idx: 1 }, 'guest');
  assert.equal(a.npc.node, 'sacrifice_name');
  assert.equal(a.bond, 55);
  assert.equal(a.flags.includes('name_sold'), true);
  assert.equal(a.flags.includes('quiet_tested'), true);
  const gold = a.gold;
  choose(context, 1);
  assert.equal(a.gold, gold + 5);
  assert.equal(a.npc.ended, true);
  choose(context, 1);
  assert.equal(a.gold, gold + 5, 'terminal dialogue cannot grant the payment twice');
});

test('face and family revelations retain their bond and prior-trust gates', () => {
  const { context } = load();
  let a = start(context, 'quiet', 3, 'quiet_remember', 79);
  choose(context, 0);
  assert.equal(a.npc.node, 'quiet_remember');
  a.bond = 80;
  choose(context, 0);
  assert.equal(a.npc.node, 'quiet_open_face');
  assert.equal(a.flags.includes('quiet_open'), true);
  a = start(context, 'quiet', 3, 'quiet_remember', 60);
  choose(context, 2);
  assert.equal(a.npc.node, 'quiet_remember');
  a.flags.push('holt_trust');
  choose(context, 2);
  assert.equal(a.npc.node, 'quiet_holt_link');
  choose(context, 2);
  assert.equal(a.npc.node, 'quiet_end_memory');
  assert.equal(a.flags.includes('memory_zero'), true);
  const quiet = fixture.after.find(npc => npc.id === 'quiet');
  for (const meeting of quiet.meetings.filter(meeting => meeting.act < 3)) for (const node of Object.values(meeting.nodes)) {
    assert.doesNotMatch(node.text, /赫尔特|祖父|孙子|年轻的脸/);
  }
});

test('the half embroidery clue is encountered before any act-two quiet_open branch', () => {
  const meeting = fixture.after.find(npc => npc.id === 'quiet').meetings.find(meeting => meeting.act === 2);
  const clue = 'mirror_offer';
  assert.match(meeting.nodes[clue].text, /半截绣字/);
  assert.match(meeting.nodes[clue].text, /卷宗/);
  // A quiet_open choice either enters the clue immediately, or is only reachable
  // after that node. This verifies the cross-NPC clue, rather than a copy snapshot.
  const withoutClue = new Set(['start']);
  const pending = ['start'];
  while (pending.length) {
    const id = pending.shift();
    for (const choice of meeting.nodes[id].choices) {
      if ((choice.effects || []).some(effect => effect.op === 'flag' && effect.k === 'quiet_open')) {
        assert.equal(choice.next, clue, `quiet_open can be set without receiving the clue at ${id}`);
      }
      if (choice.next && choice.next !== clue && !withoutClue.has(choice.next)) {
        withoutClue.add(choice.next); pending.push(choice.next);
      }
    }
  }
});

test('the site loads the revision after city callbacks are installed', () => {
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  const scripts = [...html.matchAll(/<script[^>]+src="([^"]+)"/g)].map(match => match[1].split('?')[0]);
  assert.equal(scripts.filter(file => file === 'data/npc-voices-scholar.js').length, 1);
  assert.ok(scripts.indexOf('data/npc-voices-scholar.js') > scripts.indexOf('data/lively-city.js'));
});
