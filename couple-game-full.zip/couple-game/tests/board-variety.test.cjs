'use strict';
const fs = require('node:fs'), vm = require('node:vm'), path = require('node:path');
const assert = require('node:assert/strict');
const {test} = require('node:test');
const root = path.join(__dirname, '..');
function fixture(seed = 72) {
 const x = {console, Math, Date};x.window=x;vm.createContext(x);
 for(const file of ['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','data/combat-cast.js','engine.js','battle-tactics.js','combat-director.js','tactical-board.js']) {
  vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),x,{filename:file});
 }
 const run=code=>vm.runInContext(code,x);
 run(`var a=advInit(${seed});var names={host:{name:'甲'},guest:{name:'乙'}};
  for(const [role,cls] of [['host','blade'],['guest','weaver']]){advReduce(a,{type:'pickClass',cls},role);advReduce(a,{type:'ready'},role,names);}
  genMap(a);a.map.cur='f8n1';`);
 return {run,json:code=>JSON.parse(run('JSON.stringify('+code+')'))};
}
function start(h,count=1) {h.run(`combatStart(a,${JSON.stringify(Array(count).fill('fog_fisherman'))},'normal')`);return h.json('a.combat.board');}
function identity(b) {return {theme:b.theme,positions:b.positions,tiles:b.tiles};}

test('旅程首战沿用练习布局，后续三种布局确定轮换且有独立机关结构',()=>{
 const h=fixture(),boards=Array.from({length:7},()=>start(h));
 assert.equal(new Set(boards.slice(0,4).map(b=>b.theme)).size,4,'Four different boards must appear across the first four encounters');
 assert.equal(new Set(boards.slice(0,4).map(b=>JSON.stringify(b.tiles))).size,4,'Names alone must not stand in for distinct terrain');
 assert.deepEqual(boards.slice(4).map(identity),boards.slice(1,4).map(identity));
 for(const b of boards){assert.ok(typeof b.label==='string'&&b.label.length>0);assert.ok(typeof b.hint==='string'&&b.hint.length>0&&b.hint.length<=50);}
 assert.deepEqual(boards[0].positions.e0,{x:1,y:1});
 assert.ok(boards[0].tiles.some(t=>t.kind==='trap'&&t.x===1&&t.y===0));
});

test('练习和未进入地图的战斗不会更换默认布局或消耗正式战斗计数',()=>{
 const normal=fixture(),base=identity(start(normal));
 for(const mode of ['practice','unmapped']) {
  const h=fixture();h.run(`a.stats.kills=30;a.stats.boardBattles=9;${mode==='practice'?'a.practice=true;':'a.map.cur=null;'}`);
  for(let i=0;i<4;i++)assert.deepEqual(identity(start(h)),base,mode);
  assert.equal(h.run('a.stats.boardBattles'),9);
 }
});

test('四种布局的出生点不会重叠或落在墙桶上，所有角色都能走出至少一步',()=>{
 for(let layout=0;layout<4;layout++)for(const count of [1,2,5]) {
  const h=fixture();h.run(`a.stats.boardBattles=${layout}`);const b=start(h,count);
  assert.equal(b.width,5);assert.equal(b.height,4);
  assert.deepEqual(b.positions.host,{x:1,y:3});assert.deepEqual(b.positions.guest,{x:3,y:3});
  const occupied=new Set(),terrain=new Set();
  for(const t of b.tiles){assert.ok(t.x>=0&&t.x<5&&t.y>=0&&t.y<4);const key=t.x+','+t.y;assert.ok(!terrain.has(key),'Terrain may not overlap');terrain.add(key);}
  for(const [key,p] of Object.entries(b.positions)){
   assert.ok(p.x>=0&&p.x<5&&p.y>=0&&p.y<4,`${b.theme} ${key} is in bounds`);
   assert.ok(!occupied.has(p.x+','+p.y),`${b.theme} ${key} has a distinct spawn`);occupied.add(p.x+','+p.y);
   assert.ok(!b.tiles.some(t=>t.x===p.x&&t.y===p.y&&['wall','barrel'].includes(t.kind)),`${b.theme} ${key} is not on a wall or barrel`);
  }
  for(const [key,p] of Object.entries(b.positions)){
   const exits=[[0,-1],[1,0],[0,1],[-1,0]].map(([dx,dy])=>({x:p.x+dx,y:p.y+dy})).filter(q=>q.x>=0&&q.x<5&&q.y>=0&&q.y<4&&!occupied.has(q.x+','+q.y)&&!b.tiles.some(t=>t.x===q.x&&t.y===q.y&&['wall','barrel'].includes(t.kind)));
   assert.ok(exits.length>0,`${b.theme} ${count} enemies: ${key} must have a safe empty exit`);
  }
 }
});

test('布局可从序列化状态重复得到，不读取或推进战斗随机数',()=>{
 const h=fixture();h.run('a.stats.boardBattles=2;var saved=JSON.stringify(a);var rng=a.rngState;');
 const first=start(h);assert.equal(h.run('a.rngState'),h.run('rng'));
 h.run('a=JSON.parse(saved)');assert.deepEqual(start(h),first);assert.equal(h.run('a.rngState'),h.run('rng'));
});

test('重新读取已经开战的存档不会重建机关、移动角色或重置已提交动作',()=>{
 const h=fixture();start(h);
 h.run(`a.combat.board.tiles.pop();a.combat.board.positions.host={x:2,y:3};a.combat.board.queues.host=[{kind:'guard'}];a.combat.board.locked.host=true;
  delete a.combat.board.theme;delete a.combat.board.label;delete a.combat.board.hint;a.stats.boardBattles=99;
  a=JSON.parse(JSON.stringify(a));var saved=JSON.stringify(a);boardCreate(a);`);
 assert.equal(h.run('JSON.stringify(a)'),h.run('saved'));
});

test('没有新计数字段的旧旅程，下一场可进入新地图且保持敌人生命与伤害倍率',()=>{
 const fresh=fixture(),old=fixture();start(fresh);
 old.run('a.stats.kills=4;delete a.stats.boardBattles;');const b=start(old);
 assert.notEqual(b.theme,fresh.run('a.combat.board.theme'));
 assert.deepEqual(old.json('a.combat.enemies.map(e=>({hp:e.hp,maxhp:e.maxhp,dmgMul:e.dmgMul}))'),fresh.json('a.combat.enemies.map(e=>({hp:e.hp,maxhp:e.maxhp,dmgMul:e.dmgMul}))'));
});

test('新增布局提供真实的油滑陷阱、相邻桶连爆与左右两条推怪路线',()=>{
 const oil=fixture();oil.run('a.stats.boardBattles=1');start(oil);
 oil.run(`boardRunAction(a,'host',{kind:'push',target:'e0'});`);
 assert.deepEqual(oil.json('a.combat.board.positions.e0'),{x:1,y:0});
 assert.equal(oil.run('a.combat.enemies[0].status.stun'),1);
 assert.equal(oil.run('a.combat.enemies[0].maxhp-a.combat.enemies[0].hp'),8);
 assert.deepEqual(oil.json('a.combat.presentation.events.filter(e=>e.type==="move").map(e=>e.motion)'),['push','slide']);
 const barrels=fixture();barrels.run('a.stats.boardBattles=2');const initial=start(barrels,2),before=barrels.json('a.combat.enemies.map(e=>e.hp)');
 const barrelTiles=initial.tiles.filter(t=>t.kind==='barrel');assert.equal(barrelTiles.length,2);
 assert.equal(Math.abs(barrelTiles[0].x-barrelTiles[1].x)+Math.abs(barrelTiles[0].y-barrelTiles[1].y),1);
 barrels.run(`boardRunAction(a,'host',{kind:'push',target:'e0'});`);
 assert.equal(barrels.run('a.combat.board.tiles.filter(t=>t.kind==="barrel").length'),0);
 assert.equal(barrels.run('a.combat.enemies[0].hp'),before[0]-16);assert.equal(barrels.run('a.combat.enemies[1].hp'),before[1]-8);
 const split=fixture();split.run('a.stats.boardBattles=3');start(split,2);
 split.run(`boardRunAction(a,'host',{kind:'push',target:'e0'});boardRunAction(a,'guest',{kind:'push',target:'e1'});`);
 assert.deepEqual(split.json('a.combat.enemies.map(e=>e.status.stun)'),[1,1]);
 assert.deepEqual(split.json('[a.combat.board.positions.e0,a.combat.board.positions.e1]'),[{x:1,y:0},{x:3,y:0}]);
});
