const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),x={console,Math,Date,homeView:()=>'',lobbyView:()=>'',gameTop:()=>''};x.window=x;vm.createContext(x);
for(const file of ['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','data/combat-cast.js','engine.js','battle-tactics.js','combat-director.js','tactical-board.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),x);
assert.ok(fs.existsSync(path.join(root,'practice.js')),'Practice entry must exist without replacing the saved campaign');
vm.runInContext(fs.readFileSync(path.join(root,'practice.js'),'utf8'),x);
const run=s=>vm.runInContext(s,x);
run(`var before={version:3,revision:9,players:{host:{name:'甲'},guest:{name:'乙'}},mode:'adventure',adv:advInit(42),guess:null,draw:{strokes:[]}};var saved=JSON.stringify(before);var next=practiceState(before);`);
assert.equal(run('JSON.stringify(before)===saved'),true);assert.equal(run('next.adv.practice'),true);assert.equal(run('next.adv.phase'),'combat');assert.equal(run('next.adv.combat.board.width'),5);assert.equal(run('JSON.stringify(next.practiceReturn.adv)===JSON.stringify(before.adv)'),true);assert.equal(run('next.adv.players.host.name'),'甲');console.log('✓ Practice starts a playable board and preserves the original campaign');
