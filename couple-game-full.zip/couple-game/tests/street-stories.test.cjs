const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const files=['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','engine.js','R.js','narrative-ui.js','data/lively-city.js'];
const source=fs.readFileSync(path.join(root,'data/street-stories.js'),'utf8');
const plain=value=>JSON.parse(JSON.stringify(value));
function load(rewritten){
 const ctx={console,Date,Math};ctx.window=ctx;vm.createContext(ctx);
 for(const file of files)vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),ctx,{filename:file});
 if(rewritten)vm.runInContext(source,ctx,{filename:'data/street-stories.js'});
 vm.runInContext(`var S={players:{host:{name:'阿雨'},guest:{name:'小舟'}},adv:null};
 function fixture(id,choice,actor='host'){
  const event=GD().events.find(e=>e.id===id),cls=event.choices[choice].req?.cls||'blade';
  const second=cls==='weaver'?'blade':'weaver';
  const a=advInit(73013);
  advReduce(a,{type:'pickClass',cls:actor==='host'?cls:second},'host',S.players);
  advReduce(a,{type:'pickClass',cls:actor==='guest'?cls:second},'guest',S.players);
  advReduce(a,{type:'ready'},'host',S.players);advReduce(a,{type:'ready'},'guest',S.players);
  a.act=event.act[0];a.bond=75;a.gold=1000;
  for(const p of Object.values(a.players))p.hp=p.maxhp-20;
  S.adv=a;enterNode(a,{id:'event-fixture',type:'event',eventId:id});return a;
 }
 function settle(id,choice,roll,actor='host'){
  const a=fixture(id,choice,actor),oldRand=advRand;advRand=()=>roll;
  try{advReduce(a,{type:'eventChoice',idx:choice},'host');advReduce(a,{type:'eventChoice',idx:choice},'guest');}
  finally{advRand=oldRand;}
  return a;
 }`,ctx);
 return ctx;
}
const prior=load(false),current=load(true),run=(code,ctx=current)=>vm.runInContext(code,ctx);
const before=plain(prior.GAME_DATA),after=plain(current.GAME_DATA);
const ids=after.streetStories.ids;
let tests=0;
function test(label,fn){fn();tests++;console.log('✓ '+label);}
function mechanics(event){
 const copy=plain(event);delete copy.title;delete copy.text;
 for(const choice of copy.choices){delete choice.label;delete choice.hint;for(const outcome of choice.outcomes)delete outcome.text;}
 return copy;
}
function stateRules(state){
 const copy=plain(state);delete copy.event.resultText;
 for(const entry of copy.journal){delete entry.title;delete entry.choice;delete entry.text;}
 return copy;
}

test('12场街坊事件覆盖三幕各四场及每幕必经开场',()=>{
 assert.equal(ids.length,12);assert.equal(new Set(ids).size,12);
 assert.equal(after.events.length,before.events.length);
 for(let act=1;act<=3;act++)assert.equal(ids.filter(id=>id.startsWith('a'+act+'_')).length,4);
 for(const id of ['a1_0_keyecho','a2_0_mirror_smile','a3_0_stephabit'])assert.ok(ids.includes(id));
});

test('原稿完整保存，所有门槛、分支概率、奖励及未改事件保持原样',()=>{
 for(const event of after.events){
  const old=before.events.find(e=>e.id===event.id);
  if(!ids.includes(event.id)){assert.deepEqual(event,old);continue;}
  assert.deepEqual(after.streetStories.originals[event.id],old);
  assert.deepEqual(mechanics(event),mechanics(old));
  assert.notEqual(event.text,old.text);assert.notEqual(event.title,old.title);
  event.choices.forEach((choice,i)=>choice.outcomes.forEach((outcome,j)=>assert.notEqual(outcome.text,old.choices[i].outcomes[j].text)));
 }
 for(const key of Object.keys(before).filter(k=>k!=='events'))assert.deepEqual(after[key],before[key]);
});

let branches=0;
test('逐一执行全部结果：双人同意才结算，职业由任意一端持有都与旧机制等价',()=>{
 for(const id of ids){
  const event=after.events.find(e=>e.id===id);
  for(let i=0;i<event.choices.length;i++){
   const choice=event.choices[i];let cumulative=0;
   for(let j=0;j<choice.outcomes.length;j++){
    const outcome=choice.outcomes[j],roll=cumulative+(outcome.p||0)/2;cumulative+=outcome.p||0;
    for(const actor of ['host','guest']){
     const code=`settle(${JSON.stringify(id)},${i},${roll},${JSON.stringify(actor)})`;
     const expected=run(code,prior),actual=run(code);
     assert.equal(actual.event.done,true,id+':'+i+':'+j+':'+actor);
     assert.equal(actual.event.resultText,outcome.text);
     assert.equal(actual.journal.length,1);assert.equal(actual.journal[0].text,outcome.text);
     assert.deepEqual(stateRules(actual),stateRules(expected),id+':'+i+':'+j+':'+actor);
     run(`var settledState=JSON.stringify(S.adv);advReduce(S.adv,{type:'eventChoice',idx:${i}},'host');advReduce(S.adv,{type:'eventChoice',idx:${i}},'guest');`);
     assert.equal(run('JSON.stringify(S.adv)'),run('settledState'),'重复提交不得重复领取');
    }
    branches++;
   }
  }
 }
 run(`var a=fixture('a1_0_keyecho',0);advReduce(a,{type:'eventChoice',idx:0},'host');`);
 assert.equal(run('a.event.done'),false);assert.equal(run('a.journal.length'),0);
 run(`advReduce(a,{type:'eventChoice',idx:1},'guest');`);
 assert.equal(run('a.event.done'),false);
 run(`advReduce(a,{type:'eventChoice',idx:0},'guest');`);
 assert.equal(run('a.event.done'),true);
});

test('真实地图中每幕第一场可达，其他九场也都能抽到',()=>{
 const seen=new Set();
 for(let seed=1;seed<=160;seed++)for(let act=1;act<=3;act++){
  const map=run(`var route=advInit(${seed});route.act=${act};genMap(route);route.map.floors`);
  assert.ok(ids.includes(map[0][0].eventId));assert.equal(map[0][0].main,true);
  for(const node of map.flat())if(ids.includes(node.eventId))seen.add(node.eventId);
 }
 assert.deepEqual([...seen].sort(),[...ids].sort());
});

test('街坊回调仅由真实经历触发，不泄露占位符，羁绊提示写明实际门槛',()=>{
 run(`var a=fixture('a1_4_fish',0);a.flags=[];`);
 for(const id of ids){
  const event=after.events.find(e=>e.id===id);
  const rendered=run(`advText(${JSON.stringify(event.text)})`);assert.equal(rendered.includes('{CITY:'),false);
  for(const choice of event.choices)if(choice.req?.bondMin)assert.ok(choice.hint.includes('≥ '+choice.req.bondMin),id+':'+choice.label);
 }
 run(`a.flags=['city_fish_cakes'];`);
 assert.ok(run('advText(GD().events.find(e=>e.id==="a1_4_fish").text)').includes('鱼饼师傅'));
 run('a=JSON.parse(JSON.stringify(a));S.adv=a;');
 assert.ok(run('advText(GD().events.find(e=>e.id==="a1_4_fish").text)').includes('鱼饼师傅'));
 run('a.flags=[];');assert.equal(run('advText(GD().events.find(e=>e.id==="a1_4_fish").text)').includes('鱼饼师傅'),false);
});

test('重载不会覆盖原稿快照、叠加文字或多包一层结算',()=>{
 const saved=JSON.stringify(current.GAME_DATA);vm.runInContext(source,current);
 assert.equal(JSON.stringify(current.GAME_DATA),saved);
});

const introductions=ids.map(id=>after.events.find(e=>e.id===id).text.length);
const outcomes=after.events.filter(e=>ids.includes(e.id)).flatMap(e=>e.choices.flatMap(c=>c.outcomes.map(o=>o.text.length)));
console.log(`${tests} street story tests passed; ${ids.length} events, ${branches} outcomes, ${branches*2} role permutations.`);
console.log(`Text lengths: openings ${Math.min(...introductions)}–${Math.max(...introductions)}, outcomes ${Math.min(...outcomes)}–${Math.max(...outcomes)} characters.`);
