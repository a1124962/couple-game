const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { test } = require('node:test');

function harness() {
  const source = fs.readFileSync(path.join(__dirname, '../app.js'), 'utf8');
  const start = source.indexOf('function setupPeer(');
  const end = source.indexOf('\nfunction ', start + 1);
  let clock = 0, timerId = 0;
  const timers = new Map(), peers = [], reconnects = [], saves = [];
  const x = {
    console,
    net: { generation: 1, connected: false, busy: false, code: '', status: '', hostRestoreAttempts: 0 },
    ui: { screen: 'play' },
    peerOptions: () => ({}), render() {}, toast() {}, wire() {},
    save() { saves.push(x.net.code); },
    setTimeout(fn, ms) { const id = ++timerId; timers.set(id, { fn, at: clock + ms }); return id; },
    clearTimeout(id) { timers.delete(id); },
    Peer: class extends EventEmitter {
      constructor(id) { super(); this.id = id; this.destroyed = false; this.disconnected = false; peers.push(this); }
      destroy() {
        if (this.destroyed) return;
        // PeerJS destroy() calls disconnect() before setting _destroyed.
        // Faithfully retain that event order to catch reconnection of retired peers.
        if (!this.disconnected) { this.disconnected = true; this.emit('disconnected'); }
        this.destroyed = true;
      }
      reconnect() { reconnects.push(this); this.disconnected = false; }
    }
  };
  vm.createContext(x);
  vm.runInContext(source.slice(start, end), x);
  return { x, peers, reconnects, saves, tick(ms) {
    const until = clock + ms;
    for (;;) {
      const first = [...timers].filter(([, t]) => t.at <= until).sort((a, b) => a[1].at - b[1].at)[0];
      if (!first) break;
      timers.delete(first[0]); clock = first[1].at; first[1].fn();
    }
    clock = until;
  } };
}

test('恢复原房间时，销毁旧 Peer 的 disconnected 事件不能将旧 Peer 复活', () => {
  const h = harness();
  h.x.setupPeer(true, 'ABC234', true);
  const old = h.peers[0];
  old.emit('error', { type: 'unavailable-id' });
  assert.equal(old.destroyed, true);
  assert.equal(h.reconnects.length, 0, 'A peer being destroyed must never reconnect');
  h.tick(1200);
  assert.equal(h.peers.length, 2);
  assert.equal(h.x.net.peer, h.peers[1]);
  assert.equal(h.peers[1].id, 'echoes-bones-v3-ABC234');
});

test('原房间重试后，旧 Peer 的迟到事件不能改变当前恢复状态', () => {
  const h = harness();
  h.x.setupPeer(true, 'ABC234', true);
  const old = h.peers[0];
  old.emit('error', { type: 'unavailable-id' });
  h.tick(1200);
  const current = h.x.net.peer, status = h.x.net.status;
  old.emit('open');
  old.emit('error', { type: 'server-error' });
  old.emit('disconnected');
  assert.equal(h.x.net.peer, current);
  assert.equal(h.x.net.busy, true);
  assert.equal(h.x.net.status, status);
  assert.equal(h.saves.length, 0, 'Retired open events cannot save an unready room');
  assert.equal(h.reconnects.length, 0);
});
