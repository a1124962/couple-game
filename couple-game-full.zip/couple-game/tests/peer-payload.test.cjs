const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const {test}=require('node:test');

const root=path.join(__dirname,'..');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const bundledPeer=fs.readFileSync(path.join(root,'vendor/peerjs.min.js'),'utf8');
function sourceFunction(name){
  const start=app.indexOf('function '+name+'(');
  assert.notEqual(start,-1,'Missing application function: '+name);
  const end=app.indexOf('\nfunction ',start+1);
  return app.slice(start,end===-1?undefined:end);
}

// Keep the shipped PeerJS serializers, chunker and DataConnection intact.
// Only replace RTC byte delivery and signaling: this tests payload compatibility,
// not ICE, STUN/TURN availability or cross-network connectivity.
function harness(){
  let now=0,nextTimer=0,nextPeer=0,click;
  const timers=new Map();
  class DataChannel{
    constructor(){this.ordered=true;this.bufferedAmount=0;this.messages=[];this.listeners={};}
    addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);}
    send(data){this.messages.push(data);}
    receive(data){for(const fn of this.listeners.message||[])fn({data});}
    close(){}
  }
  class RTC{
    constructor(){this.signalingState='stable';this.iceConnectionState='new';}
    createDataChannel(){return new DataChannel();}
    createOffer(){return new Promise(()=>{});}
    close(){}
    addEventListener(){}
  }
  class Socket{constructor(){this.readyState=1;}send(){}close(){}}
  const x={console,TextEncoder,TextDecoder,ArrayBuffer,Uint8Array,Blob,
    RTCPeerConnection:RTC,WebSocket:Socket,
    navigator:{userAgent:'Chrome/153.0.0'},location:{protocol:'https:'},
    setTimeout(fn,delay){const id=++nextTimer;timers.set(id,{fn,at:now+delay});return id;},
    clearTimeout(id){timers.delete(id);},
    document:{addEventListener(type,fn){if(type==='click')click=fn;}},
    render(){},save(){},toast(){},playTone(){},
    net:{generation:1,connected:false,conn:null,peer:null,code:'ABC234',retry:0,
      busy:false,status:'',timer:null,seen:new Set(),pendingPoints:new Map(),token:'a'.repeat(32)},
    ui:{screen:'room',name:'旅伴'},session:{kind:'online',role:'guest'},drawActive:null,
    S:{version:3,revision:0,mode:null,players:{host:{name:'房主'},guest:{name:'旅伴'}},
      adv:null,guess:null,draw:{promptIdx:0,strokes:[]}}
  };
  x.window=x;vm.createContext(x);vm.runInContext(bundledPeer,x,{filename:'vendor/peerjs.min.js'});
  const RealPeer=x.Peer;
  // Avoid a remote ID request while preserving the real constructor/connect API.
  x.Peer=function(options){return new RealPeer('payload-test-'+(++nextPeer),options);};
  x.ECHOES_PEER_CONFIG={debug:0,config:{iceServers:[]}};
  for(const name of ['peerOptions','setupPeer','wire'])vm.runInContext(sourceFunction(name),x);
  const clickStart=app.indexOf("document.addEventListener('click',async e=>");
  const clickEnd=app.indexOf("window.addEventListener('resize'",clickStart);
  vm.runInContext(app.slice(clickStart,clickEnd),x);
  function tick(ms){
    const end=now+ms;
    for(;;){
      const entry=[...timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];
      if(!entry)break;
      timers.delete(entry[0]);now=entry[1].at;entry[1].fn();
    }
    now=end;
  }
  function connect(){x.setupPeer(false,'ABC234');x.net.peer.emit('open');return x.net.conn;}
  return {x,tick,connect,manual:()=>click({target:{closest(){return {dataset:{action:'reconnect'}};}}}),
    parse:value=>vm.runInContext('JSON.parse('+JSON.stringify(JSON.stringify(value))+')',x)};
}

function roundTrip(h,connection,payload){
  const errors=[],received=[],returned=[];
  const remote=h.x.net.peer.connect('payload-counterpart',{reliable:true,serialization:connection.serialization});
  connection.on('error',e=>errors.push(e.type));remote.on('error',e=>errors.push(e.type));
  connection.dataChannel.onopen();remote.dataChannel.onopen();
  // Discard the application's small hello; the payload below exercises the
  // negotiated serializer selected by the actual application connection path.
  connection.dataChannel.messages.length=0;
  remote.on('data',value=>received.push(value));connection.on('data',value=>returned.push(value));
  connection.send(h.parse(payload));
  assert.deepEqual(errors,[],'Large snapshots must not be rejected by the negotiated serializer');
  const outbound=connection.dataChannel.messages.splice(0);
  for(const bytes of outbound)remote.dataChannel.receive(bytes);
  assert.equal(received.length,1,'Deliver exactly one reassembled application message');
  assert.deepEqual(JSON.parse(JSON.stringify(received[0])),payload,'Chinese, emoji and nested values survive delivery');
  remote.send(received[0]);
  const inbound=remote.dataChannel.messages.splice(0);
  for(const bytes of inbound)connection.dataChannel.receive(bytes);
  assert.equal(returned.length,1,'Return exactly one complete application message');
  assert.deepEqual(JSON.parse(JSON.stringify(returned[0])),payload,'The reverse direction is lossless too');
  return {outbound:outbound.length,inbound:inbound.length};
}

const chinese='玛拉：鱼摊可以欠账，笑话不能赊。旅伴：那我先笑为敬。🦀✨\n';
const large={type:'sync',state:{version:3,revision:82,mode:'adventure',adv:{
  journal:Array.from({length:20},(_,i)=>({title:'骨城手记 '+i,text:chinese.repeat(50)})),
  players:{host:{name:'阿雨',hp:72},guest:{name:'小舟',hp:70}},flags:['玛拉鱼摊','请君踩坑']}}};
assert.ok(Buffer.byteLength(JSON.stringify(large))>65536,'Fixture crosses both the old 16 KB limit and multiple chunks');

for(const route of ['首次加入','自动重连','手动重连'])test(route+'完整往返大于16KB的中文剧情快照',async()=>{
  const h=harness();let connection=h.connect();
  if(route==='自动重连'){connection.dataChannel.onopen();connection.close();h.tick(2000);connection=h.x.net.conn;}
  if(route==='手动重连'){await h.manual();connection=h.x.net.conn;}
  const result=roundTrip(h,connection,large);
  assert.ok(result.outbound>1&&result.inbound>1,'Large snapshots use real bundled chunking in both directions');
});

test('正常指令仍能在同一通道无损往返',()=>{
  const h=harness();
  roundTrip(h,h.connect(),{type:'command',id:'一次出招',context:'battle|2',
    action:{type:'adv',a:{type:'boardAction',tool:'push',target:'e0',x:1,y:0}}});
});

test('真实PeerJS未打开的通道超时后有限重试并最终释放忙碌状态',()=>{
  const h=harness();let connection=h.connect();
  for(let attempt=1;attempt<=3;attempt++){
    h.tick(35000);
    assert.equal(h.x.net.retry,attempt,'An unopened close must still schedule a retry');
    assert.equal(h.x.net.busy,true);
    h.tick(2000*attempt);
    assert.notEqual(h.x.net.conn,connection,'Each retry gets a fresh real DataConnection');
    connection=h.x.net.conn;
  }
  h.tick(35000);
  assert.equal(h.x.net.retry,3,'Retry count stays bounded');
  assert.equal(h.x.net.busy,false,'Allow the player to retry or leave after the last timeout');
  assert.equal(h.x.net.connected,false);
});

test('真实已打开的通道超时收尾不因close事件重复安排重连',()=>{
  const h=harness(),connection=h.connect();
  connection.dataChannel.onopen();
  h.tick(8000);
  assert.equal(h.x.net.retry,1);
  h.tick(2000);
  assert.notEqual(h.x.net.conn,connection);
  assert.equal(h.x.net.retry,1);
});

test('超时关闭后迟到的welcome和open不能复活旧连接或取消重试',()=>{
  const h=harness(),connection=h.connect();
  h.tick(35000);
  connection.emit('data',h.parse({type:'welcome',version:3,state:{...h.x.S,revision:7}}));
  assert.equal(h.x.net.connected,false,'A queued welcome from a timed-out channel is obsolete');
  connection.emit('open');connection.emit('close');
  assert.equal(h.x.net.retry,1,'Late events cannot schedule a duplicate retry');
  h.tick(2000);
  assert.notEqual(h.x.net.conn,connection);
  assert.equal(h.x.S.revision,0);
});
