const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const assert=require('node:assert/strict'),{test}=require('node:test');
const root=path.resolve(__dirname,'..'),patch='data/rogue-events.js';
const plain=x=>JSON.parse(JSON.stringify(x));
function load(rewrite=true){
 const c={console,Date,Math,addEventListener(){},document:{addEventListener(){},getElementById(){return null;},querySelector(){return null;}}};c.window=c;vm.createContext(c);
 const files=[...fs.readFileSync(path.join(root,'index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
 assert.ok(files.includes(patch),'published index must include the event patch');
 for(const file of files){if(file==='app.js')break;if(file.startsWith('vendor/'))continue;if(!rewrite&&file===patch)continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),c,{filename:file});}
 const run=code=>vm.runInContext(code,c);
 run(`var S={players:{host:{name:'小甲'},guest:{name:'小乙'}},adv:null};var session={kind:'online',role:'host'};var ui={fullText:false,readPages:{}};
 function eventFixture(id,index,actor='host'){
  const event=GD().events.find(e=>e.id===id),choice=event.choices[index],req=choiceReq(choice),cls=req.cls||'blade',other=cls==='weaver'?'blade':'weaver';
  const a=advInit(17033);
  for(const [role,pick] of [['host',actor==='host'?cls:other],['guest',actor==='guest'?cls:other]]){
   advReduce(a,{type:'pickClass',cls:pick},role,S.players);advReduce(a,{type:'ready'},role,S.players);
  }
  a.act=event.act[0];a.gold=10000;a.bond=req.bondMax??Math.max(75,req.bondMin||0);a.flags=[req.flag,...(req.flags||[])].filter(Boolean);
  if(req.npc)a.npcAff[req.npc.id]=req.npc.v;
  for(const p of Object.values(a.players))p.hp=Math.max(1,p.maxhp-20);
  S.adv=a;enterNode(a,{id:'event-fixture',type:'event',eventId:id});return a;
 }
 function settle(id,index,roll,actor='host'){
  const a=eventFixture(id,index,actor),original=advRand;advRand=()=>roll;
  try{advReduce(a,{type:'eventChoice',idx:index},'host',S.players);advReduce(a,{type:'eventChoice',idx:index},'guest',S.players);}
  finally{advRand=original;}return a;
 }
 `);
 return {c,run};
}
const before=load(false),after=load(true),old=plain(before.c.GAME_DATA.events),now=plain(after.c.GAME_DATA.events);
function mechanical(event){const e=plain(event);delete e.title;delete e.text;for(const ch of e.choices){delete ch.label;for(const o of ch.outcomes)delete o.text;}return e;}
function rules(state){const a=plain(state);delete a.event.resultText;for(const j of a.journal){delete j.title;delete j.choice;delete j.text;}return a;}

test('96个事件和520个结果全部替换，原稿逐场保留且重复加载幂等',()=>{
 assert.equal(after.c.GAME_DATA.rogueEvents.ids.length,96);assert.equal(after.c.GAME_DATA.rogueEvents.outcomes,520);
 assert.equal(now.length,old.length);assert.equal(new Set(after.c.GAME_DATA.rogueEvents.ids).size,96);
 for(const e of now){const prior=old.find(x=>x.id===e.id);assert.deepEqual(plain(after.c.GAME_DATA.rogueEventOriginals[e.id]),prior);assert.notEqual(e.text,prior.text);
  e.choices.forEach((ch,i)=>ch.outcomes.forEach((o,j)=>assert.notEqual(o.text,prior.choices[i].outcomes[j].text)));
 }
 const snapshot=JSON.stringify(after.c.GAME_DATA.events),archive=JSON.stringify(after.c.GAME_DATA.rogueEventOriginals);
 after.run(fs.readFileSync(path.join(root,patch),'utf8'));assert.equal(JSON.stringify(after.c.GAME_DATA.events),snapshot);assert.equal(JSON.stringify(after.c.GAME_DATA.rogueEventOriginals),archive);
});

test('全部门槛、分支概率、数值、线索标记和后续战斗保持原样',()=>{
 for(const e of now)assert.deepEqual(mechanical(e),mechanical(old.find(x=>x.id===e.id)),e.id);
});

test('每场2到5句，台词是可识别角色，最长一句不超过90字且不会泄露静默者的声音',()=>{
 const tags=new Set(['stage','host','guest','mara','quill','pip','holt']);let maxLine=0,maxScene=0;
 for(const e of now)for(const text of [e.text,...e.choices.flatMap(ch=>ch.outcomes.map(o=>o.text))]){
  after.c.input=text.replace(/\{(?:CITY|DAILY):[^}]+\}/g,'');const lines=plain(after.run('dialogueLinesResolved(input)'));
  assert.ok(lines&&lines.length>=2&&lines.length<=5,e.id+' lines '+lines?.length);
  assert.ok(lines.some(l=>l.speaker!=='stage'),e.id+' must include character dialogue');
  for(const line of lines){assert.ok(tags.has(line.speaker),e.id+': '+line.speaker);assert.ok(Array.from(line.text).length<=90,e.id+': '+line.text);maxLine=Math.max(maxLine,Array.from(line.text).length);}
  const chars=lines.reduce((n,l)=>n+Array.from(l.text).length,0);maxScene=Math.max(maxScene,chars);assert.ok(chars<=100,e.id+': '+chars);
  assert.doesNotMatch(after.run('prose(input,false)'),/【(?:host|guest|stage|mara|quill|pip|holt)/);
 }
 assert.ok(maxLine>0&&maxScene>0);
});

test('压短事件仍保留五处已发生日常的回收，不凭空声称一起过生日',()=>{
 for(const e of old){const tokens=e.text.match(/\{CITY:[^}]+\}/g)||[];for(const token of tokens)assert.ok(now.find(n=>n.id===e.id).text.includes(token),e.id+' '+token);}
 after.run("S.adv={flags:[]};");
 assert.doesNotMatch(after.run("advText(GD().events.find(e=>e.id==='a3_8_zero_archive').text)"),/生日那张纸|皮普的签名|\{CITY:/);
 after.run("S.adv.flags=['city_birthday_fishsong'];");
 assert.match(after.run("advText(GD().events.find(e=>e.id==='a3_8_zero_archive').text)"),/皮普的签名/);
});

test('520种结果实际经双人一致选择结算，职业在任一端时与旧规则完全等价',()=>{
 let branches=0,cases=0;
 for(const e of now)for(let i=0;i<e.choices.length;i++){
  const ch=e.choices[i];let cumulative=0;
  for(let j=0;j<ch.outcomes.length;j++){
   const o=ch.outcomes[j],roll=cumulative+o.p/2;cumulative+=o.p;
   for(const actor of ch.req?.cls?['host','guest']:['host']){
    const call=`settle(${JSON.stringify(e.id)},${i},${roll},${JSON.stringify(actor)})`;
    const expected=before.run(call),actual=after.run(call);assert.equal(actual.event.done,true,e.id+':'+i+':'+j);
    assert.equal(actual.event.resultText,o.text);assert.equal(actual.journal.at(-1).text,o.text);
    assert.deepEqual(rules(actual),rules(expected),e.id+':'+i+':'+j+':'+actor);
    const once=JSON.stringify(actual);after.run(`advReduce(S.adv,{type:'eventChoice',idx:${i}},'host');advReduce(S.adv,{type:'eventChoice',idx:${i}},'guest');`);
    assert.equal(JSON.stringify(actual),once,'no repeated reward '+e.id);cases++;
   }branches++;
  }
 }
 assert.equal(branches,520);assert.ok(cases>520);
 after.run("var a=eventFixture('a1_0_keyecho',0);advReduce(a,{type:'eventChoice',idx:0},'host');");assert.equal(after.run('a.event.done'),false);
 after.run("advReduce(a,{type:'eventChoice',idx:1},'guest');");assert.equal(after.run('a.event.done'),false);
 after.run("advReduce(a,{type:'eventChoice',idx:0},'guest');");assert.equal(after.run('a.event.done'),true);
});

test('完整发布顺序仍保留三页主线、名字失去风险与副本原件区别',()=>{
 assert.match(now.find(e=>e.id==='a3_8_zero_archive').text,/副本/);assert.match(now.find(e=>e.id==='a3_8_zero_archive').text,/原件在钟楼/);
 for(const e of now)for(const ch of e.choices)for(const o of ch.outcomes)if(o.effects.some(ef=>ef.op==='flag'&&ef.k==='name_sold'))assert.match(o.text,/名字|姓名/,e.id);
 assert.equal(after.run('GD().events.length'),96);assert.equal(after.run('GD().npcs.flatMap(n=>n.meetings.flatMap(m=>Object.keys(m.nodes))).length'),213);
 for(const id of ['a1_0_keyecho','a2_13_mirror_door','a3_14_singer']){const e=now.find(e=>e.id===id);assert.ok(e.choices.some(ch=>ch.outcomes.some(o=>o.effects.some(ef=>ef.op==='flag'&&/^shard[123]$/.test(ef.k)))));}
});
