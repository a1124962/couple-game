const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const assert=require('node:assert/strict'),{test}=require('node:test');
const root=path.resolve(__dirname,'..');
const plain=x=>JSON.parse(JSON.stringify(x));
function fixture(){
 const c={console,Date,Math,addEventListener(){},document:{addEventListener(){},getElementById(){return null;},querySelector(){return null;}}};c.window=c;vm.createContext(c);
 const scripts=[...fs.readFileSync(path.join(root,'index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
 for(const file of scripts){if(file==='data/dialogue-scenes.js')break;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),c,{filename:file});}
 const before=plain(c.GAME_DATA);
 vm.runInContext(fs.readFileSync(path.join(root,'data/dialogue-scenes.js'),'utf8'),c);
 return {c,before,run:code=>vm.runInContext(code,c)};
}
test('十五处新会面开场保留所有选项、节点与数值，不改旧存档分支',()=>{
 const {c,before}=fixture(),after=plain(c.GAME_DATA);let count=0;
 for(let i=0;i<before.npcs.length;i++)for(let j=0;j<before.npcs[i].meetings.length;j++){
  const previous=before.npcs[i].meetings[j],current=after.npcs[i].meetings[j];
  assert.notEqual(current.nodes.start.text,previous.nodes.start.text);count++;
  const normalized=plain(current);normalized.nodes.start.text=previous.nodes.start.text;
  assert.deepEqual(normalized,previous);
 }
 assert.equal(count,15);
 assert.deepEqual(after.finalChoices,before.finalChoices);
 assert.deepEqual(after.endings,before.endings);
 assert.deepEqual(after.bossScenes,before.bossScenes);
});
test('完整载入顺序下，对话开场仍在落桥页切换环境，姓名与标记正确渲染',()=>{
 const {run}=fixture();run(`var S={players:{host:{name:'阿雨'},guest:{name:'小舟'}},adv:{id:20,phase:'intro',act:1}};var session={kind:'hotseat',role:'host'};var ui={fullText:false,readPages:{}};var pages=storyPages(GD().intro.text);var landing=pages.findIndex(p=>p.includes('你们落在'));`);
 assert.ok(run('landing')>0);
 run('ui.readPages[readerKey(S.adv)]=landing-1');assert.equal(run('prologueAtArchive(S.adv)'),true);
 run('ui.readPages[readerKey(S.adv)]=landing');assert.equal(run('prologueAtArchive(S.adv)'),false);
 const html=run('prose(GD().intro.text,false)');assert.doesNotMatch(html,/【(?:stage|host|guest|holt)/);assert.match(html,/阿雨/);assert.match(html,/小舟/);
 assert.match(run('GD().intro.text'),/三页/);
});
