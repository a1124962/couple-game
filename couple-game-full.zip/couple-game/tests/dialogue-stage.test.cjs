const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),{test}=require('node:test');
function fixture(){const c={console,Date,Math};c.window=c;vm.createContext(c);for(const f of ['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','data/combat-cast.js','engine.js','combat-director.js','R.js','narrative-ui.js','visual-novel.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'..',f),'utf8'),c);vm.runInContext(`var S={players:{host:{name:'小甲'},guest:{name:'小乙'}},adv:advInit(11)};var session={kind:'hotseat',role:'host'};var ui={fullText:false,readPages:{}};for(const [r,cls] of [['host','blade'],['guest','weaver']]){advReduce(S.adv,{type:'pickClass',cls},r,S.players);advReduce(S.adv,{type:'ready'},r,S.players);}`,c);return {c,run:s=>vm.runInContext(s,c)};}
test('每页只有一名说话人，短动作随下一句显示，原文无遗漏',()=>{const {c,run}=fixture();const text='【stage】锅盖跳了一下。\n\n【host:smile】别按。\n\n【guest:annoyed】已经按了。\n\n【innkeeper:neutral】把锅扶住。';c.input=text;const pages=JSON.parse(run('JSON.stringify(storyPages(input))'));assert.equal(pages.length,3);assert.match(pages[0],/锅盖/);for(const p of pages){c.page=p;assert.equal(run(`dialogueLinesResolved(page).filter(l=>l.speaker!=='stage').length`),1);}run('reader(input,"daily")');assert.equal(run('ui.readerCurrent.speaker'),'host');run('ui.readPages.daily=1;reader(input,"daily")');assert.equal(run('ui.readerCurrent.speaker'),'guest');assert.equal(run('ui.readerCurrent.mood'),'annoyed');});
test('长对白按 Unicode 字符拆分，表情和说话人不会丢失',()=>{const {c,run}=fixture();const original='锅盖🦀'.repeat(40)+'！别跑。';c.input='【porter:smile】'+original;const pages=JSON.parse(run('JSON.stringify(storyPages(input,40))'));c.pages=pages;assert.equal(run('pages.flatMap(p=>dialogueLinesResolved(p)).map(l=>l.text).join("")'),original);assert.ok(run('pages.every(p=>dialogueLinesResolved(p).every(l=>l.speaker==="porter"&&l.mood==="smile"))'));assert.equal(pages.some(p=>/[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(p)),false);});
test('整段与手记显示姓名，分页使用名牌；未知说话人安全退回',()=>{const {c,run}=fixture();c.input='【host:smile】我来。\n\n【guest:neutral】你先把门打开。\n\n【stranger:loud】有人吗？';const whole=run('prose(input,false)');assert.match(whole,/小甲/);assert.match(whole,/小乙/);assert.match(whole,/有人/);assert.doesNotMatch(whole,/【|stranger|loud/);const page=run('reader(input,"x")');assert.doesNotMatch(page,/dialogue-speaker/);assert.equal(run('readDone()'),false);run('ui.readPages.x=2;reader(input,"x")');assert.equal(run('readDone()'),true);run('ui.fullText=true');assert.match(run('reader(input,"x")'),/dialogue-speaker/);});
test('人物名、对白和动作均转义，不把存档文字插成 HTML',()=>{const {c,run}=fixture();run(`S.players.host.name='<img src=x onerror=alert(1)>'`);c.input='【stage】<script>bad</script>\n\n【host:neutral】<img src=x onerror=alert(2)> & "杯子"';const html=run('prose(input,false)');assert.doesNotMatch(html,/<script>|<img /);assert.match(html,/&lt;script&gt;/);assert.match(html,/&lt;img/);assert.match(html,/&amp;/);});
test('没有标记的原长稿仍按原分页方式显示，切换后清理上一句说话人',()=>{const {c,run}=fixture();c.input='这一页是原来的旁白。\n\n下一段没有标记。';assert.equal(run('storyPages(input).length'),1);assert.match(run('prose(input,false)'),/<p>这一页是原来的旁白。<\/p>/);run(`reader('【innkeeper:smile】收工。','tagged');reader(input,'legacy')`);assert.equal(run('ui.readerCurrent.tagged'),false);assert.equal(run('ui.readerCurrent.speaker'),null);});
test('新场景读到谁就突出谁，切换表情；普通互动也能指定环境',()=>{const {run}=fixture();run(`GD().interludes[0]={id:'qa_dialogue',act:1,kind:'duo',title:'夜班',purpose:'帮忙',text:'【innkeeper:smile】先把饭吃了。\\n\\n【guest:annoyed】锅把勺子吃了。',stage:{background:'kitchen',cast:['innkeeper']},clues:{host:'前台',guest:'后厨'},options:{host:['甲','乙'],guest:['甲','乙']},results:[]};S.adv.phase='interlude';S.adv.interlude={id:'qa_dialogue',done:false,picks:{host:null,guest:null},attempts:0};`);let html=run('storyView(S.adv)');assert.match(html,/vn-place-kitchen/);assert.match(html,/data-speaker="innkeeper">唐婶/);assert.match(html,/is-speaking" data-person="innkeeper"/);assert.match(html,/data-expression="1"/);run('ui.readPages[readerKey(S.adv)]=1');html=run('storyView(S.adv)');assert.match(html,/data-speaker="guest">小乙/);assert.match(html,/is-speaking" data-person="guest"/);assert.doesNotMatch(html,/【guest/);});
test('静默者一般表情不能泄露摘面具立绘，既有揭示节点仍可显示',()=>{const {run}=fixture();assert.match(run('scenePortrait("quiet","annoyed",S.adv)'),/data-expression="1"/);run(`S.adv.phase='npc';S.adv.npc={id:'quiet',node:'quiet_open_face',meeting:2}`);assert.match(run('scenePortrait("quiet","annoyed",S.adv)'),/data-expression="2"/);});
test('四职业任意搭配均使用独立立绘，主客互聊保持左右位置且两端一致',()=>{
 const {c,run}=fixture();
 for(const host of ['blade','warden','weaver','seer'])for(const guest of ['blade','warden','weaver','seer']){
  c.classes={host,guest};run('S.adv.players.host.cls=classes.host;S.adv.players.guest.cls=classes.guest');
  for(const speaker of ['host','guest']){
   c.speaker=speaker;run('reader(`【${speaker}:smile】轮到我了。`,"pair")');
   const cast=JSON.parse(run('JSON.stringify(dialogueCast(S.adv,null,null))'));
   assert.deepEqual(cast.map(p=>[p.id,p.type,p.speaking]),[['host','player',speaker==='host'],['guest','partner',speaker==='guest']]);
   run('session.role="host"');const hostView=run('dialogueStage(S.adv,null,null)');
   run('session.role="guest"');assert.equal(run('dialogueStage(S.adv,null,null)'),hostView);
   assert.match(hostView,new RegExp(`data-person="host"><div class="dialogue-hero-art dialogue-hero-${host}" data-dialogue-atlas="${host}"`));
   assert.match(hostView,new RegExp(`data-person="guest"><div class="dialogue-hero-art dialogue-hero-${guest}" data-dialogue-atlas="${guest}"`));
   assert.equal((hostView.match(/is-speaking/g)||[]).length,1);
  }
 }
});
test('八名 NPC 即使不在预设演员表也必须出场，陪场角色沿用这段对话最近发言的主角',()=>{
 const {c,run}=fixture();
 for(const npc of ['mara','quill','pip','holt','quiet','innkeeper','porter','laundress']){
  c.input=`【host:neutral】把单子拿来。\n\n【guest:smile】拿反了。\n\n【${npc}:neutral】我看看。`;
  run('ui.readPages.cast=2;reader(input,"cast")');
  const cast=JSON.parse(run('JSON.stringify(dialogueCast(S.adv,{stage:{cast:["porter"]}},null))'));
  assert.deepEqual(cast.map(p=>[p.id,p.speaking]),[['guest',false],[npc,true]]);
  const html=run('dialogueStage(S.adv,{stage:{cast:["porter"]}},null)');
  assert.match(html,new RegExp(`is-speaking" data-person="${npc}"`));
  assert.match(html,new RegExp(`data-character="${npc}"`));
  run('session.role="guest"');assert.equal(run('dialogueStage(S.adv,{stage:{cast:["porter"]}},null)'),html);
 }
 run('reader("【innkeeper:neutral】新的一天。","new-scene")');
 assert.equal(run('ui.readerCurrent.playerSpeaker'),null);
 assert.equal(run('dialogueCast(S.adv,null,null)[0].id'),'host');
});
test('序章和幕间未声明的说话人也能进入前景，返回主角台词时匹配正确职业',()=>{
 const {run}=fixture();run('S.adv.players.host.cls="warden";S.adv.players.guest.cls="seer"');
 for(const phase of ['intro','actIntro']){
  run(`S.adv.phase='${phase}';var opening=${phase==='intro'?'GD().intro':'GD().actIntros[0]'};opening.text='【laundress:smile】谁把鱼洗了？\\n\\n【guest:neutral】它自己跳的。';opening.stage={background:'laundry',cast:['innkeeper']};ui.readPages={};`);
  let html=run('storyView(S.adv)');assert.match(html,/is-speaking" data-person="laundress"/);assert.match(html,/data-speaker="laundress">阿绫/);
  run('ui.readPages[readerKey(S.adv)]=1');html=run('storyView(S.adv)');assert.match(html,/is-speaking" data-person="guest"><div class="dialogue-hero-art dialogue-hero-seer"/);
 }
});
test('旧旁白同样使用大主角立绘，旧 NPC 表情仍按原节点显示',()=>{
 const {run}=fixture();run(`S.adv.phase='intro';GD().intro.text='门口挂着一块牌子。';S.adv.players.host.cls='warden';S.adv.players.guest.cls='seer';`);
 const html=run('storyView(S.adv)');assert.match(html,/data-dialogue-atlas="warden"/);assert.match(html,/data-dialogue-atlas="seer"/);assert.doesNotMatch(html,/class="cast-art/);
 run(`S.adv.phase='npc';S.adv.npc={id:'mara',node:'ask_daughter',meeting:0};reader('她低头整理渔网。','old-npc')`);
 assert.match(run('scenePortrait("mara","neutral",S.adv)'),/data-expression="2"/);
 assert.equal(run('dialogueHeroPortrait({cls:"<img src=x>"},"host")'),'');
});
