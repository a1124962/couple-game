const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const base=path.resolve(__dirname,'..');
const files=['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','engine.js','R.js','narrative-ui.js','data/lively-city.js'];
const source=fs.readFileSync(path.join(base,'data/npc-voices-mara.js'),'utf8');
const plain=value=>JSON.parse(JSON.stringify(value));
function fixture(rewrite=true){
 const x={console,Date,Math};x.window=x;vm.createContext(x);
 for(const file of files)vm.runInContext(fs.readFileSync(path.join(base,file),'utf8'),x,{filename:file});
 const before=plain(x.GAME_DATA);
 if(rewrite)vm.runInContext(source,x,{filename:'data/npc-voices-mara.js'});
 const run=code=>vm.runInContext(code,x);
 run(`var S={players:{host:{name:'阿雨'},guest:{name:'小舟'}},adv:null};
 function start(act=1){let a=advInit(7301);for(const [r,cls] of [['host','blade'],['guest','weaver']]){advReduce(a,{type:'pickClass',cls},r,S.players);advReduce(a,{type:'ready'},r,S.players);}a.act=act;a.gold=500;a.bond=80;a.npcAff.mara=5;S.adv=a;enterNode(a,{id:'mara-'+act,type:'npc',npcId:'mara'});return a;}
 function pick(a,idx){for(const r of ['host','guest'])advReduce(a,{type:'npcChoice',idx},r,S.players);}
 function state(a){return {gold:a.gold,bond:a.bond,hp:Object.fromEntries(Object.entries(a.players).map(([r,p])=>[r,p.hp])),flags:a.flags,npcAff:a.npcAff,npc:a.npc.node,ended:a.npc.ended,npcMet:a.npcMet,visited:a.npcVisitedChoices,pendingDraft:a.pendingDraft,pendingDrafts:a.pendingDrafts,rng:a.rngState};}`);
 return {x,before,run,mara:x.GAME_DATA.npcs.find(n=>n.id==='mara')};
}
const {x,before,run,mara}=fixture();
const original=before.npcs.find(n=>n.id==='mara');
const nodes=act=>mara.meetings.find(m=>m.act===act).nodes;
let count=0;function test(label,fn){fn();count++;console.log('✓ '+label);}
function withoutVoice(npc){const copy=plain(npc);for(const m of copy.meetings)for(const n of Object.values(m.nodes)){delete n.text;for(const c of n.choices)delete c.label;}return copy;}

test('三幕55节点全部改写，原稿副本完整保留',()=>{
 assert.equal(mara.meetings.reduce((n,m)=>n+Object.keys(m.nodes).length,0),55);
 assert.deepEqual(plain(mara.meetings.map(m=>Object.keys(m.nodes).length)),[14,29,12]);
 const archive=JSON.parse(fs.readFileSync(path.join(base,'data/archive/npc-mara-before-voices-v1.json'),'utf8'));
 assert.deepEqual(archive,original);
 for(const m of mara.meetings){const old=original.meetings.find(o=>o.act===m.act);for(const [id,n] of Object.entries(m.nodes))assert.notEqual(n.text,old.nodes[id].text,m.act+':'+id);}
});

test('所有节点ID、分支顺序、next、req、effects、hidden、hint及其余字段不变',()=>{
 assert.deepEqual(withoutVoice(mara),withoutVoice(original));
 const oldOthers=before.npcs.filter(n=>n.id!=='mara');
 assert.deepEqual(plain(x.GAME_DATA.npcs.filter(n=>n.id!=='mara')),oldOthers);
 const oldGame=plain(before),newGame=plain(x.GAME_DATA);delete oldGame.npcs;delete newGame.npcs;
 assert.deepEqual(newGame,oldGame);
});

test('正文具备具体行动且长度合理，收尾允许短句，所有选择都有文字',()=>{
 const all=[];
 for(const m of mara.meetings)for(const [id,n] of Object.entries(m.nodes)){
  all.push(n.text);const han=(n.text.match(/\p{Script=Han}/gu)||[]).length;
  const ending=!n.choices.length||id.endsWith('_end')||id.startsWith('end_');
  assert.ok(han>=(ending?45:100),m.act+':'+id+' 过短：'+han);
  assert.ok(han<=240,m.act+':'+id+' 过长：'+han);
  for(const c of n.choices)assert.ok(c.label.trim().length>=4);
 }
 assert.doesNotMatch(all.join('\n'),/谁更爱谁|道歉不是认输|三厘米|半边笑容|爱不是答案/);
 assert.match(nodes(1).start.text,/背包勾住筐沿/);
 assert.match(nodes(2).ask_price.text,/记忆税/);
 assert.match(nodes(3).alive_memory.text,/带这块/);
});

test('三幕保留城市往事回调，重复载入不叠字且存档仍能展开回调',()=>{
 for(const m of mara.meetings)assert.equal(m.nodes.start.text.split('{CITY:mara}').length-1,1);
 const once=JSON.stringify(x.GAME_DATA);vm.runInContext(source,x);assert.equal(JSON.stringify(x.GAME_DATA),once);
 run(`var a=start(2);a.flags.push('city_fish_cakes');a=JSON.parse(JSON.stringify(a));S.adv=a;`);
 const callback=run(`advText(GAME_DATA.npcs.find(n=>n.id==='mara').meetings[1].nodes.start.text)`);
 assert.match(callback,/鱼饼师傅/);assert.doesNotMatch(callback,/\{CITY:/);
});

test('费用与实得一致：付费地图不二次收费、两种取影收费、镜片与木刺',()=>{
 for(const id of ['ta_first','silence'])for(const i of [0,2])assert.match(nodes(1)[id].choices[i].label,/20 星砂/);
 assert.match(nodes(1).pay_map.text,/二十星砂已经收下/);
 assert.match(nodes(1).paid_end.text,/没有再收一次/);
 assert.match(nodes(1).self_first.choices[0].label,/挣 5 星砂/);
 for(const [id,cost] of [['buyback',5],['together_first',5],['ta_first',10]]){
  const c=nodes(2)[id].choices[0];assert.match(c.label,new RegExp(cost+' 星砂'));assert.match(c.label,/2 羁绊/);
  assert.equal(c.effects.find(e=>e.op==='gold').v,-cost);assert.equal(c.effects.find(e=>e.op==='bond').v,-2);
 }
 assert.match(nodes(2).refuse_buy.choices[2].label,/3 星砂/);
 assert.match(nodes(3).hull_carving.choices[1].label,/双方失去 5 生命/);
 assert.match(nodes(3).hull_vow.choices[1].label,/自己的名字.*卖出名字/);
 run(`var a=start(1);a.gold=19;pick(a,1);var locked=JSON.stringify(state(a));pick(a,0);`);
 assert.equal(run('JSON.stringify(state(a))'),run('locked'),'买地图仍受真实资源门槛限制');
});

test('玛拉存活入口不再依赖救命flag，私密旧事仍需信任，卖名回忆仍需真实flag',()=>{
 run(`var a=start(3);a.flags=[];a.npcAff.mara=0;`);
 assert.equal(run(`hasReq(a,choiceReq(GAME_DATA.npcs.find(n=>n.id==='mara').meetings[2].nodes.start.choices[0]))`),true);
 assert.equal(nodes(3).start.choices[0].req,undefined);
 run(`pick(a,0);a.npcAff.mara=2;var locked=JSON.stringify(state(a));pick(a,2);`);
 assert.equal(run('JSON.stringify(state(a))'),run('locked'));
 run(`a.npcAff.mara=3;pick(a,2);`);assert.equal(run('a.npc.node'),'alive_memory');
 run(`var a=start(2);pick(a,2);var locked=JSON.stringify(state(a));pick(a,2);`);
 assert.equal(run('a.npc.node'),'offer_help');assert.equal(run('JSON.stringify(state(a))'),run('locked'));
 run(`a.flags.push('name_sold');pick(a,2);`);assert.equal(run('a.npc.node'),'name_sold_understand');
});

test('女儿的倒影不是复活，三条船骸路线都与玛拉仍活着的连续性一致',()=>{
 assert.match(nodes(2).mirror_daughter.text,/我知道人没了/);
 assert.match(nodes(2).offer_help.text,/不能让死者复生/);
 assert.match(nodes(2).buy_result.text,/不是女儿复生/);
 assert.match(nodes(2).ask_daughter.text,/回答不了今天的事/);
 assert.match(nodes(3).start.text,/玛拉跪在里面补板/);
 assert.match(nodes(3).alive_end.text,/玛拉已经踩上踏台/);
 assert.match(nodes(3).dead_cabin.text,/玛拉从窗缝伸进铁钩/);
 assert.match(nodes(3).dead_end.text,/玛拉已经补住了漏风的缝/);
 assert.match(nodes(3).hull_end.text,/玛拉继续处理/);
 const sea=Object.values(nodes(3)).map(n=>n.text).join('\n');
 assert.doesNotMatch(sea,/她随船沉没|她已经死|玛拉的尸体|玛拉的遗骸/);
});

test('旧信只记mara_note，实际归路选择记录mara_survive，未选的事件不会凭空触发',()=>{
 run(`var a=start(3);for(const i of [1,0,0,0,0])pick(a,i);`);
 assert.equal(run('a.npc.ended'),true);assert.equal(run(`a.flags.includes('mara_note')`),true);assert.equal(run(`a.flags.includes('mara_survive')`),false);
 run(`var a=start(3);for(const i of [0,0,1,1,0])pick(a,i);`);
 assert.equal(run('a.npc.ended'),true);assert.equal(run(`a.flags.includes('mara_survive')`),false);
 run(`var a=start(3);for(const i of [0,0,0,0,0])pick(a,i);`);
 assert.equal(run('a.npc.ended'),true);assert.equal(run(`a.flags.filter(f=>f==='mara_survive').length`),1);
 run(`var a=start(3);for(const i of [2,2,1,0])pick(a,i);`);
 assert.equal(run(`a.flags.includes('name_sold')`),true);assert.equal(run(`a.flags.includes('mara_survive')`),false);
});

test('所有终点路径在真实双人共识流程中可达，改写前后数值和标记相同',()=>{
 const old=fixture(false),fresh=fixture(true);let paths=0;
 function walk(m,id='start',steps=[]){
  const n=m.nodes[id];if(!n.choices.length){verify(m.act,steps);return;}
  n.choices.forEach((c,i)=>{const nextSteps=[...steps,{id,idx:i,req:c.req||{}}];if(c.next)walk(m,c.next,nextSteps);else verify(m.act,nextSteps);});
 }
 function verify(act,steps){
  paths++;
  for(const f of [old,fresh]){
   f.run(`var a=start(${act});a.flags=['name_sold'];`);
   for(const step of steps){
    assert.equal(f.run('a.npc.node'),step.id);
    if(step.req.cls)f.run(`a.players.guest.cls=${JSON.stringify(step.req.cls)};`);
    f.run(`pick(a,${step.idx});`);
   }
   assert.equal(f.run('a.npc.ended'),true,'路径没有抵达结尾：'+act+':'+steps.map(s=>s.id+'.'+s.idx).join(','));
  }
  assert.deepEqual(plain(fresh.run('state(a)')),plain(old.run('state(a)')));
 }
 for(const m of mara.meetings)walk(m);
 assert.ok(paths>=100,'应该覆盖全部组合而非只检查节点：'+paths);
 console.log('  '+paths+' 条终点路径通过双人共识');
});

console.log(count+' Mara voice tests passed.');
