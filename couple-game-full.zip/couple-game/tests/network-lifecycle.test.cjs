const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {test}=require('node:test');

const source=fs.readFileSync(path.join(__dirname,'../app.js'),'utf8');
function sourceFunction(name){
  const start=source.indexOf('function '+name+'(');
  assert.notEqual(start,-1,'Missing application function: '+name);
  const next=source.indexOf('\nfunction ',start+1);
  return source.slice(start,next===-1?undefined:next);
}

// Exercise production protocol handlers with a deterministic clock and transport.
// This suite deliberately does not claim WebRTC, ICE, or cross-network coverage.
function harness(role='guest'){
  let clock=0,timerId=0,tokenId=0;
  const timers=new Map(),calls={renders:0,redraws:0,saves:0,reconnects:0};
  const x={
    console,
    setTimeout(fn,delay){const id=++timerId;timers.set(id,{fn,at:clock+delay});return id;},
    clearTimeout(id){timers.delete(id);},
    net:{generation:1,connected:false,conn:null,peer:null,code:'ABC234',retry:0,
      busy:false,status:'',timer:null,seen:new Set(),pendingPoints:new Map(),token:'a'.repeat(32),guestToken:''},
    ui:{screen:'room',name:'同行者',penColor:'#344d48',penSize:4,eraser:false},
    session:{kind:'online',role},companionTimer:null,drawActive:null,
    S:{version:3,revision:5,mode:'draw',players:{host:{name:'房主'},guest:{name:'旅伴'}},
      adv:null,guess:null,draw:{promptIdx:0,strokes:[]}},
    render(){calls.renders++;},redrawCanvas(){calls.redraws++;},
    save(){calls.saves++;},saveSoon(){calls.saves++;},toast(){},playTone(){},
    clone(value){return JSON.parse(JSON.stringify(value));},
    randomToken(){return (++tokenId).toString(16).padStart(32,'0');},
    GD(){return {drawPrompts:['一','二','三']};},
    advInit(){return {phase:'classSelect'};},
    publicState(){return x.clone(x.S);},
    dispatch(){throw new Error('Unexpected local dispatch');}
  };
  function connection(){
    const c=new EventEmitter();
    c.open=false;c.closed=false;c.sent=[];
    c.send=value=>c.sent.push(x.clone(value));
    c.close=()=>{if(c.closed)return;c.closed=true;c.open=false;c.emit('close');};
    c.start=()=>{c.open=true;c.emit('open');};
    return c;
  }
  x.net.peer={destroyed:false,destroy(){this.destroyed=true;},connect(){calls.reconnects++;return connection();}};
  vm.createContext(x);
  for(const name of ['phaseKey','applyAction','send','sync','clearPendingContinue','disconnect','wire','drawPoint']){
    vm.runInContext(sourceFunction(name),x,{filename:'app.js:'+name});
  }
  function tick(ms){
    const end=clock+ms;
    for(;;){
      const next=[...timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];
      if(!next)break;
      timers.delete(next[0]);clock=next[1].at;next[1].fn();
    }
    clock=end;
  }
  function guestConnected(){
    const c=connection();x.wire(c,false,x.net.generation);c.start();
    c.emit('data',{type:'welcome',version:3,state:x.clone(x.S)});
    return c;
  }
  return {x,calls,connection,tick,guestConnected};
}

test('被新连接替代的旧连接不能回滚状态、拒绝房间或改变当前连接',()=>{
  const h=harness(),{x}=h,old=h.connection(),current=h.connection();
  x.wire(old,false,1);old.start();
  x.wire(current,false,1);current.start();
  current.emit('data',{type:'welcome',version:3,state:{...x.clone(x.S),revision:10}});
  old.emit('data',{type:'welcome',version:3,state:{...x.clone(x.S),revision:2}});
  assert.equal(x.S.revision,10,'Late welcome must not roll state back');
  old.emit('data',{type:'sync',state:{...x.clone(x.S),revision:100}});
  old.emit('data',{type:'rejected',message:'旧请求已失效'});
  old.emit('open');old.emit('close');
  assert.equal(x.S.revision,10,'Even a newer revision from an obsolete connection is invalid');
  assert.equal(x.net.conn,current);
  assert.equal(x.net.connected,true);
  assert.notEqual(x.net.status,'旧请求已失效');
});

test('手动建立新连接会取消仍在等待的自动重连计时器',()=>{
  const h=harness(),{x}=h;
  let obsoleteRetry=0;
  x.net.timer=x.setTimeout(()=>obsoleteRetry++,2000);
  x.wire(h.connection(),false,1);
  h.tick(2500);
  assert.equal(obsoleteRetry,0,'Manual connection must cancel the scheduled retry');
});

test('离开旧房间后重试次数归零，新房间首连失败仍可重试',()=>{
  const h=harness(),{x}=h;
  x.net.retry=3;x.net.seen.add('old-command');x.net.pendingPoints.set('old-point',{});
  x.disconnect();
  assert.equal(x.net.retry,0);
  assert.equal(x.net.seen.size,0);
  assert.equal(x.net.pendingPoints.size,0);
  const c=h.connection();
  x.wire(c,false,x.net.generation);
  h.tick(35000);
  assert.equal(c.closed,true);
  assert.equal(x.net.retry,1);
  assert.equal(x.net.busy,true);
});

for(const mode of ['adventure','draw']){
  test('客人画图期间房主'+(mode==='draw'?'清空画布':'切换玩法')+'仍能同步',()=>{
    const h=harness(),{x}=h,c=h.guestConnected();
    x.drawActive={id:'guest-stroke',pointer:1,last:0};
    for(let i=0;i<10;i++)x.drawPoint({x:i/20,y:.5});
    assert.equal(x.S.draw.strokes[0].points.length,10,'Keep immediate local drawing feedback');
    assert.equal(x.S.revision,5,'Local optimistic points must not advance the authority revision');
    assert.equal(c.sent.filter(m=>m.type==='command').length,10);
    assert.equal(x.net.pendingPoints.size,10);
    const state={...x.clone(x.S),revision:6,mode,draw:{promptIdx:0,epoch:mode==='draw'?1:0,strokes:[]}};
    c.emit('data',{type:'sync',state});
    assert.equal(x.S.revision,6);
    assert.equal(x.S.mode,mode);
    assert.equal(x.S.draw.strokes.length,0);
    assert.equal(x.net.pendingPoints.size,0);
    assert.equal(x.drawActive,null,'A new mode or canvas epoch cancels an obsolete active stroke');
  });
}

test('重复命令 ID 不会重复修改状态，而新命令 ID 仍可执行',()=>{
  const h=harness('host'),{x}=h,c=h.connection();
  x.wire(c,true,1);c.start();
  c.emit('data',{type:'hello',version:3,name:'旅伴',token:'a'.repeat(32)});
  const before=x.S.revision;
  const command={type:'command',id:'once',context:x.phaseKey(),action:{type:'drawPrompt'}};
  c.emit('data',command);c.emit('data',command);
  assert.equal(x.S.draw.promptIdx,1);
  assert.equal(x.S.revision,before+1);
  c.emit('data',{...command,id:'next'});
  assert.equal(x.S.draw.promptIdx,2);
  assert.equal(x.S.revision,before+2);
});

test('清空画布后迟到的旧阶段画点被拒绝，新阶段画点仍可加入',()=>{
  const h=harness('host'),{x}=h,c=h.connection();
  x.wire(c,true,1);c.start();
  c.emit('data',{type:'hello',version:3,name:'旅伴',token:'a'.repeat(32)});
  const oldContext=x.phaseKey();
  const point={type:'drawPoint',id:'guest-stroke',point:{x:.2,y:.4},color:'#344d48',size:4};
  c.emit('data',{type:'command',id:'before-clear',context:oldContext,action:point});
  assert.equal(x.S.draw.strokes.length,1);
  x.applyAction({type:'drawClear'},'host');
  const clearedRevision=x.S.revision;
  assert.notEqual(x.phaseKey(),oldContext);
  c.emit('data',{type:'command',id:'late-point',context:oldContext,action:point});
  assert.equal(x.S.draw.strokes.length,0);
  assert.equal(x.S.revision,clearedRevision);
  assert.equal(c.sent.at(-1).type,'sync','Tell the sender which canvas is authoritative');
  c.emit('data',{type:'command',id:'fresh-point',context:x.phaseKey(),action:point});
  assert.equal(x.S.draw.strokes.length,1);
});

test('同一连接重复welcome不能回滚已经同步的状态',()=>{
  const h=harness(),{x}=h,c=h.guestConnected();
  c.emit('data',{type:'sync',state:{...x.clone(x.S),revision:10}});
  c.emit('data',{type:'welcome',version:3,state:{...x.clone(x.S),revision:1}});
  assert.equal(x.S.revision,10);
});

test('同一画布的正常同步不会打断正在绘制的手势',()=>{
  const h=harness(),{x}=h,c=h.guestConnected();
  const active={id:'in-progress',pointer:1,last:0};x.drawActive=active;
  c.emit('data',{type:'sync',state:{...x.clone(x.S),revision:6}});
  assert.equal(x.drawActive,active);
  assert.ok(h.calls.redraws>0);
});

test('快照先于画点确认到达时，未确认笔点仍按原顺序显示且序号保持权威值',()=>{
  const h=harness(),{x}=h,c=h.guestConnected(),before=x.clone(x.S);
  x.drawActive={id:'guest-in-flight',pointer:1,last:0};
  const points=[{x:.1,y:.2},{x:.2,y:.3},{x:.3,y:.4}];
  for(const point of points)x.drawPoint(point);
  const commands=c.sent.filter(m=>m.type==='command');
  // The host produced this snapshot before any of the guest's points arrived.
  c.emit('data',{type:'sync',state:{...before,revision:6}});
  assert.deepEqual(x.clone(x.S.draw.strokes[0].points),points);
  assert.equal(x.net.pendingPoints.size,3);
  assert.equal(x.S.revision,6);
  commands.forEach((command,i)=>c.emit('data',{type:'pointAck',id:command.id,revision:7+i}));
  assert.equal(x.net.pendingPoints.size,0);
  assert.equal(x.S.revision,9);
  assert.deepEqual(x.clone(x.S.draw.strokes[0].points),points,'ACKs must not append or remove visible points');
});

test('画点确认先于快照到达时，已确认笔点不会被重复重放',()=>{
  const h=harness(),{x}=h,c=h.guestConnected();
  x.drawActive={id:'guest-confirmed',pointer:1,last:0};
  const points=[{x:.1,y:.2},{x:.2,y:.3}];
  for(const point of points)x.drawPoint(point);
  const commands=c.sent.filter(m=>m.type==='command');
  const authoritative=x.clone(x.S);authoritative.revision=7;
  commands.forEach((command,i)=>c.emit('data',{type:'pointAck',id:command.id,revision:6+i}));
  assert.equal(x.net.pendingPoints.size,0);
  c.emit('data',{type:'sync',state:authoritative});
  assert.equal(x.S.revision,7);
  assert.equal(x.S.draw.strokes.length,1);
  assert.deepEqual(x.clone(x.S.draw.strokes[0].points),points);
});

test('快照包含部分已确认笔点时，只重放其余未确认笔点',()=>{
  const h=harness(),{x}=h,c=h.guestConnected();
  x.drawActive={id:'guest-partial',pointer:1,last:0};
  const points=[{x:.1,y:.2},{x:.2,y:.3},{x:.3,y:.4}];
  for(const point of points)x.drawPoint(point);
  const commands=c.sent.filter(m=>m.type==='command');
  const partial=x.clone(x.S);partial.revision=6;partial.draw.strokes[0].points=points.slice(0,1);
  c.emit('data',{type:'pointAck',id:commands[0].id,revision:6});
  c.emit('data',{type:'sync',state:partial});
  assert.equal(x.net.pendingPoints.size,2);
  assert.equal(x.S.revision,6);
  assert.deepEqual(x.clone(x.S.draw.strokes[0].points),points);
});

test('画笔消息和确认不能倒退或污染权威序号',()=>{
  const h=harness(),{x}=h,c=h.guestConnected();
  x.S.revision=10;
  const point={type:'drawPoint',id:'host-stroke',point:{x:.2,y:.4},color:'#344d48',size:4};
  for(const revision of [9,NaN,Infinity,'11']){
    c.emit('data',{type:'point',revision,role:'host',action:point});
    c.emit('data',{type:'pointAck',revision});
    assert.equal(x.S.revision,10);
    assert.equal(x.S.draw.strokes.length,0,'Ignore stale or invalid point packets entirely');
  }
  c.emit('data',{type:'point',revision:11,role:'host',action:point});
  assert.equal(x.S.revision,11);
  assert.equal(x.S.draw.strokes[0].points.length,1);
  c.emit('data',{type:'pointAck',revision:12});
  assert.equal(x.S.revision,12);
});
