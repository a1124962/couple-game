'use strict';
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const {test}=require('node:test');
const root=path.join(__dirname,'..'),boardFile=path.join(root,'tactical-board.js');
function fixture(){
 const x={console,Math,Date:class extends Date{static now(){return 1000;}}};x.window=x;vm.createContext(x);
 for(const f of ['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','data/combat-cast.js','engine.js','battle-tactics.js','combat-director.js',...(fs.existsSync(boardFile)?['tactical-board.js']:[])])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),x,{filename:f});
 const run=s=>vm.runInContext(s,x);
 run(`var S={players:{host:{name:'一'},guest:{name:'二'}}};var a=advInit(72);for(const [r,cls] of [['host','blade'],['guest','weaver']]){advReduce(a,{type:'pickClass',cls},r);advReduce(a,{type:'ready'},r,S.players);}genMap(a);combatStart(a,['siren'],'boss');`);
 return {x,run,json:s=>JSON.parse(run('JSON.stringify('+s+')'))};
}
test('新战斗创建五乘四棋盘和双方各自的公开行动队列',()=>{
 const h=fixture(),b=h.json('a.combat.board||null');
 assert.ok(b,'New combats must have tactical board state');
 assert.equal(b.width,5);assert.equal(b.height,4);
 assert.deepEqual(b.queues,{host:[],guest:[]});
 assert.deepEqual(b.locked,{host:false,guest:false});
 assert.ok(b.positions.host&&b.positions.guest&&b.positions.e0);
});

function boardFixture(){const h=fixture();assert.ok(h.run('a.combat.board'),'Tactical rules are loaded');return h;}
function queue(h,role,action){h.run(`advReduce(a,${JSON.stringify({type:'boardQueue',...action})},${JSON.stringify(role)},S.players)`);}
function command(h,role,action){h.run(`advReduce(a,${JSON.stringify(action)},${JSON.stringify(role)},S.players)`);}
function clearArena(h){h.run(`a.combat.board.tiles=[];a.combat.board.threats=[];a.combat.board.positions={host:{x:0,y:3},guest:{x:4,y:3},e0:{x:2,y:0}};a.combat.enemies[0].hp=500;a.combat.enemies[0].maxhp=500;for(const r of ROLES){a.players[r].block=0;a.players[r].status={};}`);}
function preview(h){return h.json('boardPreview(a)');}
function boardTest(name,fn){test(name,{skip:!fs.existsSync(boardFile)},fn);}

function plan(h,role,action){h.run(`a.combat.board.queues[${JSON.stringify(role)}]=[${JSON.stringify(action)}]`);}
boardTest('每人选一招就准备好，等待期间不执行也不扣能量',()=>{
 const h=boardFixture();clearArena(h);const energy=h.run('a.players.host.energy'),hp=h.run('a.combat.enemies[0].hp');
 queue(h,'host',{kind:'skill',skill:'blade_slash',target:'e0'});
 assert.equal(h.run('a.combat.enemies[0].hp'),hp);assert.equal(h.run('a.players.host.energy'),energy);
 assert.equal(h.run('a.combat.board.locked.host'),true);
 assert.equal(h.run('a.combat.board.queues.host.length'),1);assert.equal(h.run('a.combat.turn'),1);
});
boardTest('重复提交不能替换已准备的动作，撤回后可重新选招',()=>{
 const h=boardFixture();clearArena(h);queue(h,'host',{kind:'guard'});queue(h,'host',{kind:'move',x:0,y:2});
 assert.equal(h.run('a.combat.board.queues.host.length'),1);assert.equal(h.run('a.combat.board.queues.host[0].kind'),'guard');
 command(h,'host',{type:'boardUnlock'});
 assert.deepEqual(h.json('a.combat.board.queues.host'),[]);assert.equal(h.run('a.combat.board.locked.host'),false);
 queue(h,'host',{kind:'move',x:0,y:2});assert.equal(h.run('a.combat.board.queues.host[0].kind'),'move');
});
boardTest('能量不足时不能提交动作且不会被锁定',()=>{
 const h=boardFixture();clearArena(h);h.run('a.players.host.energy=0');queue(h,'host',{kind:'guard'});
 assert.deepEqual(h.json('a.combat.board.queues.host'),[]);assert.equal(h.run('a.combat.board.locked.host'),false);
 h.run('a.players.host.energy=1');queue(h,'host',{kind:'guard'});
 assert.equal(h.run('boardQueueCost(a,"host")'),1);assert.equal(h.run('a.players.host.energy'),1);
});
boardTest('非法坐标、未知动作和无效敌人不会进入队列',()=>{
 const h=boardFixture();clearArena(h);
 for(const action of [{kind:'move',x:-1,y:0},{kind:'move',x:5,y:0},{kind:'move',x:0,y:4},{kind:'move',x:1.5,y:0},{kind:'move',x:'1',y:0},{kind:'ignite',x:0,y:null},{kind:'push',target:'missing'},{kind:'push',target:'host'},{kind:'skill',skill:'not-a-skill',target:'e0'},{kind:'dance'}])queue(h,'host',action);
 assert.deepEqual(h.json('a.combat.board.queues.host'),[]);assert.equal(h.run('a.players.host.energy'),3);
});
boardTest('双方各选一招会自动执行并进入新回合，无需额外锁定按钮',()=>{
 const h=boardFixture();clearArena(h);queue(h,'host',{kind:'move',x:1,y:3});
 assert.equal(h.run('a.combat.turn'),1);assert.deepEqual(h.json('a.combat.board.positions.host'),{x:0,y:3});
 queue(h,'guest',{kind:'guard'});
 assert.equal(h.run('a.combat.turn'),2);assert.deepEqual(h.json('a.combat.board.positions.host'),{x:1,y:3});
 assert.deepEqual(h.json('a.combat.board.queues'),{host:[],guest:[]});
 assert.deepEqual(h.json('a.combat.board.locked'),{host:false,guest:false});
});
boardTest('系统自动先走位再推拉，给连锁让出位置',()=>{
 const h=boardFixture();clearArena(h);h.run(`a.combat.board.positions={host:{x:0,y:1},guest:{x:2,y:1},e0:{x:1,y:1}};`);
 plan(h,'host',{kind:'push',target:'e0'});plan(h,'guest',{kind:'move',x:3,y:1});const p=preview(h);
 assert.deepEqual(p.steps.map(s=>s.role),['guest','host']);assert.deepEqual(p.board.positions.e0,{x:2,y:1});assert.equal(p.enemies[0].hp,500);
});
boardTest('系统自动先推怪再出技能，双方提交先后不改变配合顺序',()=>{
 const h=boardFixture();clearArena(h);h.run(`a.combat.board.positions={host:{x:0,y:3},guest:{x:0,y:1},e0:{x:1,y:1}};`);
 plan(h,'host',{kind:'skill',skill:'blade_slash',target:'e0'});plan(h,'guest',{kind:'push',target:'e0'});
 assert.deepEqual(preview(h).steps.map(s=>s.role),['guest','host']);
});
boardTest('执行时目标已失效不会自动攻击别人，也不消耗能量',()=>{
 const h=boardFixture();clearArena(h);plan(h,'host',{kind:'skill',skill:'blade_slash',target:'e0'});h.run("a.combat.enemies.push({...clone(a.combat.enemies[0]),uid:'e1'});a.combat.board.positions.e1={x:4,y:0};a.combat.enemies[0].hp=0");
 const p=preview(h);assert.equal(p.players.host.energy,h.run('a.players.host.energy'));
 assert.equal(p.steps.length,1);assert.equal(p.steps[0].ok,false);assert.ok(p.steps[0].text);assert.equal(p.enemies[1].hp,500,'Must not retarget to the surviving enemy');
});
boardTest('移动能躲开已经亮出的敌人攻击格，留在原格会受伤',()=>{
 const h=boardFixture();clearArena(h);h.run(`a.combat.board.positions.host={x:1,y:3};a.combat.board.threats=[{enemy:'e0',cells:[{x:1,y:3}],intent:{type:'attack',v:10,target:'host'}}];`);
 const before=h.run('a.players.host.hp');queue(h,'host',{kind:'move',x:1,y:2});queue(h,'guest',{kind:'guard'});
 assert.equal(h.run('a.players.host.hp'),before);assert.deepEqual(h.json('a.combat.board.positions.host'),{x:1,y:2});
 const hit=boardFixture();clearArena(hit);hit.run(`a.combat.board.positions.host={x:1,y:3};a.combat.board.threats=[{enemy:'e0',cells:[{x:1,y:3}],intent:{type:'attack',v:10,target:'host'}}];`);
 const old=hit.run('a.players.host.hp');queue(hit,'host',{kind:'skill',skill:'blade_slash',target:'e0'});queue(hit,'guest',{kind:'guard'});
 assert.ok(hit.run('a.players.host.hp')<old,'Staying inside the same telegraph must actually get hit');
});
boardTest('推到油地会再滑一格，撞墙造成四点伤害',()=>{
 const h=boardFixture();clearArena(h);h.run(`a.combat.board.positions.host={x:0,y:1};a.combat.board.positions.e0={x:1,y:1};a.combat.board.tiles=[{kind:'oil',x:2,y:1}];`);
 plan(h,'host',{kind:'push',target:'e0'});let p=preview(h);assert.deepEqual(p.board.positions.e0,{x:3,y:1});
 h.run(`a.combat.board.tiles.push({kind:'wall',x:3,y:1})`);p=preview(h);
 assert.deepEqual(p.board.positions.e0,{x:2,y:1});assert.equal(p.enemies[0].hp,496);
});
boardTest('拉扯把敌人拉近一格，距离不够时不会扣费',()=>{
 const h=boardFixture();clearArena(h);h.run(`a.combat.board.positions.host={x:0,y:1};a.combat.board.positions.e0={x:2,y:1};`);
 plan(h,'host',{kind:'pull',target:'e0'});let p=preview(h);assert.deepEqual(p.board.positions.e0,{x:1,y:1});
 h.run(`a.combat.board.positions.e0={x:4,y:1}`);p=preview(h);assert.equal(p.steps[0].ok,false);assert.equal(p.players.host.energy,3);
});
boardTest('引爆炸桶会同时伤及旁边敌人与队友',()=>{
 const h=boardFixture();clearArena(h);h.run(`a.combat.board.positions={host:{x:0,y:1},guest:{x:2,y:2},e0:{x:3,y:1}};a.combat.board.tiles=[{kind:'barrel',x:2,y:1}];`);
 const hp=h.run('a.players.guest.hp');plan(h,'host',{kind:'ignite',x:2,y:1});const p=preview(h);
 assert.equal(p.enemies[0].hp,492);assert.equal(p.players.guest.hp,hp-8);assert.equal(p.board.tiles.some(t=>t.kind==='barrel'),false);
});
boardTest('将怪推入场上陷阱造成八点伤害和眩晕，机关用后消失',()=>{
 const h=boardFixture();clearArena(h);h.run(`a.combat.board.positions={host:{x:0,y:1},guest:{x:2,y:2},e0:{x:1,y:1}};a.combat.board.tiles=[{kind:'trap',x:2,y:1,owner:'guest'}];`);
 plan(h,'host',{kind:'push',target:'e0'});const p=preview(h);
 assert.equal(p.enemies[0].hp,492);assert.equal(p.enemies[0].status.stun,1);assert.equal(p.board.tiles.some(t=>t.kind==='trap'),false);
});
boardTest('重复预览不会改变真实随机数、生命、奖励或演出序列',()=>{
 const h=boardFixture();clearArena(h);plan(h,'host',{kind:'skill',skill:'blade_slash',target:'e0'});plan(h,'guest',{kind:'guard'});
 const before=h.run('JSON.stringify(a)'),one=preview(h),two=preview(h);assert.deepEqual(one,two);assert.equal(h.run('JSON.stringify(a)'),before);
});
boardTest('倒下的旅伴不阻止存活玩家选择动作后推进下一轮',()=>{
 const h=boardFixture();clearArena(h);h.run(`a.players.guest.hp=0;a.players.guest.down=true;a.combat.ended.guest=true;`);queue(h,'host',{kind:'guard'});
 assert.equal(h.run('a.combat.turn'),2);assert.equal(h.run('a.phase'),'combat');
});
boardTest('序列化重载保留准备状态，旅伴选招后能正常继续',()=>{
 const h=boardFixture();clearArena(h);queue(h,'host',{kind:'move',x:1,y:3});h.run('a=JSON.parse(JSON.stringify(a))');
 assert.equal(h.run('a.combat.board.locked.host'),true);queue(h,'guest',{kind:'guard'});
 assert.equal(h.run('a.combat.turn'),2);assert.deepEqual(h.json('a.combat.board.positions.host'),{x:1,y:3});
});
boardTest('同类动作先后手逐轮轮换，玩家不用额外排顺序',()=>{
 const h=boardFixture();clearArena(h);plan(h,'host',{kind:'guard'});plan(h,'guest',{kind:'guard'});
 assert.deepEqual(preview(h).steps.map(s=>s.role),['host','guest']);
 h.run('a.combat.turn=2;a.combat.board.round=2');assert.deepEqual(preview(h).steps.map(s=>s.role),['guest','host']);
});
boardTest('已开始的旧存档战斗保持原技能行为，后续新战斗才启用棋盘',()=>{
 const h=boardFixture();clearArena(h);h.run('delete a.combat.board');const before=h.run('a.combat.enemies[0].hp');
 command(h,'host',{type:'useSkill',skill:'blade_slash',target:'e0'});
 assert.ok(h.run('a.combat.enemies[0].hp')<before);assert.equal(h.run('a.combat.board'),undefined);
});
boardTest('自动旅伴零能量时选择等待，安全格和低血危险格都不会卡住回合',()=>{
 for(const danger of [false,true]){
  const h=boardFixture();clearArena(h);
  h.run(`a.players.guest.energy=0;for(const id of a.players.guest.skills)a.players.guest.cd[id]=1;`);
  if(danger)h.run(`a.players.guest.hp=Math.floor(a.players.guest.maxhp*.6);a.combat.board.threats=[{enemy:'e0',cells:[{x:4,y:3}],intent:{type:'attack',v:1,target:'guest'}}];`);
  queue(h,'host',{kind:'guard'});
  assert.equal(h.run('boardCompanionStep(a)'),true,`Zero-energy companion must submit a free action, danger=${danger}`);
  assert.equal(h.run('a.combat.turn'),2,`The pending round must resolve, danger=${danger}`);
  const step=h.json('a.combat.board.last.find(s=>s.role==="guest")');
  assert.equal(step.action.kind,'wait');assert.equal(step.ok,true);
 }
});
boardTest('已经眩晕的敌人本轮不会攻击，危险预告也不应点亮攻击格',()=>{
 const h=boardFixture();clearArena(h);
 h.run(`a.combat.enemies[0].status.stun=1;boardForecast(a);`);
 assert.deepEqual(h.json('a.combat.board.threats.find(t=>t.enemy==="e0").cells'),[]);
 h.run(`a.combat.enemies[0].status.stun=0;boardForecast(a);`);
 assert.ok(h.run('a.combat.board.threats.find(t=>t.enemy==="e0").cells.length')>0,'The attack telegraph must return when the stun expires');
});
boardTest('推入陷阱的敌人当轮不能攻击或移动，眩晕结束后才恢复前进',()=>{
 const h=boardFixture();clearArena(h);
 h.run(`a.combat.board.positions={host:{x:1,y:3},guest:{x:4,y:3},e0:{x:1,y:1}};a.combat.board.tiles=[{kind:'trap',x:1,y:0}];a.combat.board.threats=[{enemy:'e0',cells:[{x:1,y:3}],intent:{type:'attack',v:10,target:'host'}}];`);
 const hp=h.run('a.players.host.hp');queue(h,'host',{kind:'push',target:'e0'});queue(h,'guest',{kind:'wait'});
 assert.equal(h.run('a.combat.turn'),2);assert.equal(h.run('a.players.host.hp'),hp);
 assert.deepEqual(h.json('a.combat.board.positions.e0'),{x:1,y:0},'A stunned enemy must stay on its trap landing cell');
 assert.equal(h.run('a.combat.enemies[0].status.stun'),0);
 queue(h,'host',{kind:'wait'});queue(h,'guest',{kind:'wait'});
 assert.deepEqual(h.json('a.combat.board.positions.e0'),{x:1,y:1},'Movement resumes on the next unstunned round');
});
boardTest('连击敌人被第一击反伤击杀后，不再攻击第二位玩家或继续后续连击',()=>{
 const h=boardFixture();clearArena(h);
 h.run(`a.combat.enemies.push({...clone(a.combat.enemies[0]),uid:'e1'});a.combat.board.positions.e1={x:4,y:0};a.combat.enemies[0].hp=1;a.combat.enemies[0].dmgMul=1;a.players.host.status.thorns=1;a.players.host.energy=0;a.players.guest.energy=0;a.combat.board.threats=[{enemy:'e0',cells:[{x:0,y:3},{x:4,y:3}],intent:{type:'multi',v:5,hits:3,target:'both'}}];`);
 const hp=h.json('({host:a.players.host.hp,guest:a.players.guest.hp})');
 queue(h,'host',{kind:'wait'});queue(h,'guest',{kind:'wait'});
 assert.equal(h.run('a.combat.enemies[0].hp'),0);assert.equal(h.run('a.combat.turn'),2);
 assert.equal(h.run('a.players.host.hp'),hp.host-5,'The first strike should land before its thorns retaliation');
 assert.equal(h.run('a.players.guest.hp'),hp.guest,'A defeated attacker cannot finish the same strike against the partner');
});
