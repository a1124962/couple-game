const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const {test}=require('node:test');
const root=path.resolve(__dirname,'..');
const source=fs.readFileSync(path.join(root,'data/npc-voices-neighbors.js'),'utf8');
const plain=value=>JSON.parse(JSON.stringify(value));

function fixture(patch=true){
 const c={console,Date,Math};c.window=c;vm.createContext(c);
 for(const file of ['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','engine.js','R.js','narrative-ui.js','visual-novel.js','data/lively-city.js','data/street-stories.js','data/main-story-revision.js']){
  vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),c,{filename:file});
 }
 const before=plain(c.GAME_DATA.npcs);
 if(patch)vm.runInContext(source,c,{filename:'data/npc-voices-neighbors.js'});
 const run=script=>vm.runInContext(script,c);
 run(`var S={players:{host:{name:'阿雨'},guest:{name:'小舟'}},adv:null};
 function start(person,act,node='start'){
  const a=advInit(70521);
  for(const [role,cls] of [['host','blade'],['guest','weaver']]){
   advReduce(a,{type:'pickClass',cls},role,S.players);
   advReduce(a,{type:'ready'},role,S.players);
  }
  a.act=act;S.adv=a;enterNode(a,{id:'neighbors',type:'npc',npcId:person});
  a.npc.node=node;return a;
 }
 function choose(a,index){for(const role of ROLES)advReduce(a,{type:'npcChoice',idx:index},role,S.players);}
 function mechanics(a){
  const clean=clone(a);delete clean.journal;
  if(clean.npc){delete clean.npc.trail;delete clean.npc.lastText;}
  return clean;
 }
 function tryOption(person,act,node,index){
  const a=start(person,act,node);
  const m=GD().npcs.find(n=>n.id===person).meetings.find(m=>m.act===act);
  const q=choiceReq(m.nodes[node].choices[index]);
  a.bond=q.bondMax??90;a.gold=500;
  a.flags=[q.flag,...(q.flags||[])].filter(Boolean);
  if(q.cls)a.players.host.cls=q.cls;
  if(q.npc)a.npcAff[q.npc.id]=q.npc.v;
  if(!hasReq(a,q))throw Error('Test did not satisfy choice requirement');
  choose(a,index);return mechanics(a);
 }`);
 return {c,before,run,json:script=>plain(run(script))};
}

test('80 个节点保留，74 处分支改为短口语对话，门槛和奖励完全不变',()=>{
 const {c,before}=fixture();let count=0;
 for(const npc of c.GAME_DATA.npcs){
  const original=before.find(n=>n.id===npc.id);
  if(!['holt','pip'].includes(npc.id)){assert.deepEqual(plain(npc),original);continue;}
  let characterCount=0;
  for(const meeting of npc.meetings){
   const previous=original.meetings.find(m=>m.act===meeting.act);
   assert.deepEqual(Object.keys(meeting.nodes),Object.keys(previous.nodes));
   for(const [id,node] of Object.entries(meeting.nodes)){
    const old=previous.nodes[id];const restored=plain(node);
    assert.notEqual(node.text,old.text,npc.id+':'+meeting.act+':'+id);
    if(id==='start')assert.ok(node.text.length>=80,'The existing opening remains for the later opening patch');
    else {
     const turns=node.text.split(/\n\n+/);
     assert.ok(turns.length>=2&&turns.length<=4,'A branch takes two to four short turns: '+id);
     assert.ok(turns.every(line=>/^【(?:host|guest|holt|pip|stage):(?:neutral|smile|annoyed)】/.test(line)),'Every spoken line has a cast identity: '+id);
     assert.ok(node.text.length<=250,'A branch must not expand into a prose page: '+id);
    }
    assert.equal(node.choices.length,old.choices.length);
    restored.text=old.text;
    restored.choices.forEach((choice,index)=>{
     assert.ok(choice.label.trim());choice.label=old.choices[index].label;
     if(npc.id==='pip'&&meeting.act===1&&id==='count'&&index===0){
      assert.match(choice.hint,/失去名字.*面具.*不能撤回/);
      if('hint' in old.choices[index])choice.hint=old.choices[index].hint;else delete choice.hint;
     }
    });
    assert.deepEqual(restored,old,'Only text and labels may change: '+id);
    count++;characterCount++;
   }
  }
  assert.equal(characterCount,npc.id==='holt'?37:43);
 }
 assert.equal(count,80);
 assert.deepEqual(plain(c.GAME_DATA.npcNeighborVoices),{version:1,nodes:80});
});

test('六张对话图的引用完整，每个节点从 start 可达',()=>{
 const {c}=fixture();
 for(const npc of c.GAME_DATA.npcs.filter(n=>['holt','pip'].includes(n.id))){
  for(const meeting of npc.meetings){
   const queue=['start'],seen=new Set();
   while(queue.length){
    const id=queue.pop();if(seen.has(id))continue;seen.add(id);
    const node=meeting.nodes[id];assert.ok(node,'Dangling node reference '+id);
    for(const choice of node.choices||[]){
     if(choice.next){assert.ok(meeting.nodes[choice.next]);queue.push(choice.next);}
     if(choice.req?.cls)assert.ok(c.GAME_DATA.classes.some(cls=>cls.id===choice.req.cls));
     for(const effect of choice.effects||[])if(effect.op==='npc')assert.ok(c.GAME_DATA.npcs.some(n=>n.id===effect.id));
    }
   }
   assert.equal(seen.size,Object.keys(meeting.nodes).length,npc.id+':'+meeting.act);
  }
 }
});

test('每个选项通过真实双人 reducer 执行，改稿前后玩法状态逐项相同',()=>{
 const old=fixture(false),current=fixture();let count=0;
 for(const npc of old.before.filter(n=>['holt','pip'].includes(n.id))){
  for(const meeting of npc.meetings)for(const [id,node] of Object.entries(meeting.nodes)){
   node.choices.forEach((_,index)=>{
    const call=`tryOption(${JSON.stringify(npc.id)},${meeting.act},${JSON.stringify(id)},${index})`;
    assert.deepEqual(current.json(call),old.json(call),npc.id+':'+meeting.act+':'+id+':'+index);
    count++;
   });
  }
 }
 assert.ok(count>150);
});

test('孙名、母亲和付费选项仍按原条件开放，不会因新台词提前解锁',()=>{
 const {run,json}=fixture();
 run(`var a=start('holt',3,'approach');a.bond=90;var held=JSON.stringify(a);choose(a,2);`);
 assert.equal(run('JSON.stringify(a)'),run('held'));
 run(`a.flags.push('quiet_open');choose(a,2);`);
 assert.equal(run('a.npc.node'),'grandson');
 run(`a=start('pip',3,'meet_mother');a.bond=69;held=JSON.stringify(a);choose(a,2);`);
 assert.equal(run('JSON.stringify(a)'),run('held'));
 run(`a.bond=70;choose(a,2);`);assert.equal(run('a.npc.node'),'hidden_1');
 run(`a=start('pip',2);held=JSON.stringify(a);choose(a,3);`);
 assert.equal(run('JSON.stringify(a)'),run('held'));
 run(`a.flags.push('name_sold');choose(a,3);`);assert.equal(run('a.npc.node'),'remember');
 run(`a=start('pip',2,'market_delay');a.gold=1;held=JSON.stringify(a);choose(a,1);`);
 assert.equal(run('JSON.stringify(a)'),run('held'));
 run(`a.gold=2;choose(a,1);`);assert.equal(run('a.gold'),0);assert.equal(run('a.npc.node'),'buy_bun');
 assert.equal(json('a.flags').includes('pip_mother'),false);
});

test('三种母亲结果各自完成，开闸后劝回仍保留沉城后果',()=>{
 const {run}=fixture();
 for(const [node,choices,end] of [
  ['demand_1',[0,0],'demand_end'],
  ['accept_1',[0,0],'accept_end'],
  ['hidden_1',[0,0,0],'hidden_end']
 ]){
  run(`var a=start('pip',3,${JSON.stringify(node)});a.bond=80;for(const index of ${JSON.stringify(choices)})choose(a,index);`);
  assert.equal(run('a.npc.node'),end);assert.equal(run('a.npc.ended'),true);
  assert.equal(run(`a.flags.filter(f=>f==='pip_mother').length`),1);
 }
 run(`a=start('holt',3,'oppose');a.bond=80;choose(a,1);choose(a,1);choose(a,0);choose(a,0);`);
 assert.equal(run('a.npc.ended'),true);
 assert.equal(run(`a.flags.includes('city_sink')`),true);
 assert.equal(run(`a.flags.includes('holt_trust')`),true);
 run(`a=start('holt',3,'oppose');a.bond=80;choose(a,0);choose(a,2);choose(a,0);`);
 assert.equal(run('a.npc.ended'),true);
 assert.equal(run(`a.flags.includes('city_sink')`),false);
 // Collapsing in the second meeting never gained a new death flag.
 run(`a=start('holt',2,'fall');choose(a,0);`);
 assert.equal(run('a.flags.length'),0);assert.equal(run('a.npc.ended'),true);
});

test('旧 flag 的长期后果在选择前讲明，交名与不交名仍走不同回家结局',()=>{
 const {c,run}=fixture();
 const count=c.GAME_DATA.npcs.find(n=>n.id==='pip').meetings[0].nodes.count;
 assert.match(count.text,/名字不退/);assert.match(count.text,/认不出彼此/);
 assert.match(count.choices[0].label,/交出名字.*面具/);
 assert.match(count.choices[0].hint,/不能撤回/);
 for(const [choice,ending] of [[0,'masked'],[1,'return']]){
  run(`var a=start('pip',1,'count');choose(a,${choice});a.phase='finale';a.bond=90;a.memories=[0,1,2];for(const role of ROLES)advReduce(a,{type:'finalChoice',choice:'return'},role);`);
  assert.equal(run('a.ending.id'),ending);
 }
});

test('汇合节点不凭空发地图、宣告死亡，静默者线索需当场核对才能补全孙名',()=>{
 const {c}=fixture();const meetings=c.GAME_DATA.npcs.find(n=>n.id==='holt').meetings;
 assert.match(meetings[0].nodes.bridge_cross.text,/看清路牌/);
 assert.doesNotMatch(meetings[0].nodes.bridge_cross.text,/看了地图/);
 assert.match(meetings[1].nodes.fall.text,/昏了过去，仍有呼吸/);
 assert.match(meetings[1].nodes.fall.text,/送进值班室休息/);
 const last=meetings[2].nodes;
 assert.match(last.grandson.text,/半截绣字/);assert.match(last.grandson.text,/老人自己补上/);
 for(const node of Object.values(last))for(const choice of node.choices){
  if(choice.req?.flag==='quiet_open'){
   assert.match(choice.label,/线索/);
   assert.doesNotMatch(choice.label,/已.*(孙子|名字|姓名)|交还.*名字|找到.*名字/);
  }
 }
});

test('旧存档中的节点与待确认选择能续读，重复指令不重复给信任和羁绊',()=>{
 const f=fixture(false);const {run,c}=f;
 run(`var a=start('holt',3,'remember_offer');a.bond=70;advReduce(a,{type:'npcChoice',idx:0},'host');var saved=JSON.stringify(a);`);
 vm.runInContext(source,c);
 run(`a=JSON.parse(saved);S.adv=a;advReduce(a,{type:'npcChoice',idx:0},'guest');`);
 assert.equal(run('a.npc.node'),'agree_remember');assert.equal(run('a.bond'),73);
 assert.equal(run('a.npcAff.holt'),2);
 run(`a.npc.node='remember_offer';choose(a,0);`);
 assert.equal(run('a.bond'),73);assert.equal(run('a.npcAff.holt'),2);
 assert.equal(run(`a.flags.filter(f=>f==='holt_trust').length`),1);
});

test('四处 CITY 回调保留，存档手记固定当时的正文和称呼',()=>{
 const {c,run,json}=fixture();
 for(const person of ['holt','pip'])for(const act of [2,3]){
  const text=c.GAME_DATA.npcs.find(n=>n.id===person).meetings.find(m=>m.act===act).nodes.start.text;
  assert.equal((text.match(new RegExp('\\{CITY:'+person+'\\}','g'))||[]).length,1);
  run(`var a=start(${JSON.stringify(person)},${act});`);
  assert.equal(run(`advText(${JSON.stringify(text)})`).includes('{CITY:'),false);
 }
 run(`a=start('holt',3);a.flags=['city_clock_dialect'];choose(a,1);advReduce(a,{type:'npcLeave'},'host');advReduce(a,{type:'npcLeave'},'guest');var entry=clone(a.journal.at(-1));`);
 assert.ok(run('entry.trail[0].text').includes('有口音'));
 assert.equal(run('entry.trail[0].text').includes('{CITY:'),false);
 const frozen=json('entry');run(`S.adv=start('holt',3);`);assert.deepEqual(json('entry'),frozen);
});

test('原稿副本独立保存，重复加载不叠文案、不覆盖已保存的原稿',()=>{
 const {c,before}=fixture();
 for(const person of ['holt','pip'])for(const meeting of before.find(n=>n.id===person).meetings){
  assert.deepEqual(plain(c.GAME_DATA.npcNeighborVoiceOriginals[person][meeting.act]),meeting.nodes);
 }
 const once=JSON.stringify(c.GAME_DATA.npcs),archive=JSON.stringify(c.GAME_DATA.npcNeighborVoiceOriginals);
 vm.runInContext(source,c);assert.equal(JSON.stringify(c.GAME_DATA.npcs),once);
 c.GAME_DATA.npcs.find(n=>n.id==='holt').meetings[0].nodes.start.text='测试修改';
 assert.equal(JSON.stringify(c.GAME_DATA.npcNeighborVoiceOriginals),archive);
});
