const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const assert=require('node:assert/strict'),{test}=require('node:test');
const root=path.resolve(__dirname,'..'),plain=o=>JSON.parse(JSON.stringify(o));
const source=fs.readFileSync(path.join(root,'data/old-interludes-dialogue.js'),'utf8');
function fixture(){
 const c={console,Date,Math};c.window=c;vm.createContext(c);
 for(const file of ['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','engine.js','R.js','narrative-ui.js','data/lively-city.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),c,{filename:file});
 const before=plain(c.GAME_DATA.interludes),run=code=>vm.runInContext(code,c);run(source);
 return {c,before,run};
}
test('原九场互动仅改对话与舞台元信息，选项、私有线索、答案、奖励均原样',()=>{
 const {c,before}=fixture();assert.equal(Object.keys(c.GAME_DATA.oldInterludeDialogueOriginals).length,9);
 assert.deepEqual(plain(c.GAME_DATA.oldInterludeDialogueOriginals),Object.fromEntries(before.map(d=>[d.id,d])));
 for(const d of c.GAME_DATA.interludes){
  const old=before.find(x=>x.id===d.id),restored=plain(d);
  assert.notEqual(d.text,old.text);restored.text=old.text;
  for(const key of ['success','fail'])if(d[key]!==undefined){assert.notEqual(d[key],old[key]);restored[key]=old[key];}
  if(d.results)d.results.forEach((r,i)=>{assert.notEqual(r.text,old.results[i].text);restored.results[i].text=old.results[i].text;});
  if(d.spots)d.spots.forEach((p,i)=>{assert.notEqual(p[1],old.spots[i][1]);restored.spots[i][1]=old.spots[i][1];});
  if('stage' in old)restored.stage=old.stage;else delete restored.stage;
  assert.deepEqual(restored,old,d.id);
 }
});
test('改写段落都有明确说话人或短舞台动作，开场不把两人的私有答案提前拼出',()=>{
 const {c}=fixture();let passages=0;
 for(const d of c.GAME_DATA.interludes){
  const texts=[d.text,d.success,d.fail,...(d.spots||[]).map(p=>p[1]),...(d.results||[]).map(r=>r.text)].filter(Boolean);
  for(const text of texts){
   for(const paragraph of text.split(/\n\n+/))assert.match(paragraph,/^【(?:stage|(?:host|guest|mara|quill|holt|pip|quiet):(?:neutral|smile))】/);
   const dialogue=text.split(/\n\n+/).filter(p=>!p.startsWith('【stage】'));
   assert.ok(dialogue.length>=2);passages++;
  }
  if(d.kind==='puzzle')assert.ok(d.clues.host&&d.clues.guest);
 }
 assert.equal(passages,39);
});
test('旧互动对话覆盖幂等，原稿备份不随二次加载而变',()=>{
 const {run}=fixture();run('var previous=JSON.stringify(GAME_DATA.interludes),archive=JSON.stringify(GAME_DATA.oldInterludeDialogueOriginals);');
 run(source);assert.equal(run('JSON.stringify(GAME_DATA.interludes)'),run('previous'));assert.equal(run('JSON.stringify(GAME_DATA.oldInterludeDialogueOriginals)'),run('archive'));
});
