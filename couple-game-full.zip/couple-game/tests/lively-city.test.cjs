const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const base=path.resolve(__dirname,'..');
const x={console,Date,Math};x.window=x;vm.createContext(x);
for(const file of ['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','engine.js','R.js','narrative-ui.js'])vm.runInContext(fs.readFileSync(path.join(base,file),'utf8'),x,{filename:file});
const before=JSON.parse(JSON.stringify(x.GAME_DATA));
const source=fs.readFileSync(path.join(base,'data/lively-city.js'),'utf8');
vm.runInContext(source,x,{filename:'data/lively-city.js'});
const run=script=>vm.runInContext(script,x);
run(`var S={players:{host:{name:'阿雨'},guest:{name:'小舟'}},adv:null};var session={kind:'online',role:'host'};var ui={fullText:true,readPages:{}};var settings={};
function start(act=1){let a=advInit(921);for(const [r,cls] of [['host','blade'],['guest','weaver']]){advReduce(a,{type:'pickClass',cls},r,S.players);advReduce(a,{type:'ready'},r,S.players);}a.act=act;S.adv=a;return a;}
function play(act,i,j){let a=start(act);enterNode(a,{id:'test-scene',type:'interlude',sceneId:'duo_'+act});advReduce(a,{type:'scenePick',idx:i},'host',S.players);advReduce(a,{type:'scenePick',idx:j},'guest',S.players);return a;}`);
let count=0;function test(label,fn){fn();count++;console.log('✓ '+label);}

test('保留9场景及原三幕ID，三段生活互动各有2×2完整结果',()=>{
 assert.equal(x.GAME_DATA.interludes.length,9);
 assert.deepEqual(Array.from(x.GAME_DATA.interludes,d=>d.id),before.interludes.map(d=>d.id));
 const flags=new Set();
 for(const d of x.GAME_DATA.interludes.filter(d=>d.kind==='duo')){
  assert.equal(d.options.host.length,2);assert.equal(d.options.guest.length,2);assert.equal(d.results.length,4);
  assert.notEqual(d.clues.host,d.clues.guest);assert.ok(d.clues.host.length>40&&d.clues.guest.length>40);
  for(const result of d.results){assert.ok(result.text.length>150);assert.ok(result.flag);flags.add(result.flag);assert.ok(x.GAME_DATA.flagNames[result.flag]);}
 }
 assert.equal(flags.size,12);
});

test('12种组合按实际选择记录不同flag，失败笑料也给正向收获',()=>{
 const seen=new Set();
 for(let act=1;act<=3;act++)for(let i=0;i<2;i++)for(let j=0;j<2;j++){
  run(`var a=play(${act},${i},${j});`);
  assert.equal(run('a.interlude.done'),true);
  const d=x.GAME_DATA.interludes.find(d=>d.id==='duo_'+act),result=d.results[i*2+j];
  assert.equal(run('a.interlude.result'),result.text);
  assert.equal(run('a.flags.filter(f=>f.startsWith("city_")).length'),1);
  assert.equal(run('a.flags[0]'),result.flag);seen.add(result.flag);
  assert.ok(run('a.bond')>50);assert.ok(run('a.gold')>=40);
  assert.equal(run('a.journal.length'),1);assert.equal(run('a.journal[0].text'),result.text);
  assert.ok(run('a.interlude.summary').includes(x.GAME_DATA.flagNames[result.flag]));
 }
 assert.equal(seen.size,12);
});

test('任意一人先锁定都正确，重复提交不会重复奖励或记第二个结果',()=>{
 run(`var a=start();enterNode(a,{id:'scene',type:'interlude',sceneId:'duo_1'});advReduce(a,{type:'scenePick',idx:1},'guest');`);
 assert.equal(run('a.interlude.done'),false);assert.equal(run('a.flags.length'),0);
 run(`advReduce(a,{type:'scenePick',idx:0},'host');var settled=JSON.stringify(a);for(let i=0;i<3;i++){advReduce(a,{type:'scenePick',idx:1},'host');advReduce(a,{type:'scenePick',idx:0},'guest');}`);
 assert.equal(run('JSON.stringify(a)'),run('settled'));
 assert.equal(run('a.flags[0]'),'city_fish_cakes');
});

test('非法选项与角色不能制造flag或领取结果',()=>{
 run(`var a=start();enterNode(a,{id:'scene',type:'interlude',sceneId:'duo_1'});for(const idx of [-1,2,'0',null])advReduce(a,{type:'scenePick',idx},'host');advReduce(a,{type:'scenePick',idx:0},'stranger');`);
 assert.equal(run('a.interlude.picks.host'),null);assert.equal(run('a.interlude.picks.guest'),null);assert.equal(run('a.flags.length'),0);assert.equal(run('a.gold'),40);
});

test('新增结算只使用支持的flag效果，收获字段有限且非负',()=>{
 for(const d of x.GAME_DATA.interludes.filter(d=>d.kind==='duo'))for(const result of d.results){
  assert.deepEqual(Object.keys(result).filter(k=>!['text','flag','bond','gold','heal'].includes(k)),[]);
  for(const key of ['bond','gold','heal'])if(key in result){assert.ok(Number.isFinite(result[key]));assert.ok(result[key]>=0);}
 }
 run(`var effectsSeen=[];var applyOriginal=applyEffects;applyEffects=function(a,e,r){effectsSeen.push(...e);return applyOriginal(a,e,r);};play(1,1,0);play(2,0,1);play(3,1,1);applyEffects=applyOriginal;`);
 for(const ef of JSON.parse(run('JSON.stringify(effectsSeen)')))assert.ok(['bond','gold','heal','flag'].includes(ef.op));
});

test('双端只显示自己的私有线索，读完前不提前展示选择',()=>{
 for(let act=1;act<=3;act++){
  run(`var a=start(${act});enterNode(a,{id:'scene',type:'interlude',sceneId:'duo_${act}'});ui.fullText=true;`);
  const d=x.GAME_DATA.interludes.find(d=>d.id==='duo_'+act);
  for(const role of ['host','guest']){
   run(`session.role='${role}';`);
   const html=run('interludeView(a)');assert.ok(html.includes('lively-clue'));assert.ok(html.includes(d.clues[role]));assert.equal(html.includes(d.clues[role==='host'?'guest':'host']),false);
  }
  run('ui.fullText=false;ui.readPages={};');const early=run('interludeView(a)');assert.equal(early.includes('lively-clue'),false);assert.equal(early.includes('data-type="scenePick"'),false);
 }
 run('ui.fullText=true;session.role="host";');
});

test('回调由已经发生的组合驱动，序列化存档后仍保留',()=>{
 run(`var a=play(1,0,1);a=JSON.parse(JSON.stringify(a));S.adv=a;`);
 const text=run('advText("{CITY:mara}")');assert.ok(text.includes('鱼饼师傅'));assert.equal(text.includes('镊子'),false);assert.equal(text.includes('{CITY:'),false);
 run(`a.flags=[];`);assert.equal(run('advText("{CITY:mara}")'),'');
 run(`a=play(2,1,1);a=JSON.parse(JSON.stringify(a));S.adv=a;`);assert.ok(run('advText("{CITY:holt}")').includes('有口音'));
 run(`a=play(3,1,0);a=JSON.parse(JSON.stringify(a));S.adv=a;`);assert.ok(run('advText("{CITY:archive}")').includes('热面'));
 assert.ok(run('advText("{CITY:quiet}")').includes('皮普的生日'));
});

test('手记固定当时的回调，之后的新旅程不会改写它',()=>{
 run(`var a=play(1,0,1);a.act=2;enterNode(a,{id:'mara',type:'npc',npcId:'mara'});advReduce(a,{type:'npcLeave'},'host');advReduce(a,{type:'npcLeave'},'guest');var savedEntry=JSON.parse(JSON.stringify(a.journal.at(-1)));`);
 const text=run('savedEntry.trail[0].text');assert.ok(text.includes('鱼饼师傅'));assert.equal(text.includes('{CITY:'),false);
 run('S.adv=start(1);');assert.equal(run('advText(savedEntry.trail[0].text)'),text);
});

test('原长篇、全部旧分支及其他六个互动保持完整',()=>{
 const G=x.GAME_DATA;
 assert.equal(G.events.length,96);assert.equal(G.npcs.flatMap(n=>n.meetings.flatMap(m=>Object.keys(m.nodes))).length,213);
 assert.deepEqual(JSON.parse(JSON.stringify(G.intro)),before.intro);
 assert.deepEqual(JSON.parse(JSON.stringify(G.memories)),before.memories);
 assert.deepEqual(JSON.parse(JSON.stringify(G.endings)),before.endings);
 assert.deepEqual(JSON.parse(JSON.stringify(G.livelyCity.originals.interludes)),before.interludes.filter(d=>d.kind==='duo'));
 for(const d of G.interludes.filter(d=>d.kind!=='duo'))assert.deepEqual(JSON.parse(JSON.stringify(d)),before.interludes.find(b=>b.id===d.id));
 for(const n of G.npcs)for(const m of n.meetings){
  const old=before.npcs.find(b=>b.id===n.id).meetings.find(b=>b.act===m.act);
  assert.ok(m.nodes.start.text.includes(old.nodes.start.text));
  assert.equal(G.livelyCity.originals.openings[n.id+':'+m.act],old.nodes.start.text);
  for(const [id,node] of Object.entries(m.nodes))assert.deepEqual(JSON.parse(JSON.stringify(node.choices||[])),old.nodes[id].choices||[]);
 }
 for(const e of G.events){const old=before.events.find(b=>b.id===e.id);assert.ok(e.text.includes(old.text));assert.deepEqual(JSON.parse(JSON.stringify(e.choices)),old.choices);}
});

test('重复载入模块不会叠加正文、奖励包装或改变其他资料',()=>{
 const once=JSON.stringify(x.GAME_DATA.npcs);vm.runInContext(source,x);
 assert.equal(JSON.stringify(x.GAME_DATA.npcs),once);
 run('var a=play(1,0,0);');assert.equal(run('a.flags.length'),1);assert.equal(run('a.bond'),56);assert.equal(run('a.gold'),54);
});
console.log(count+' lively city tests passed.');
