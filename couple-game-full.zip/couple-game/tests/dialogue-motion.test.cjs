const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {test}=require('node:test'),assert=require('node:assert/strict');
const source=fs.readFileSync(path.join(__dirname,'../dialogue-motion.js'),'utf8');
function classes(...initial){const items=new Set(initial);return {add:v=>items.add(v),remove:v=>items.delete(v),contains:v=>items.has(v)};}
function portrait(id,speaking=false){
 const values={},art={dataset:{dialogueAtlas:id},style:{setProperty:(k,v)=>values[k]=v},values};
 return {art,classList:classes(...speaking?['is-speaking']:[]),querySelector:()=>art};
}
function npc(id,expression=2){const art={dataset:{character:id},style:{expression}};return {art,classList:classes('is-speaking'),querySelector:()=>null};}
function scene(actors){return {isConnected:true,actors,classList:classes(),querySelectorAll:()=>actors};}
function fixture(actors=[portrait('blade',true),npc('quiet')]){
 let now=0,next=0,current=scene(actors);const timers=new Map(),events={},observers=[];
 const preference={matches:false,addEventListener:(event,cb)=>events.preference=cb};
 const document={hidden:false,body:{classList:classes()},getElementById:()=>({}),querySelector:()=>current,addEventListener:(event,cb)=>events[event]=cb};
 const c={document,settings:{motion:true},matchMedia:()=>preference,
  setTimeout:(fn,delay)=>{timers.set(++next,{at:now+delay,fn});return next;},clearTimeout:id=>timers.delete(id),
  addEventListener:(event,cb)=>events[event]=cb,MutationObserver:class{constructor(fn){this.fn=fn;observers.push(this);}observe(){}}
 };c.window=c;vm.createContext(c);vm.runInContext(source,c);
 function tick(ms){const until=now+ms;while(true){const entry=[...timers.entries()].filter(([,v])=>v.at<=until).sort((a,b)=>a[1].at-b[1].at)[0];if(!entry)break;const [id,t]=entry;timers.delete(id);now=t.at;t.fn();}now=until;}
 return {c,actors,events,timers,preference,document,tick,scene:()=>current,setScene:s=>current=s,mount:()=>c.DIALOGUE_MOTION.mount()};
}
test('四职业真实闭眼帧短暂眨眼，发言手势结束后回到待机，不动NPC情绪帧',()=>{
 for(const id of ['blade','warden','weaver','seer']){
  const hero=portrait(id,true),quiet=npc('quiet',1),f=fixture([hero,quiet]);
  assert.equal(hero.art.dataset.motionFrame,'0');f.tick(180);assert.equal(hero.art.dataset.motionFrame,'2');
  f.tick(760);assert.equal(hero.art.dataset.motionFrame,'0');
  const firstBlink=2400+[...id].reduce((n,c)=>n+c.charCodeAt(0),0)%700;
  f.tick(firstBlink-940);assert.equal(hero.art.dataset.motionFrame,'1');f.tick(125);assert.equal(hero.art.dataset.motionFrame,'0');
  assert.deepEqual(quiet.art.style,{expression:1});assert.equal(quiet.art.dataset.motionFrame,undefined);
 }
});
test('重复挂载不叠加计时器；翻页清掉上一页，旧回调不能再换旧立绘',()=>{
 const old=portrait('blade',true),f=fixture([old]),pending=f.timers.size;
 f.mount();f.mount();assert.equal(f.timers.size,pending);
 const oldCallbacks=[...f.timers.values()].map(t=>t.fn),fresh=portrait('weaver');
 f.scene().isConnected=false;f.setScene(scene([fresh]));f.mount();const count=f.timers.size;
 for(const callback of oldCallbacks)callback();
 assert.equal(old.art.dataset.motionFrame,'0');assert.equal(f.timers.size,count);assert.equal(fresh.art.dataset.motionFrame,'0');
});
test('退出剧情与pagehide回收所有定时器，不留下眨眼闭眼帧',()=>{
 const hero=portrait('blade',true),f=fixture([hero]);f.tick(180);assert.equal(hero.art.dataset.motionFrame,'2');
 f.setScene(null);f.mount();assert.equal(f.timers.size,0);assert.equal(hero.art.dataset.motionFrame,'0');assert.equal(f.c.DIALOGUE_MOTION.active,false);
 f.setScene(scene([hero]));f.mount();assert.ok(f.timers.size>0);f.events.pagehide();assert.equal(f.timers.size,0);
});
test('关闭动作、系统减少动态效果、后台隐藏都立即停止，恢复时只装一套计时器',()=>{
 for(const type of ['setting','system','hidden','body']){
  const hero=portrait('warden',true),f=fixture([hero]);f.tick(180);
  if(type==='setting')f.c.settings.motion=false;
  if(type==='system')f.preference.matches=true;
  if(type==='hidden')f.document.hidden=true;
  if(type==='body')f.document.body.classList.add('reduced-motion');
  f.mount();assert.equal(f.timers.size,0,type);assert.equal(hero.art.dataset.motionFrame,'0',type);assert.equal(f.c.DIALOGUE_MOTION.active,false,type);
  f.c.settings.motion=true;f.preference.matches=false;f.document.hidden=false;f.document.body.classList.remove('reduced-motion');f.mount();assert.equal(f.timers.size,2,type);f.mount();assert.equal(f.timers.size,2,type);
 }
});
test('未知图集不切帧；只读取设置，不读写游戏状态或推进随机数',()=>{
 const unknown=portrait('quiet',true),f=fixture([unknown]);assert.equal(unknown.art.dataset.motionFrame,undefined);assert.equal(f.timers.size,0);
 const f2=fixture([portrait('seer')]);f2.c.S={adv:{flags:['keep'],gold:20,rngState:50,pageReady:{host:false,guest:false}}};const before=JSON.stringify(f2.c.S);f2.tick(30000);assert.equal(JSON.stringify(f2.c.S),before);
});
