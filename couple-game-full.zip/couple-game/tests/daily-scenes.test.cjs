const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const assert=require('node:assert/strict');
const {test}=require('node:test');
const root=path.resolve(__dirname,'..');
const common=['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','engine.js','R.js','narrative-ui.js','data/lively-city.js','data/street-stories.js','data/main-story-revision.js','data/npc-voices-neighbors.js','data/npc-voices-mara.js','data/npc-voices-scholar.js','data/old-interludes-dialogue.js'];
const packs=['data/daily-pot.js','data/daily-delivery.js','data/daily-laundry.js'];
const source=fs.readFileSync(path.join(root,'daily-scenes.js'),'utf8');
const plain=value=>JSON.parse(JSON.stringify(value));
function fixture(patch=true){
 const c={console,Date,Math};c.window=c;vm.createContext(c);
 for(const file of [...common,...packs])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),c,{filename:file});
 const before=plain(c.GAME_DATA.interludes),run=code=>vm.runInContext(code,c);
 run(`var S={players:{host:{name:'阿雨'},guest:{name:'小舟'}},adv:null};
 var session={kind:'online',role:'host'},ui={fullText:true,readPages:{}};
 function start(id,seed=83032){
  const a=advInit(seed);
  for(const [role,cls] of [['host','blade'],['guest','weaver']]){
   advReduce(a,{type:'pickClass',cls},role,S.players);advReduce(a,{type:'ready'},role,S.players);
  }
  if(id){
   const d=GD().interludes.find(d=>d.id===id);a.act=d.act;
   for(const p of Object.values(a.players))p.hp=p.maxhp-30;
   enterNode(a,{id:'daily-fixture',type:'interlude',sceneId:id});
  }
  S.adv=a;return a;
 }
 function pick(a,role,index){advReduce(a,{type:'scenePick',idx:index},role,S.players);}
 `);
 if(patch)run(source);
 return {c,before,run,json:code=>plain(run(code))};
}

test('九场新日常各有双人四种结果，旧场景完整保留',()=>{
 const {c,before}=fixture(),g=c.GAME_DATA;
 assert.equal(g.dailyScenes.ids.length,9);assert.equal(g.dailyScenes.flags.length,36);
 assert.deepEqual(plain(g.interludes.slice(0,before.length)),before);
 assert.deepEqual(plain(g.dailyScenes.originals.interludes),before);
 assert.equal(g.interludes.length,before.length+9);
 for(const key of ['pot','delivery','laundry']){
  const pack=g.dailyScenePacks[key];assert.equal(pack.length,3);
  assert.deepEqual(plain(pack.map(d=>d.act)).sort(),[1,2,3]);
  for(const d of pack){
   assert.equal(d.results.length,4);assert.ok(d.stage?.background);assert.ok(d.stage?.cast?.length);
   for(const result of d.results)assert.ok(g.flagNames[result.flag]);
  }
 }
});

test('三幕仍各十六站，九场日常只替换可选支路，全部战斗和人物节点保留',()=>{
 const current=fixture(),old=fixture(false);const found=new Set();
 for(let seed=1;seed<=25;seed++)for(let act=1;act<=3;act++){
  const code=`var a=start(null,${seed});a.act=${act};genMap(a);a.map`;
  const now=current.json(code),before=old.json(code);assert.equal(now.floors.length,16);
  for(let floor=0;floor<16;floor++)if(![3,7,11].includes(floor))assert.deepEqual(now.floors[floor],before.floors[floor]);
  for(const [floor,pack] of [[3,'pot'],[7,'delivery'],[11,'laundry']]){
   assert.equal(now.floors[floor].length,before.floors[floor].length);
   assert.ok(now.floors[floor].length>1,'Daily jobs must be a choice');
   const node=now.floors[floor].find(n=>n.dailySlot===pack),prior=before.floors[floor].find(n=>n.dailySlot===pack);
   assert.equal(node.sceneId,`daily_${pack}_${act}`);assert.equal(node.id,prior.id);
   assert.deepEqual(node.next,prior.next);assert.equal(node.type,'interlude');assert.equal(node.main,false);
   for(const sibling of now.floors[floor].filter(n=>n!==node))assert.deepEqual(sibling,before.floors[floor].find(n=>n.id===sibling.id));
   found.add(node.sceneId);
  }
  assert.equal(now.floors.filter(f=>f.every(n=>['battle','elite'].includes(n.type))).length,7);
  const nodes=now.floors.flat(),index=new Map(nodes.map(n=>[n.id,n])),visited=new Set(),queue=now.floors[0].map(n=>n.id);
  while(queue.length){const id=queue.shift();if(visited.has(id))continue;visited.add(id);const n=index.get(id);assert.ok(n,'broken map edge');for(const next of n.next)queue.push(next);}
  assert.equal(visited.size,nodes.length);assert.equal(nodes.filter(n=>!n.next.length)[0].type,'boss');
 }
 assert.equal(found.size,9);
});

test('旧存档地图不会被加载模块改写，下一幕才生成新路线',()=>{
 const {run}=fixture(false);
 run(`var oldSave=start(null,733);genMap(oldSave);oldSave.map.cur='f8n1';oldSave.map.visited=['f0n0','f8n1'];var previous=JSON.stringify(oldSave);`);
 run(source);assert.equal(run('JSON.stringify(oldSave)'),run('previous'));
 run('oldSave=JSON.parse(previous);oldSave.act=2;genMap(oldSave);');
 assert.equal(run("oldSave.map.floors[3].find(n=>n.dailySlot===\'pot\').sceneId"),'daily_pot_2');
});

test('36种结果在双方任意提交顺序下才结算一次，奖励与持久事实一致',()=>{
 const {c,run}=fixture();
 for(const id of c.GAME_DATA.dailyScenes.ids){
  const d=c.GAME_DATA.interludes.find(d=>d.id===id);
  for(let h=0;h<2;h++)for(let g=0;g<2;g++)for(const first of ['host','guest']){
   const result=d.results[h*2+g],other=first==='host'?'guest':'host';
   run(`var a=start(${JSON.stringify(id)}),before=clone(a);pick(a,${JSON.stringify(first)},${first==='host'?h:g});`);
   assert.equal(run('a.interlude.done'),false);assert.equal(run('a.journal.length'),0);assert.deepEqual(plain(run('a.flags')),[]);
   run(`pick(a,${JSON.stringify(first)},${first==='host'?1-h:1-g});`);
   assert.equal(run(`a.interlude.picks.${first}`),first==='host'?h:g,'already locked answer is unchanged');
   run(`pick(a,${JSON.stringify(other)},${other==='host'?h:g});`);
   assert.equal(run('a.interlude.done'),true);assert.equal(run('a.journal.length'),1);
   assert.equal(run('a.gold-before.gold'),result.gold||0);
   assert.equal(run('a.bond-before.bond'),result.bond);
   assert.equal(run('a.players.host.hp-before.players.host.hp'),Math.min(30,result.heal||0));
   assert.equal(run('a.players.guest.hp-before.players.guest.hp'),Math.min(30,result.heal||0));
   assert.deepEqual(plain(run('a.flags')),[result.flag]);
   assert.doesNotMatch(run('a.interlude.result'),/\{DAILY:/);
   assert.equal(run('a.journal[0].text'),run('a.interlude.result'));
   run(`var saved=JSON.stringify(a);pick(a,'host',${h});pick(a,'guest',${g});completeScene(a,GD().interludes.find(d=>d.id===${JSON.stringify(id)}),'duplicate',[{op:'gold',v:100}]);`);
   assert.equal(run('JSON.stringify(a)'),run('saved'));
  }
 }
});

test('伏笔只按本局真实分支回收，缺少旧经历使用明确备用对白',()=>{
 const {c,run}=fixture();let checked=0;
 for(const id of c.GAME_DATA.dailyScenes.ids){
  const d=c.GAME_DATA.interludes.find(d=>d.id===id);
  for(const [key,branches] of Object.entries(d.callbacks||{})){
   assert.ok(branches.default.trim(),id+': missing first-meeting fallback');
   run(`var a=start(${JSON.stringify(id)});`);
   const token='{DAILY:'+key+'}';
   assert.equal(run(`GD().dailyScenes.resolve(${JSON.stringify(token)},a)`),branches.default);
   for(const [flag,text] of Object.entries(branches).filter(([f])=>f!=='default')){
    run(`a.flags=[${JSON.stringify(flag)}];`);
    assert.equal(run(`GD().dailyScenes.resolve(${JSON.stringify(token)},a)`),text);
    run(`a.flags=['unrelated_'+${JSON.stringify(flag)}];`);
    assert.equal(run(`GD().dailyScenes.resolve(${JSON.stringify(token)},a)`),branches.default);
    checked++;
   }
  }
 }
 assert.ok(checked>=24,'each recurring chain has meaningful previous-choice callbacks');
});

test('回收文本和手记使用传入旅程的事实，刷新与后来的新旅程不改写旧记录',()=>{
 const {c,run}=fixture();
 const d=c.GAME_DATA.interludes.find(d=>d.id.startsWith('daily_')&&Object.keys(d.callbacks||{}).length);
 const [key,branches]=Object.entries(d.callbacks)[0],flag=Object.keys(branches).find(key=>key!=='default');
 run(`var a=start(${JSON.stringify(d.id)});a.flags=[${JSON.stringify(flag)}];a.interlude.picks={host:0,guest:1};
 var foreign=start(${JSON.stringify(d.id)});foreign.flags=[];S.adv=foreign;
 completeScene(a,GD().interludes.find(d=>d.id===${JSON.stringify(d.id)}),${JSON.stringify('{DAILY:'+key+'}')},[]);`);
 assert.equal(run('a.journal[0].text'),branches[flag]);
 run(`var archived=JSON.stringify(a);a=JSON.parse(archived);a.flags=[];S.adv=foreign;advReduce(a,{type:'continue'},'host');advReduce(a,{type:'continue'},'guest');`);
 assert.equal(run('a.journal[0].text'),branches[flag]);assert.equal(run('a.phase'),'map');
});

test('双端只呈现各自线索，单方锁定不泄露答案且不同选择也能继续',()=>{
 const {c,run}=fixture();
 for(const id of c.GAME_DATA.dailyScenes.ids){
  run(`var a=start(${JSON.stringify(id)}),d=GD().interludes.find(d=>d.id===a.interlude.id);d.clues={host:'主端私有线索甲乙丙',guest:'客端私有线索丁戊己'};`);
  for(const role of ['host','guest']){
   const html=run(`session.role=${JSON.stringify(role)};interludeView(a)`);
   assert.ok(html.includes(role==='host'?'主端私有线索甲乙丙':'客端私有线索丁戊己'));
   assert.ok(!html.includes(role==='host'?'客端私有线索丁戊己':'主端私有线索甲乙丙'));
  }
  run("pick(a,'host',1);session.role='guest';");
  assert.ok(run('interludeView(a)').includes('TA 已锁定答案'));
  run("pick(a,'guest',0);advReduce(a,{type:'continue'},'host');advReduce(a,{type:'continue'},'guest');");
  assert.equal(run('a.phase'),'map');
 }
});

test('新模块可重复加载且只安装一次，非法内容在修改共享语料之前失败',()=>{
 const {run}=fixture();run('var snapshot=JSON.stringify(GD().interludes),originals=JSON.stringify(GD().dailyScenes.originals);');
 run(source);assert.equal(run('JSON.stringify(GD().interludes)'),run('snapshot'));assert.equal(run('JSON.stringify(GD().dailyScenes.originals)'),run('originals'));
 const broken=fixture(false);broken.run("var snapshot=JSON.stringify(GD().interludes);GD().dailyScenePacks.delivery[0].results.pop();");
 assert.throws(()=>broken.run(source),/Invalid daily scene/);assert.equal(broken.run('JSON.stringify(GD().interludes)'),broken.run('snapshot'));
});
