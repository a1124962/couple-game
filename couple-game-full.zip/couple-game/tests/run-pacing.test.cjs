'use strict';
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const assert=require('node:assert/strict'),{test}=require('node:test');
const root=path.resolve(__dirname,'..');
function fixture(){
 const c={console,Math,Date,interludeView:()=>'',npcView:()=>'',eventView:()=>''};c.window=c;vm.createContext(c);
 for(const f of ['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','data/combat-cast.js','engine.js','battle-tactics.js','combat-director.js','tactical-board.js','data/lively-city.js','data/street-stories.js','data/main-story-revision.js','data/npc-voices-neighbors.js','data/npc-voices-mara.js','data/npc-voices-scholar.js','data/dialogue-scenes.js','data/old-interludes-dialogue.js','data/daily-pot.js','data/daily-delivery.js','data/daily-laundry.js','daily-scenes.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),c,{filename:f});
 const run=s=>vm.runInContext(s,c);
 run(`var names={host:{name:'甲'},guest:{name:'乙'}};
 function start(seed=40){let a=advInit(seed);for(const [r,cls] of [['host','blade'],['guest','weaver']]){advReduce(a,{type:'pickClass',cls},r,names);advReduce(a,{type:'ready'},r,names);}return a;}
 function both(a,ac){for(const r of ROLES)advReduce(a,ac,r,names);}
 var a=start();`);
 return {c,run,json:s=>JSON.parse(run('JSON.stringify('+s+')'))};
}
test('开场双方确认后直接进入第一场正式棋盘战斗，刷新和重复确认不重新开战',()=>{
 const {run,json}=fixture();
 run("advReduce(a,{type:'continue'},'host',names)");assert.equal(run('a.phase'),'intro');
 run("a=JSON.parse(JSON.stringify(a));advReduce(a,{type:'continue'},'guest',names)");
 assert.equal(run('a.phase'),'combat');assert.equal(run('a.map.cur'),'f0n0');
 assert.equal(run('a.map.pacingVersion'),2);assert.equal(run('a.combat.enemies[0].id'),'sea_rat');
 assert.equal(run('a.combat.enemies.length'),1);assert.ok(run('a.combat.board'));
 assert.deepEqual(json('a.map.visited'),['f0n0']);assert.equal(run('a.stats.nodes'),1);
 run("var before=JSON.stringify(a);both(a,{type:'continue'});");assert.equal(run('JSON.stringify(a)'),run('before'));
});
test('首战击败真实敌人后双方各自三选一，再进入带战斗的路线，不丢失成长',()=>{
 const {run,json}=fixture();run("both(a,{type:'continue'});");
 assert.equal(run('a.phase'),'combat');
 run(`for(let i=0;i<12&&a.phase==='combat';i++){
  advReduce(a,{type:'useSkill',skill:'blade_slash',target:'e0'},'host',names);
  advReduce(a,{type:'useSkill',skill:'weaver_thornstitch',target:'e0'},'guest',names);
 }`);
 assert.equal(run('a.phase'),'draft');assert.equal(run('a.stats.kills'),1);
 assert.equal(run('a.draft.host.length'),3);assert.equal(run('a.draft.guest.length'),3);
 run("var hc=a.draft.host[0],gc=a.draft.guest[0];advReduce(a,{type:'draftPick',card:hc},'host',names);");
 assert.equal(run('a.phase'),'draft');
 run("a=JSON.parse(JSON.stringify(a));advReduce(a,{type:'draftPick',card:gc},'guest',names);");
 assert.equal(run('a.phase'),'map');assert.equal(run('a.stats.cardsTaken'),2);
 assert.ok(run('a.players.host.cards.includes(hc)'));assert.ok(run('a.players.guest.cards.includes(gc)'));
 assert.deepEqual(json('reachable(a)'),json('a.map.floors[1].map(n=>n.id)'));
});
test('三幕所有路线至少七场普通战或精英战，支线不能连续淹没战斗',()=>{
 const {run,json}=fixture();
 for(let seed=1;seed<=40;seed++)for(let act=1;act<=3;act++){
  run(`a=start(${seed});a.act=${act};genMap(a);`);const map=json('a.map');
  assert.equal(map.floors.length,16);
  const nodes=map.floors.flat(),index=new Map(nodes.map(n=>[n.id,n]));
  const pending=map.floors[0].map(n=>({id:n.id,battles:0,gap:0}));
  const seen=new Set();let terminals=0;
  while(pending.length){const p=pending.pop(),n=index.get(p.id);assert.ok(n);const fight=['battle','elite'].includes(n.type),b=p.battles+(fight?1:0),gap=fight||n.type==='boss'?0:p.gap+1,key=[n.id,b,gap].join(':');if(seen.has(key))continue;seen.add(key);assert.ok(gap<=2,'More than two non-combat rooms in a row: '+key);if(!n.next.length){assert.equal(n.type,'boss');assert.ok(b>=7);terminals++;}for(const id of n.next)pending.push({id,battles:b,gap});}
  assert.ok(terminals>0);assert.equal(nodes.filter(n=>n.type==='npc').length,5);
  for(const key of ['pot','delivery','laundry']){const n=nodes.find(n=>n.sceneId===`daily_${key}_${act}`);assert.ok(n);assert.ok(map.floors[n.floor].length>1,'Daily scenes must stay optional');assert.equal(n.main,false);}
 }
});
test('旧存档只更新未走的路线，当前场景和已取得奖励原样保留，迁移幂等',()=>{
 const {run,json}=fixture();
 run(`a=start();genMap(a);delete a.map.pacingVersion;a.phase='interlude';a.map.cur='f3n0';a.map.visited=['f0n0','f1n0','f2n0','f3n0'];
 a.interlude={id:'daily_pot_1',done:true,result:'留住这一句话',picks:{host:0,guest:0}};
 a.map.floors[3][0]={...a.map.floors[3][0],type:'interlude',sceneId:'daily_pot_1'};
 a.map.floors[4][0]={...a.map.floors[4][0],type:'npc',npcId:'mara'};
 a.flags=['daily_fact'];a.players.host.hp=33;a.players.host.cards=['blade_c05'];
 var saved=clone(a);`);
 assert.equal(run('typeof upgradeBattleRoute'),'function');
 run('upgradeBattleRoute(a);');
 assert.equal(run('a.phase'),'interlude');assert.equal(run('a.interlude.result'),'留住这一句话');
 assert.deepEqual(json('a.map.floors.slice(0,3)'),json('saved.map.floors.slice(0,3)'));
 assert.equal(run('a.map.floors[3][0].sceneId'),'daily_pot_1');
 assert.equal(run('a.map.floors[4][0].type'),'battle');
 assert.deepEqual(json('a.map.visited'),json('saved.map.visited'));
 assert.deepEqual(json('a.players'),json('saved.players'));assert.deepEqual(json('a.flags'),['daily_fact']);
 assert.equal(run('a.rngState'),run('saved.rngState'),'A route upgrade must not consume the live combat RNG');
 run('var once=JSON.stringify(a);upgradeBattleRoute(a);');assert.equal(run('JSON.stringify(a)'),run('once'));
 run("both(a,{type:'continue'});");assert.equal(run('a.phase'),'map');
 const target=run('reachable(a)[0]');run(`both(a,{type:'vote',node:${JSON.stringify(target)}});`);assert.equal(run('a.phase'),'combat');
});
test('旧存档结束当前剧情才进入新路线，未结束的选择不能被迁移跳过',()=>{
 const {run}=fixture();run(`a=start();genMap(a);delete a.map.pacingVersion;a.phase='event';a.map.cur='f1n0';a.map.visited=['f0n0','f1n0'];a.event={id:'a1_0_keyecho',done:false};var before=JSON.stringify(a);both(a,{type:'continue'});`);
 assert.equal(run('JSON.stringify(a)'),run('before'));
 run("a.event.done=true;both(a,{type:'continue'});");assert.equal(run('a.phase'),'map');assert.equal(run('a.map.pacingVersion'),2);
});
test('旧地图已完成的开场事件与调查不会在新路线再次发奖励',()=>{
 const {run,json}=fixture();
 run(`a=start();genMap(a);delete a.map.pacingVersion;a.map.cur='f0n0';a.map.visited=['f0n0'];
 a.map.floors[0][0]={...a.map.floors[0][0],type:'event',eventId:'a1_0_keyecho'};
 a.seenEvents=['a1_0_keyecho'];a.phase='event';a.event={id:'a1_0_keyecho',done:true};both(a,{type:'continue'});`);
 assert.equal(run('a.map.floors[1][0].type'),'battle');
 assert.ok(json('a.map.floors.slice(1).flat()').every(n=>n.eventId!=='a1_0_keyecho'));
 run(`a=start();genMap(a);delete a.map.pacingVersion;a.map.cur='f2n0';a.map.visited=['f0n0','f1n0','f2n0'];
 a.map.floors[0][0]={...a.map.floors[0][0],type:'event',eventId:'a1_0_keyecho'};
 a.map.floors[2][0]={...a.map.floors[2][0],type:'interlude',sceneId:'inspect_1'};
 a.seenEvents=['a1_0_keyecho'];a.phase='interlude';a.interlude={id:'inspect_1',done:true,result:'已经调查过'};
 both(a,{type:'continue'});`);
 assert.equal(run('a.phase'),'map');
 assert.ok(json('a.map.floors.slice(3).flat()').every(n=>n.eventId!=='a1_0_keyecho'&&n.sceneId!=='inspect_1'));
 assert.equal(run('a.map.floors[2][0].sceneId'),'inspect_1');
});
test('旧幕间页和后续幕转场均接正式战斗，单方操作仍等待搭档',()=>{
 const {run}=fixture();
 for(const initial of ['actIntro','memory']){
  run(`a=start();a.phase=${JSON.stringify(initial)};a.act=1;a.pageReady={host:false,guest:false};advReduce(a,{type:'continue'},'guest',names);`);
  assert.equal(run('a.phase'),initial);
  run("advReduce(a,{type:'continue'},'host',names);");assert.equal(run('a.phase'),'combat');assert.equal(run('a.act'),initial==='memory'?2:1);
 }
});
