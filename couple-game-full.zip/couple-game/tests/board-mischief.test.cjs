'use strict';
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const {test}=require('node:test');
const root=path.join(__dirname,'..');
function fixture(){
 const ctx={console,Math,Date:class extends Date{static now(){return 1000;}}};ctx.window=ctx;vm.createContext(ctx);
 for(const f of ['data/core.js','data/corpus.js','data/minigames.js','data/rules-copy.js','data/full-story.js','data/continuity.js','data/combat-cast.js','data/board-banter.js','engine.js','battle-tactics.js','combat-director.js','tactical-board.js','board-delight.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f});
 const run=s=>vm.runInContext(s,ctx);
 run(`var a=advInit(29);for(const [r,cls] of [['host','blade'],['guest','weaver']]){advReduce(a,{type:'pickClass',cls},r);advReduce(a,{type:'ready'},r);}genMap(a);combatStart(a,['fog_fisherman','crab'],'normal');a.combat.board.tiles=[];a.combat.board.threats=[];a.combat.board.positions={host:{x:0,y:1},guest:{x:4,y:3},e0:{x:1,y:1},e1:{x:4,y:0}};for(const e of a.combat.enemies){e.hp=e.maxhp=100;e.block=0;e.dmgMul=1;e.status={};}for(const r of ROLES){a.players[r].status={};a.players[r].mods.crit=0;}a.combat.presentation.events=[];a.combat.presentation.transcript=[];`);
 return {run,loadUi(){ctx.document={addEventListener(){}};run(`var ui={boardTool:'push',target:'e0'},session={kind:'online',role:'host'},settings={motion:true};var S={adv:a,players:{host:{name:'甲'},guest:{name:'乙'}}};`);for(const f of ['R.js','tactical-ui.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f});},json:s=>JSON.parse(run('JSON.stringify('+s+')'))};
}
function action(h,r,ac){return h.json(`boardRunAction(a,${JSON.stringify(r)},${JSON.stringify(ac)})`);}
function queue(h,r,ac){return h.run(`boardSubmit(a,${JSON.stringify(r)},${JSON.stringify({type:'boardQueue',...ac})})`);}
function events(h){return h.json('a.combat.presentation.events');}
function push(h){return action(h,'host',{kind:'push',target:'e0'});}
function thorn(h){return action(h,'guest',{kind:'skill',skill:'weaver_thornstitch',target:'e0'});}

test('推离原位后旅伴技能额外接刀3点，同一只怪同一轮只能一次',()=>{
 const base=fixture(),relay=fixture();thorn(base);push(relay);const step=thorn(relay);
 assert.equal(relay.run('a.combat.enemies[0].hp'),base.run('a.combat.enemies[0].hp')-3);
 assert.match(step.text,/追击追加3伤害/);assert.equal(events(relay).filter(e=>e.impact==='relay').length,1);
 const before=relay.run('a.combat.enemies[0].hp');thorn(relay);
 assert.equal(before-relay.run('a.combat.enemies[0].hp'),100-base.run('a.combat.enemies[0].hp'));
 assert.equal(events(relay).filter(e=>e.impact==='relay').length,1);
 assert.ok(relay.json('a.combat.board.lastHighlights').some(x=>x.id==='relay'&&x.text.includes('3')));
});

test('自己推自己打、撞墙未位移、远距失败、治疗均不能领取接刀伤害',()=>{
 for(const mode of ['same-role','wall','too-far','heal']){
  const h=fixture();
  if(mode==='wall')h.run(`a.combat.board.tiles=[{x:2,y:1,kind:'wall'}]`);
  if(mode==='too-far')h.run(`a.combat.board.positions.e0={x:4,y:1}`);
  push(h);
  if(mode==='same-role')action(h,'host',{kind:'skill',skill:'blade_slash',target:'e0'});
  else if(mode==='heal'){const id=h.run(`a.players.guest.skills.find(id=>findSkill(id).effects.some(e=>e.op==='heal')&&!findSkill(id).effects.some(e=>e.op==='dmg'))`);assert.equal(action(h,'guest',{kind:'skill',skill:id}).ok,true);}
  else thorn(h);
  assert.equal(events(h).filter(e=>e.impact==='relay').length,0,mode);
 }
});

test('成功拉近同样可接刀；油滑只算一次成功位移',()=>{
 const pull=fixture();pull.run(`a.combat.board.positions.e0={x:2,y:1}`);action(pull,'host',{kind:'pull',target:'e0'});thorn(pull);
 assert.equal(events(pull).filter(e=>e.impact==='relay').length,1);
 const slide=fixture();slide.run(`a.combat.board.tiles=[{x:2,y:1,kind:'oil'}]`);push(slide);thorn(slide);
 assert.deepEqual(slide.json('a.combat.board.positions.e0'),{x:3,y:1});
 assert.equal(events(slide).filter(e=>e.impact==='relay').length,1);
});

test('完全被盾挡住的技能、已倒下或已阵亡的攻击者不会追加伤害',()=>{
 for(const mode of ['shield','down','dead']){
  const h=fixture();push(h);
  if(mode==='shield')h.run('a.combat.enemies[0].block=100');
  if(mode==='down')h.run('a.players.guest.down=true');
  if(mode==='dead')h.run('a.players.guest.hp=0');
  thorn(h);assert.equal(events(h).filter(e=>e.impact==='relay').length,0,mode);
 }
});

test('接刀击杀只结算一次胜利，已被前一技能击杀的敌人不再追加',()=>{
 const h=fixture();h.run('a.combat.enemies[1].hp=0;a.combat.enemies[0].hp=7');push(h);thorn(h);
 assert.equal(h.run('a.combat.enemies[0].hp'),0);assert.equal(h.run('a.combat.result'),'win');
 assert.equal(events(h).filter(e=>e.impact==='relay').length,1);
 const gold=h.run('a.gold'),kills=h.run('a.stats.kills');
 assert.equal(queue(h,'guest',{kind:'skill',skill:'weaver_thornstitch',target:'e0'}),false);
 assert.equal(h.run('a.gold'),gold);assert.equal(h.run('a.stats.kills'),kills);
 const early=fixture();early.run('a.combat.enemies[0].hp=4');push(early);thorn(early);
 assert.equal(events(early).filter(e=>e.impact==='relay').length,0);
});

test('接力标记支持JSON往返，跨回合过期；旧存档没有标记也能正常出招',()=>{
 const saved=fixture();push(saved);saved.run('a=JSON.parse(JSON.stringify(a))');thorn(saved);
 assert.equal(events(saved).filter(e=>e.impact==='relay').length,1);
 const stale=fixture();push(stale);stale.run('a.combat.turn++');thorn(stale);
 assert.equal(events(stale).filter(e=>e.impact==='relay').length,0);
 const old=fixture();old.run('delete a.combat.board.relay;a=JSON.parse(JSON.stringify(a))');thorn(old);
 assert.equal(events(old).filter(e=>e.impact==='relay').length,0);
});

test('只收一次队列指令；双方提交顺序不同仍先推再接刀；预览不污染状态',()=>{
 const a=fixture(),b=fixture();
 assert.equal(queue(a,'guest',{kind:'skill',skill:'weaver_thornstitch',target:'e0'}),true);
 assert.equal(queue(a,'guest',{kind:'skill',skill:'weaver_thornstitch',target:'e0'}),false);
 a.run(`a.combat.board.queues.host=[{kind:'push',target:'e0'}]`);
 const before=a.run('JSON.stringify(a)'),first=a.json('boardPreview(a)');
 assert.deepEqual(first,a.json('boardPreview(a)'));assert.equal(a.run('JSON.stringify(a)'),before);
 a.run('a.combat.board.queues.host=[]');queue(a,'host',{kind:'push',target:'e0'});
 queue(b,'host',{kind:'push',target:'e0'});queue(b,'guest',{kind:'skill',skill:'weaver_thornstitch',target:'e0'});
 assert.deepEqual(a.json('a.combat.enemies'),b.json('a.combat.enemies'));
 assert.equal(a.run('a.combat.enemies[0].hp'),first.enemies[0].hp);
 assert.equal(events(a).filter(e=>e.impact==='relay').length,1);
 assert.equal(a.run('a.combat.board.relay'),undefined);
});

test('敌人按已预告格误伤其他怪物，攻击来源、护盾和实掉血量均准确',()=>{
 const h=fixture();h.run(`a.combat.board.positions.e1={x:2,y:1};a.combat.enemies[1].block=3;a.combat.board.threats=[{enemy:'e0',cells:[{x:2,y:1}],intent:{type:'attack',v:9}}];boardEnemyRound(a)`);
 assert.equal(h.run('a.combat.enemies[1].hp'),94);assert.equal(h.run('a.combat.enemies[1].block'),0);
 const hit=events(h).find(e=>e.impact==='friendly-fire');
 assert.equal(hit.actor,'e0');assert.equal(hit.target,'e1');assert.equal(hit.value,6);assert.equal(hit.blocked,3);
 const attack=events(h).find(e=>e.type==='attack');assert.deepEqual(attack.targets,['e1']);
 assert.ok(h.json('a.combat.board.lastHighlights').some(x=>x.id==='friendly-fire'));
 assert.equal(h.run('a.combat.enemies[0].hp'),100);
});

test('推入别人的攻击格可借刀，攻击者自己的格子与区域外的怪不会受伤',()=>{
 const h=fixture();h.run(`a.combat.board.threats=[{enemy:'e1',cells:[{x:2,y:1},{x:4,y:0}],intent:{type:'attack',v:10}}]`);push(h);h.run('boardEnemyRound(a)');
 assert.equal(h.run('a.combat.enemies[0].hp'),90);assert.equal(h.run('a.combat.enemies[1].hp'),100);
 const outside=fixture();outside.run(`a.combat.board.threats=[{enemy:'e1',cells:[{x:4,y:0}],intent:{type:'attack',v:10}}];boardEnemyRound(a)`);
 assert.deepEqual(outside.json('a.combat.enemies.map(e=>e.hp)'),[100,100]);
});

test('减益只影响玩家；眩晕或死亡的怪物不会误伤；完全格挡不虚报掉血亮点',()=>{
 for(const mode of ['debuff','stun','dead','shield']){
  const h=fixture();h.run(`a.combat.board.positions.e1={x:2,y:1};a.combat.board.threats=[{enemy:'e0',cells:[{x:2,y:1}],intent:{type:'${mode==='debuff'?'debuff':'attack'}',v:6,s:'weak'}}];`);
  if(mode==='stun')h.run('a.combat.enemies[0].status.stun=1');
  if(mode==='dead')h.run('a.combat.enemies[0].hp=0');
  if(mode==='shield')h.run('a.combat.enemies[1].block=30');
  h.run('boardEnemyRound(a)');assert.equal(h.run('a.combat.enemies[1].hp'),100,mode);
  assert.equal(h.run('a.combat.enemies[1].status.weak'),undefined,mode);
  assert.equal(h.run('(a.combat.board.lastHighlights||[]).some(x=>x.id===\'friendly-fire\')'),false,mode);
 }
});

test('误伤击杀会跳过死者后续出招，受反伤死亡的攻击者立即停止多段攻击',()=>{
 const kill=fixture();kill.run(`a.combat.enemies[1].hp=4;a.combat.board.positions.e1={x:2,y:1};a.combat.board.threats=[{enemy:'e0',cells:[{x:2,y:1}],intent:{type:'attack',v:8}},{enemy:'e1',cells:[{x:0,y:1}],intent:{type:'attack',v:30}}];var health=a.players.host.hp;boardEnemyRound(a)`);
 assert.equal(kill.run('a.combat.enemies[1].hp'),0);assert.equal(kill.run('a.players.host.hp'),kill.run('health'));
 assert.equal(events(kill).filter(e=>e.type==='attack'&&e.actor==='e1').length,0);
 const thorny=fixture();thorny.run(`a.combat.enemies[0].hp=1;a.combat.enemies[1].status.thorns=1;a.combat.board.positions.e1={x:2,y:1};a.combat.board.threats=[{enemy:'e0',cells:[{x:2,y:1}],intent:{type:'multi',v:5,hits:3}}];boardEnemyRound(a)`);
 assert.equal(thorny.run('a.combat.enemies[0].hp'),0);assert.equal(thorny.run('a.combat.enemies[1].hp'),95);
 assert.equal(events(thorny).filter(e=>e.impact==='friendly-fire').length,1);
 const both=fixture();both.run(`a.combat.enemies[0].hp=1;a.combat.enemies[1].hp=4;a.combat.enemies[1].status.thorns=1;a.combat.board.positions.e1={x:2,y:1};a.combat.board.threats=[{enemy:'e0',cells:[{x:2,y:1}],intent:{type:'multi',v:5,hits:3}}];var goldBefore=a.gold;boardEnemyRound(a)`);
 assert.deepEqual(both.json('a.combat.enemies.map(e=>e.hp)'),[0,0]);
 assert.equal(both.run('a.combat.result'),'win');assert.equal(both.run('a.stats.kills'),2);
 assert.equal(both.run('a.gold-goldBefore'),22);
 assert.equal(events(both).filter(e=>e.impact==='friendly-fire').length,1);
});

test('单体首领不会自伤；固定3点接刀没有按首领血量放大；关闭演出不改规则',()=>{
 for(const muted of [false,true]){
  const h=fixture();h.run(`combatStart(a,['mirror'],'boss');a.combat.enemies[0].hp=a.combat.enemies[0].maxhp=1000;a.combat.board.tiles=[];a.combat.board.positions={host:{x:0,y:1},guest:{x:4,y:3},e0:{x:1,y:1}};a.combat.board.threats=[{enemy:'e0',cells:[{x:2,y:1}],intent:{type:'attack',v:100}}];${muted?'battleEmit=function(){};':''}`);
  push(h);thorn(h);const before=h.run('a.combat.enemies[0].hp');h.run('boardEnemyRound(a)');
  assert.equal(h.run('a.combat.enemies[0].hp'),before);assert.equal(before,992);
 }
});


test('界面保留三个主操作，标题显示地点，借刀标记和有条件的接力预览可见',()=>{
 const h=fixture();h.loadUi();h.run(`a.practice=true;a.combat.board.threats=[{enemy:'e1',cells:[{x:1,y:1},{x:2,y:1}],intent:{type:'attack',v:10}}]`);
 const before=h.run('JSON.stringify(a)'),preview=h.json(`boardUiPushPreview(a,'host',a.combat.enemies[0])`);
 assert.match(preview.text,/旅伴命中后 \+3/);assert.match(preview.text,/可借刀/);
 const html=h.run(`boardCombatView(a,'host')`);
 assert.equal((html.match(/id="board-tool-/g)||[]).length,3);
 assert.match(html,/<h2>码头演练<\/h2>/);assert.match(html,/<small>回合<\/small>/);
 assert.match(html,/这只怪会被其他怪物误伤/);assert.match(html,/class="board-friendly-mark"/);
 assert.doesNotMatch(html,/你一招，我接上|这一战，一起赢|ROUND|接得漂亮/);
 assert.equal(h.run('JSON.stringify(a)'),before,'Rendering and opportunity labels must not commit a move');
 h.run(`a.practice=false;a.act=2`);assert.match(h.run(`boardCombatView(a,'host')`),/<h2>失名街区遭遇<\/h2>/);
});
