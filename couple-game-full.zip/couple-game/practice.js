/* A short, repeatable rehearsal. The campaign is kept outside this adventure. */
function practiceState(state){
 const next=clone(state),a=advInit();
 next.practiceReturn={adv:clone(state.adv||null),mode:state.mode||null};
 a.practice=true;
 for(const [role,cls] of [['host','blade'],['guest','weaver']]){
  advReduce(a,{type:'pickClass',cls},role,next.players);
  advReduce(a,{type:'ready'},role,next.players);
 }
 genMap(a);
 const enemies=GD().enemies.filter(e=>e.act===1&&e.tier==='normal');
 combatStart(a,[enemies[0].id],'normal');
 a.combat.enemies[0].hp=a.combat.enemies[0].maxhp=26;
 advLog(a,'赫尔特：试试把它推到铁夹上。别把桶往自己脚边推。');
 next.mode='adventure';next.adv=a;
 return next;
}
function practiceResultView(){
 const a=S.adv,won=a.combat?.result==='win';
 return `${topbar()}<main class="shell game-shell">${gameTop('码头演练')}<section class="panel" style="max-width:720px;margin:32px auto;padding:clamp(24px,5vw,48px)"><div class="eyebrow">演练结果</div><h1 style="font-size:clamp(28px,6vw,42px)">${won?'演练胜利':'演练失败'}</h1><div class="prose"><p>${won?'赫尔特踢了踢碎桶板，弯腰捡起还能用的铁箍。「行，知道怎么打了。收拾完再走。」':'赫尔特伸手把你拉起来。「别光盯着它。红格都亮半天了，你还站着。」'}</p><p>每人每回合选一招。走位可避开红格，推怪可触发机关；队友还能追击被推动的怪物。</p></div><div class="hero-actions">${button('再练一把','practiceAgain')}${button('退出演练','practiceExit','','secondary')}</div><p class="muted" style="margin-top:20px">本次演练不影响存档和收藏。</p></section></main>`;
}
(function(){
 const home=homeView,lobby=lobbyView,top=gameTop;
 homeView=function(){return home().replace('<div class="hero-foot">','<div style="margin:12px 0 20px"><button class="text-btn gold" data-action="practice">战斗演练 →</button></div><div class="hero-foot">');};
 lobbyView=function(){return lobby().replace('<div class="hero-foot">','<div style="margin:12px 0 20px"><button class="text-btn gold" data-action="practice">双人战斗演练 →</button></div><div class="hero-foot">');};
 gameTop=function(title){const html=top(title);return S.adv?.practice?html.replace('data-action="lobby"','data-action="practiceExit"').replace('回到大厅','结束演练')+'<p class="muted practice-note">演练目标：击败潮湿尸骸。每人选一招，双方选好后结算。</p>':html;};
})();
