/* A short, repeatable rehearsal. The campaign is kept outside this adventure. */
function practiceState(state){
 const next=clone(state),a=advInit();
 next.practiceReturn={adv:clone(state.adv||null),mode:state.mode||null};
 a.practice=true;
 for(const [role,cls] of [['host','blade'],['guest','weaver']]){
  advReduce(a,{type:'pickClass',cls},role,next.players);
  advReduce(a,{type:'ready'},role,next.players);
 }
 genMap(a);
 const enemies=GD().enemies.filter(e=>e.act===1&&e.tier==='normal');
 combatStart(a,[enemies[0].id],'normal');
 a.combat.enemies[0].hp=a.combat.enemies[0].maxhp=26;
 advLog(a,'赫尔特：先练一把。打坏的桶算我的，别写进交班本。');
 next.mode='adventure';next.adv=a;
 return next;
}
function practiceResultView(){
 const a=S.adv,won=a.combat?.result==='win';
 return `${topbar()}<main class="shell game-shell">${gameTop('码头演练')}<section class="panel" style="max-width:720px;margin:32px auto;padding:clamp(24px,5vw,48px)"><div class="eyebrow">练一把 · ${won?'配合完成':'再来就会了'}</div><h1 style="font-size:clamp(28px,6vw,42px)">${won?'怪倒了，默契站起来了。':'人没事，桶也不追究了。'}</h1><div class="prose"><p>${won?'赫尔特在交班本上写：两位新来的，挺能打。想了想，又加一句：不建议让他们搬易碎品。':'赫尔特把交班本翻过去：“这页不算。刚才风太大，地太滑，怪也不讲礼貌。”'}</p><p>每人一招，走位躲红格，推怪撞机关。还想试点别的，就换个招式接着玩。</p></div><div class="hero-actions">${button('再练一把','practiceAgain')}${button('返回旅程','practiceExit','','secondary')}</div><p class="muted" style="margin-top:20px">演练独立进行，你们原来的旅程和收藏都还在。</p></section></main>`;
}
(function(){
 const home=homeView,lobby=lobbyView,top=gameTop;
 homeView=function(){return home().replace('<div class="hero-foot">','<div style="margin:12px 0 20px"><button class="text-btn gold" data-action="practice">先练一把 · 直接体验双人战棋 →</button></div><div class="hero-foot">');};
 lobbyView=function(){return lobby().replace('<div class="hero-foot">','<div style="margin:12px 0 20px"><button class="text-btn gold" data-action="practice">双人练一把 · 推怪、走位、一起接招 →</button></div><div class="hero-foot">');};
 gameTop=function(title){const html=top(title);return S.adv?.practice?html.replace('data-action="lobby"','data-action="practiceExit"').replace('回到大厅','结束演练')+'<p class="muted practice-note">码头演练 · 不覆盖旅程。一人推上陷阱，一人补刀；选好自动出手。</p>':html;};
})();
