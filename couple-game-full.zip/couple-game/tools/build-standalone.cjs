// Run from any directory. Preserve raw manuscript; inline only active scripts/assets.
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),out=path.resolve(process.argv[2]||path.join(root,'../deliverables/echoes-bone-city-full.html'));
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const imageAssets=new Map();
html=html.replace(/<link rel="stylesheet" href="([^"]+)">/g,(_,sheet)=>{const css=fs.readFileSync(path.join(root,sheet),'utf8').replace(/url\(["']?([^"')]+)["']?\)/g,(_,file)=>{const data=fs.readFileSync(path.join(root,file));const mime=file.endsWith('.png')?'image/png':file.endsWith('.webp')?'image/webp':'font/woff';const uri=`url("data:${mime};base64,${data.toString('base64')}")`;if(mime.startsWith('image/')){if(!imageAssets.has(file))imageAssets.set(file,{key:'--embedded-image-'+imageAssets.size,uri});return `var(${imageAssets.get(file).key})`;}return uri;});return '<style>'+css+'</style>';});
// A scene or atlas can be referenced by many selectors; embed its bytes once.
// Font-face src descriptors keep literal URLs because they do not resolve CSS variables.
html=html.replace('</head>','<style>:root{'+[...imageAssets.values()].map(({key,uri})=>`${key}:${uri}`).join(';')+'}</style></head>');
html=html.replace(/<script src="([^"]+)"><\/script>/g,(_,file)=>'<script>\n'+fs.readFileSync(path.join(root,file),'utf8').replace(/<\/script/gi,'<\\/script')+'\n</script>');
fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,html);console.log(path.basename(out),Buffer.byteLength(html),'bytes');
// This is the offline artifact. The web publisher externalizes image bytes and
// validates the actual uploaded files; an offline bundle may exceed 25 MiB.
