// Run from any directory. Preserve raw manuscript; inline only active scripts/assets.
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),out=path.resolve(process.argv[2]||path.join(root,'../deliverables/echoes-bone-city-full.html'));
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');let css=fs.readFileSync(path.join(root,'style.css'),'utf8').replace(/url\(["']?([^"')]+)["']?\)/g,(_,file)=>{const data=fs.readFileSync(path.join(root,file));const mime=file.endsWith('.png')?'image/png':'font/woff';return `url("data:${mime};base64,${data.toString('base64')}")`;});
html=html.replace('<link rel="stylesheet" href="style.css">',()=>'<style>'+css+'</style>');
html=html.replace(/<script src="([^"]+)"><\/script>/g,(_,file)=>'<script>\n'+fs.readFileSync(path.join(root,file),'utf8').replace(/<\/script/gi,'<\\/script')+'\n</script>');
fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,html);console.log(path.basename(out),Buffer.byteLength(html),'bytes');
if(Buffer.byteLength(html)>25*1024*1024)throw Error('Exceeds GitHub web upload file limit');
