/* Recurring bathhouse jobs. Load after the three authored daily-scene packs.
 * Daily jobs fill optional story slots between fights. Existing active scenes
 * are retained when the engine updates the unvisited part of an old route.
 */
(function(G){
'use strict';
if(G.dailyScenes?.version===1)return;
const packOrder=['pot','delivery','laundry'];
const scenes=packOrder.flatMap(key=>G.dailyScenePacks?.[key]||[]);
const ids=new Set(),flags=new Set();
for(const key of packOrder){
 const pack=G.dailyScenePacks?.[key];
 if(!Array.isArray(pack)||pack.length!==3)throw new Error('Incomplete daily scene pack: '+key);
 for(let act=1;act<=3;act++)if(pack.filter(d=>d.act===act).length!==1)throw new Error('Daily scene act missing: '+key+':'+act);
}
for(const d of scenes){
 if(!d.id||ids.has(d.id)||G.interludes.some(old=>old.id===d.id)||d.kind!=='duo'||!d.text||d.options?.host?.length!==2||d.options?.guest?.length!==2||d.results?.length!==4)throw new Error('Invalid daily scene: '+d.id);
 ids.add(d.id);
 for(const result of d.results){
  if(!result.text||!result.flag||flags.has(result.flag)||!Number.isFinite(result.bond)||['gold','heal'].some(k=>result[k]!=null&&(!Number.isFinite(result[k])||result[k]<0)))throw new Error('Invalid daily scene result: '+d.id);
  flags.add(result.flag);
 }
 for(const [key,branches] of Object.entries(d.callbacks||{})){
  if(!/^[a-z0-9_]+$/.test(key)||!branches||typeof branches.default!=='string'||Object.values(branches).some(text=>typeof text!=='string'))throw new Error('Invalid daily callback: '+d.id+':'+key);
 }
}
const originals={interludes:JSON.parse(JSON.stringify(G.interludes))};
const byId=Object.fromEntries(scenes.map(d=>[d.id,d]));
G.interludes.push(...scenes);
for(const d of scenes)for(const result of d.results){
 G.flagNames[result.flag]=result.memory||result.fact||d.title;
}
function sceneFor(a){return a?.phase==='interlude'?byId[a.interlude?.id]||null:null;}
function resolve(text,a,scene=sceneFor(a)){
 const present=new Set(a?.flags||[]);
 return String(text||'').replace(/\{DAILY:([a-z0-9_]+)\}/g,(_,key)=>{
  // A callback belongs to its scene: the same earlier incident can be mentioned
  // differently at a later meeting. Unrelated scenes cannot invent that memory.
  const branches=scene?.callbacks?.[key];
  if(!branches)return '';
  const fact=Object.keys(branches).find(flag=>flag!=='default'&&present.has(flag));
  return fact?branches[fact]:branches.default;
 }).trim();
}
G.dailyScenes={version:1,ids:[...ids],flags:[...flags],originals,sceneFor,resolve};

const makeMap=genMap;
genMap=function(a){
 const result=makeMap(a),floors=a?.map?.floors;
 if(!floors||floors.length!==16)return result;
 for(const floor of floors)for(let i=0;i<floor.length;i++){
  const old=floor[i],pack=old.dailySlot;if(!pack)continue;
  const d=G.dailyScenePacks[pack]?.find(scene=>scene.act===a.act);if(!d)continue;
  const node={...old,type:'interlude',sceneId:d.id,title:d.title,kind:'duo',main:false};
  delete node.eventId;floor[i]=node;
 }
 return result;
};

const complete=completeScene;
completeScene=function(a,d,text,effects){
 if(!byId[d?.id])return complete(a,d,text,effects);
 // A stale/repeated result must not grant a second reward or a second fact.
 if(a?.phase!=='interlude'||a.interlude?.id!==d.id||a.interlude.done)return;
 const picks=a.interlude.picks;
 if(![0,1].includes(picks?.host)||![0,1].includes(picks?.guest))return;
 const authored=d.results[picks.host*2+picks.guest];
 const start=a.journal?.length||0;
 const value=complete(a,d,text,[...(effects||[]),{op:'flag',k:authored.flag}]);
 a.interlude.result=resolve(a.interlude.result,a,d);
 for(const entry of (a.journal||[]).slice(start))if(typeof entry.text==='string')entry.text=resolve(entry.text,a,d);
 return value;
};

const format=advText;
advText=function(text){return format(resolve(text,typeof S==='undefined'?null:S.adv));};
const reduce=advReduce;
advReduce=function(a,action,role,names){
 const start=a?.journal?.length||0,scene=sceneFor(a);
 const value=reduce(a,action,role,names);
 if(!a)return value;
 const active=scene||sceneFor(a);
 const freeze=entry=>{if(entry?.text?.includes('{DAILY:'))entry.text=resolve(entry.text,a,active);};
 for(const entry of a.npc?.trail||[])freeze(entry);
 for(const entry of (a.journal||[]).slice(start)){
  freeze(entry);for(const step of entry.trail||[])freeze(step);
 }
 if(a.npc?.lastText?.includes('{DAILY:'))a.npc.lastText=resolve(a.npc.lastText,a,active);
 if(a.interlude?.result?.includes('{DAILY:'))a.interlude.result=resolve(a.interlude.result,a,active);
 return value;
};
})(window.GAME_DATA);
