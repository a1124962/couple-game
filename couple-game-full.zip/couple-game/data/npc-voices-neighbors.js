/* New dialogue voices, with the complete previous nodes retained for reference.
 * Only prose, choice labels and explicit consequence hints change; IDs, gates, outcomes and save data do not.
 */
(function(G){
'use strict';
if(G.npcNeighborVoices)return;
const rewrites={
  "holt": {
    "1": {
      "start": {
        "text": "赫尔特从桥边搬来自己的旧椅子。刚才掉下来的三条椅腿还捆在一旁，第四条已经当了拐杖。旧椅子坐下去有点晃。\n\n「这把没坏，地不平。」他垫了张废告示，坐稳，朝你们伸手，「卷宗。刚才忙着捡东西，签名还没核。」\n\nTA 把封面转向他。他看了一眼，先拿印章，又放下，抽出塞在帽檐里的检查单。\n\n「别催。上回有人把菜单递给我，我放过去了四份烤鱼。」\n\n单子第一项写着：两个人，都要在。老人抬眼，认真数了数你们。",
        "labels": [
          "把零号卷宗递给他",
          "问他平时负责什么",
          "先收好卷宗，暂时不交"
        ]
      },
      "show_zero": {
        "text": "【holt:neutral】零号啊。缺三页，补齐才能回去。卖纸的要是说他那儿能补，别信，纯坑钱。\n\n【guest:neutral】桥上那些钥匙能捡吗？\n\n【holt:neutral】不能！碰了就骂人。靠白线走。哎，卷宗呢？\n\n【host:neutral】还在您手上。",
        "labels": [
          "袖子上绣的是谁？",
          "行，准备过桥",
          "给我们张地图呗"
        ]
      },
      "ask_who": {
        "text": "【holt:neutral】守桥的。验人、验纸，顺便把掉下去的人捞上来。\n\n【guest:neutral】一个人干这么多？\n\n【holt:neutral】可不。涨工钱的时候就说我一个人。卷宗拿来，我看看。",
        "labels": [
          "递卷宗，让他查",
          "不查了，先去集市"
        ]
      },
      "hesitate": {
        "text": "【host:neutral】先等会儿。咱们还不知道他是谁呢。\n\n【holt:annoyed】行，自己商量。别一人拽一边，我这儿没浆糊。\n\n【guest:neutral】不交就过不去？\n\n【holt:annoyed】集市能去，桥别上。有几块板子早烂了。",
        "labels": [
          "商量好了，给他看",
          "先去集市"
        ]
      },
      "ask_sleeve": {
        "text": "【holt:neutral】袖子上？一个名字。谁的……我又给忘了。\n\n【guest:neutral】能看清一点。要不我们帮您猜猜？\n\n【holt:neutral】别猜。我猜过三个，越猜越乱。帮我照着抄下来就行，缺的先空着。",
        "labels": [
          "行，我们帮您记着",
          "这事我们不敢答应"
        ]
      },
      "bridge_warn": {
        "text": "【holt:neutral】钥匙里都是别人吵架剩下的话。前天我踩一脚，骂了我半宿。\n\n【guest:neutral】够缺德的。怎么过去？\n\n【holt:neutral】拨到边上。过桥再看下巡桥盒进没进水，里头五枚星砂算工钱，拿走吧。",
        "labels": [
          "清好桥，领五枚工钱",
          "踩一把听听"
        ]
      },
      "ask_map": {
        "text": "【holt:neutral】问路就问路，手别——啧，笔又掉了。\n\n【guest:neutral】我捡。地图能给我们一张吗？\n\n【holt:neutral】能。帮我擦掉桥口那个旧箭头，图和十枚工钱一起拿。先商量好去哪儿，别给我画俩方向。",
        "labels": [
          "先道歉，一起改路标",
          "让 TA 先道歉"
        ]
      },
      "trust_open": {
        "text": "【holt:smile】对，照着描。断线的地方别补。\n\n【guest:neutral】描好了。您这个线头也收着？\n\n【holt:smile】给你们。我留着又得丢。三枚买纸钱，还有张旧地图，要就拿。",
        "labels": [
          "收好线头、纸钱和地图",
          "收好拓样，道谢过桥"
        ]
      },
      "leave_bridge": {
        "text": "【holt:neutral】靠右！\n\n【guest:neutral】右边是水坑！\n\n【holt:neutral】啊？哦，我站反了。走那条干的，去集市。",
        "labels": [
          "去集市"
        ]
      },
      "bridge_cross": {
        "text": "【holt:neutral】两个人吧？\n\n【guest:neutral】两个！您刚数过！\n\n【holt:neutral】我知道！再问一遍怎么了！\n\n【host:neutral】走吧，先看清路牌。别又走回他面前。",
        "labels": [
          "走吧，继续赶路"
        ]
      },
      "key_echo": {
        "text": "【stage:neutral】铜钥匙响起来：「我恨你，别再找我。」\n\n【guest:neutral】让你别踩你非踩，有病吧？万一咬人呢？\n\n【host:neutral】我哪知道它能一直喊。\n\n【holt:neutral】翻个面！别站那儿跟钥匙吵！",
        "labels": [
          "先过桥，不吵了"
        ]
      },
      "map_given": {
        "text": "【guest:neutral】面包铺怎么画得比钟楼还大？\n\n【holt:smile】台阶高，我摔过。特意画大，省得下一个倒霉。\n\n【host:neutral】……谢谢。\n\n【holt:smile】图拿走，不用还。哪儿不对，下回告诉我。",
        "labels": [
          "收好地图，谢谢他"
        ]
      },
      "map_denied": {
        "text": "【holt:annoyed】行了，图我留着。照你俩这架势，一人得撕一半。\n\n【guest:neutral】那路呢？\n\n【holt:annoyed】往集市，第二个口左拐。笔尖也给我摔歪了，工钱别惦记了。",
        "labels": [
          "离开桥头"
        ]
      }
    },
    "2": {
      "start": {
        "text": "{CITY:holt}\n\n钟楼背面的铜廊很窄。赫尔特站在同一块地砖上，刚在本子里勾掉『查门闩』，又翻回去查了一遍。\n\n「第七层，水闸。潮涨，开门……」\n\n他念错一处，立刻从头再来。帽子掉在脚边，他弯腰想捡，忘了自己在捡什么，扶着墙站起来。\n\nTA 叫他坐下。老人没应，手指还在找本子上那一行，连拴在腰带上的笔也握不住了。\n\n铜廊里的潮声越来越响。他嘴里的字在减少，你们得赶紧让他认出眼前的人和事。",
        "labels": [
          "先看他的呼吸和反应",
          "叫他的名字，试着让他回应",
          "握住他的手，带他坐稳"
        ]
      },
      "count": {
        "text": "【holt:neutral】桥上几个？刚才还有人，几个来着？\n\n【host:neutral】两个。您看，都在这儿。\n\n【holt:neutral】两个……桥上几个？\n\n【guest:neutral】他听不进去。问问袖口那个名字，别再数了。",
        "labels": [
          "问袖口上那个名字",
          "提醒他：您怕把谁忘了？",
          "不打断，继续看"
        ]
      },
      "ask": {
        "text": "【guest:neutral】赫尔特，听得见吗？\n\n【holt:neutral】在。今晚不换班。\n\n【guest:neutral】不是查岗。您先坐下。\n\n【holt:neutral】桥上还有人。钥匙呢？我钥匙呢……",
        "labels": [
          "您袖子上是谁？",
          "我们帮您记一份",
          "不再打断"
        ]
      },
      "memory1": {
        "text": "【holt:neutral】那孩子的衣服呢？小的那件。我记得给他穿过。\n\n【guest:neutral】您袖口有字。是他的名字？\n\n【holt:neutral】是……叫什么？你们看得清吗？\n\n【host:neutral】只剩几针，不能瞎认。",
        "labels": [
          "是个孩子的名字",
          "把针脚认成自己的名字",
          "看不清，先不猜"
        ]
      },
      "memory2": {
        "text": "【guest:neutral】名字还没认出来。不过您一直怕忘了这个人。\n\n【holt:neutral】对，我怕。纸写了一张又一张，一张也找不着。\n\n【host:neutral】我们另抄一份。\n\n【holt:neutral】那下回我再问，你们还给我看？",
        "labels": [
          "行，下次还提醒您",
          "我们尽量找，不能打包票",
          "这事我们接不了"
        ]
      },
      "wake": {
        "text": "【holt:neutral】哎哟……刚才到哪儿了？\n\n【guest:neutral】到该歇着了。还站？您腿都软了。\n\n【holt:neutral】桥哪块板子松，我都记得。就这孩子，死活想不起来。你们帮我记一份，行不行？",
        "labels": [
          "行，我们接着找",
          "一点点查，尽量吧",
          "先不答应"
        ]
      },
      "silent": {
        "text": "【guest:neutral】等等！那是我们的名字，不是您袖子上那个。\n\n【holt:neutral】那到底是谁？你们一会儿说是，一会儿又说不是。\n\n【host:neutral】怪我，刚才说岔了。\n\n【holt:neutral】算了……潮到哪儿了？一、二……",
        "labels": [
          "留下，把话说清楚",
          "不试了，让他继续数"
        ]
      },
      "question": {
        "text": "【holt:neutral】「已经找回」划掉。没找着就写没找着，明天我会当真的。\n\n【guest:neutral】改成「正在找」。这样行吧？\n\n【holt:neutral】行。你们留一份？我这本哪天丢了，还能找你们问。",
        "labels": [
          "留一份，继续找",
          "先记着，我们尽量",
          "以后提醒的事，接不了"
        ]
      },
      "yes": {
        "text": "【holt:smile】这回放里兜。帽子不能再放，风一吹什么都没。\n\n【guest:neutral】本子上画的闸门是哪儿？\n\n【holt:smile】第七层。开了，城跟账册全沉下去，也就不用再找了。\n\n【guest:neutral】您这话什么意思？",
        "labels": [
          "陪他出去，收好记录"
        ]
      },
      "no": {
        "text": "【holt:neutral】行，你们也有自己的事。\n\n【guest:neutral】纸粘一起了，我给您分开。\n\n【holt:neutral】不用。我这点事还能干。你们去吧。",
        "labels": [
          "告辞，不再答应别的"
        ]
      },
      "fall": {
        "text": "【stage:neutral】赫尔特昏了过去，仍有呼吸。\n\n【guest:neutral】别晃他！我去喊值守的。\n\n【stage:neutral】值守人抬来担架，把他送进值班室休息。\n\n【host:neutral】本子和拐杖带上，他醒了肯定找。",
        "labels": [
          "收好本子，送到值班室"
        ]
      }
    },
    "3": {
      "start": {
        "text": "{CITY:holt}\n\n第七层的闸门前，赫尔特正用扳手拧一只锈死的螺帽。他脚边放着椅子，椅面整齐摆着本子、帽子和那张检查单。\n\n「别站门缝前。」他没回头，「一会儿出水。」\n\n墙上刻着开闸后的水位，最高一道越过了城顶。TA 问谁叫他开的，老人翻了几页本子，没找到名字，只找到自己的字：城沉了，欠下的名字就不必再找。\n\n他把那页按平，重新握住闸柄。螺帽已经松了，现在拦他还来得及。",
        "labels": [
          "走近，问清楚开闸的原因",
          "先看他在操作什么",
          "一起按住闸柄，让他停下"
        ]
      },
      "approach": {
        "text": "【holt:annoyed】闸一开，七层全灌满。账烂了，谁也别查了。\n\n【guest:neutral】人呢？街上那些人也灌？\n\n【holt:annoyed】我拿孙子的名字换了这份差事。城说替我存着，问它要，它又不给。我守到现在，连他长什么样都忘了。\n\n【host:neutral】那也不能拿一城人撒气。先松手。",
        "labels": [
          "我们帮您留记录，继续找",
          "城里的人招谁惹谁了？",
          "拿静默者的线索对一下"
        ]
      },
      "observe": {
        "text": "【guest:neutral】最后一条，确认没人。您自己写的。\n\n【holt:neutral】我看见了。\n\n【guest:neutral】街上摊还没收呢。\n\n【holt:neutral】我知道！……让我缓缓。我现在满脑子都是那孩子，想得头疼。",
        "labels": [
          "用静默者的线索查查",
          "人还没走完，停闸",
          "您看这条：确认没人"
        ]
      },
      "block": {
        "text": "【holt:annoyed】让开，我有钥匙。\n\n【guest:neutral】有钥匙也不能想淹谁就淹谁。\n\n【holt:annoyed】我就想把这破事做完。\n\n【host:neutral】那得换个做法。我们不松手。",
        "labels": [
          "我们接着替您找",
          "先把闸固定住",
          "拿出静默者的线索"
        ]
      },
      "remember_offer": {
        "text": "【holt:neutral】名字都没了，记什么？\n\n【guest:neutral】您给孩子缝过个绿布袋，这个总能记。\n\n【holt:neutral】蓝的。洗旧了看着像绿的，你别乱记。\n\n【host:neutral】行，蓝的。您接着说，我们听着。",
        "labels": [
          "行，我们帮您记着",
          "这份托付，我们接不了",
          "拿静默者的线索认针脚"
        ]
      },
      "grandson": {
        "text": "【stage:neutral】静默者留下的半截绣字，与袖口的断线对上。最后一笔由老人自己补上。\n\n【holt:neutral】对……是这个。他嫌我字丑，非得多缝一横。\n\n【guest:neutral】这回认准了？\n\n【holt:neutral】准了。等下，我再写一遍。",
        "labels": [
          "我们再抄一份",
          "您多写几遍，我们核对",
          "名字找回了，同意沉城"
        ]
      },
      "oppose": {
        "text": "【host:neutral】您淹的是人，不是一本账。玛拉她们还在下面。\n\n【holt:annoyed】天天找，天天找。谁都找不着，干脆都别找了。\n\n【guest:neutral】您找烦了，凭什么让别人一块儿死？\n\n【holt:annoyed】……别喊，我听得见。",
        "labels": [
          "一起拦住，不许开",
          "让他开闸，接受沉城",
          "先对一下静默者的线索"
        ]
      },
      "agree_remember": {
        "text": "【holt:neutral】扶一下，栓子对不上。手抖，别催。\n\n【guest:neutral】稳着呢，您插。\n\n【holt:neutral】好了。记不清的就空着，别编。还有，哪天我又来问，你们别嫌我烦。",
        "labels": [
          "忘了就问，我们还讲",
          "把核实的名字刻在骨桥上",
          "您自己也得留一份"
        ]
      },
      "refuse_remember": {
        "text": "【holt:annoyed】行，不接就不接。这也不是你们的活。\n\n【guest:neutral】那您把手松开。\n\n【holt:annoyed】要走走左边。右边低，水马上就到了。\n\n【host:neutral】您还真打算开？",
        "labels": [
          "退开，让他开闸",
          "改口：我们接了，您停手",
          "同意淹城，不拦了"
        ]
      },
      "stop_him": {
        "text": "【holt:annoyed】我说了，不是闸坏了，是我要开！\n\n【guest:neutral】听懂了。所以才拦您。\n\n【holt:annoyed】那明天呢？明天我又全忘了，谁来告诉我？\n\n【host:neutral】明天再说。您先坐下，别动这个了。",
        "labels": [
          "我们留记录，以后提醒",
          "一起核对静默者的线索",
          "先守着闸，别的以后说"
        ]
      },
      "city_sink": {
        "text": "【stage:neutral】闸门打开，水涌进街道。警铃响了。\n\n【guest:neutral】靠，真开了！快关！\n\n【holt:annoyed】我那张纸……\n\n【host:neutral】别管纸！先关小点，进去的水已经收不回来了！",
        "labels": [
          "留下，接受淹城的后果",
          "接下托付，马上劝他关闸",
          "离开，任水继续灌"
        ]
      },
      "end_remember": {
        "text": "【holt:smile】栓子卡死了。你们检查下，别听我一句好了就走。\n\n【guest:neutral】稳了。明天记得看本子。\n\n【holt:smile】看不懂我还得问。\n\n【host:neutral】那就问，别动闸就行。",
        "labels": [
          "下回继续对记录",
          "确认的名字刻在桥上",
          "提醒他看本子，告辞"
        ]
      },
      "end_sink": {
        "text": "【holt:annoyed】上头还有路，你们走。\n\n【guest:neutral】您说要全淹了，倒还把本子护得挺紧。\n\n【holt:annoyed】……那是我的。\n\n【host:neutral】闸柄还够得着。您到底关不关？",
        "labels": [
          "陪着他，接受沉城",
          "最后劝一次：关闸，我们接了",
          "上台阶走，不再阻止"
        ]
      }
    }
  },
  "pip": {
    "1": {
      "start": {
        "text": "市场木箱上写着「皮普办事处」，下面还有一行小字：问路一枚星砂，聊天不收钱。\n\n牌子的主人正在拿半块馒头砸核桃。砸了两下，他发现你们在看，立刻把核桃踢到箱底。\n\n「我试试新货结不结实。」\n\nTA 看着馒头：「结实。」\n\n皮普拍掉上面的灰，挑了没碰过核桃的一面递过来。他的袖口卷了三层，还是盖住半只手。\n\n「吃吗？不收钱。你们得坐下，站着挡我招牌了。」",
        "labels": [
          "接过馒头，在箱子旁坐下",
          "问问办事处老板叫什么",
          "让 TA 先跟他打招呼"
        ]
      },
      "bread": {
        "text": "【guest:neutral】你这馒头拿来防身的吧？\n\n【pip:neutral】掰这里！你看——嘶，牙疼。\n\n【host:neutral】我给你掰。\n\n【pip:neutral】等下，手伸出来。我数数，十根都在吧？这里什么都会丢，我每天都数。",
        "labels": [
          "把 TA 的手也递过去",
          "馒头还给他"
        ]
      },
      "name": {
        "text": "【pip:smile】皮普。不是皮皮，叫错了我不理你。\n\n【guest:neutral】牌上那个「普」是不是反了？\n\n【pip:smile】你别管牌。你们叫什么？一个一个说，我得记俩。",
        "labels": [
          "告诉他两人的名字",
          "你妈妈呢？"
        ]
      },
      "together": {
        "text": "【pip:smile】坐箱子。篮子底是坏的，刚才忘了。\n\n【host:neutral】你自己坐哪个？\n\n【pip:smile】我站着。我是老板，老板站着说。你俩谁先？",
        "labels": [
          "我先说",
          "让 TA 先说"
        ]
      },
      "count": {
        "text": "【pip:neutral】九根……你藏了一根！伸出来！\n\n【host:neutral】给你，十根。你要学的就是这张回声术？\n\n【guest:neutral】先看小字：教的人得交出名字，名字不退。回家以后也认不出彼此，走「面具」结局。\n\n【pip:neutral】那不学了。这什么破学费，教个别的。",
        "labels": [
          "交出名字，教回声术（回家进入「面具」结局）",
          "不学这个，换一个"
        ],
        "hints": [
          "失去名字；之后选择普通回家将进入「面具」结局，不能撤回。",
          null
        ]
      },
      "refuse": {
        "text": "【pip:annoyed】嫌硬就说硬，我又不是不知道。\n\n【guest:neutral】他给的是自己那份。\n\n【pip:annoyed】谁说的，我还有！……你别看我口袋。还坐不坐？",
        "labels": [
          "接回来：对不住啊",
          "不收，坐一会儿"
        ]
      },
      "introduce": {
        "text": "【pip:smile】这个是你，这个是——不对，核桃摆反了。\n\n【guest:neutral】赖核桃啊？\n\n【pip:smile】本来就是。喏，潮汐石，能换钱。我捡的，送你们。\n\n【host:neutral】你舍得？",
        "labels": [
          "收下潮汐石",
          "你自己留着吧"
        ]
      },
      "mother": {
        "text": "【pip:annoyed】我喊妈妈，她问我找谁。我说找你，她说认错门了。\n\n【guest:neutral】她一点都不记得？\n\n【pip:annoyed】不记得。她会补网，左手拉线，我这个结就是她教的。……吃吧，别老看我。",
        "labels": [
          "这事我们也记着",
          "陪他吃馒头"
        ]
      },
      "youfirst": {
        "text": "【pip:smile】你叫这个……算了，字太难写，画个圈。\n\n【guest:neutral】我也一个圈？那怎么分？\n\n【pip:smile】大的算你。好了，你们教我个词，或者我教你们。",
        "labels": [
          "教他个用得上的词",
          "教我们句本地话"
        ]
      },
      "tapfirst": {
        "text": "【pip:smile】等一下！前面那个名字还没记牢呢。\n\n【host:neutral】我不急。\n\n【pip:smile】你可以急一点。我忘得快，得连着念。再说一遍？",
        "labels": [
          "教他个用得上的词",
          "教我们句本地话"
        ]
      },
      "teach": {
        "text": "【pip:neutral】买东西的我会，骂人的也会。想叫别人别走，怎么说？\n\n【guest:neutral】就说「别走」。\n\n【pip:neutral】这么说，他们也走。还有没有别的？",
        "labels": [
          "想说就说，先开口",
          "「回声不骗人」啥意思？",
          "不教了，走"
        ]
      },
      "end_good": {
        "text": "【pip:smile】那我先说了。下次经过，还来找我。\n\n【guest:neutral】行。\n\n【pip:smile】说好了啊。两张牌，你们一人一张，算学费。我不白学。",
        "labels": []
      },
      "end_neutral": {
        "text": "【pip:smile】皮普——听见没有？墙也喊皮普。\n\n【guest:neutral】这不就是回音？\n\n【pip:smile】对啊！这个不用押名字。千万别喊笨蛋，我吃过亏。给你一枚星砂，下回还来。",
        "labels": []
      },
      "end_cold": {
        "text": "【pip:neutral】哎，我还没学呢……真走啊？\n\n【stage:neutral】皮普把招牌翻了回去。\n\n【pip:neutral】算了，我问别人。隔壁那个，你会不会？",
        "labels": []
      }
    },
    "2": {
      "start": {
        "text": "{CITY:pip}\n\n皮普在镜子前练习敲门。敲三下，清嗓子，再把衣领拉正。看见你们，他立刻收起手。\n\n「这里的镜子归我检查。」\n\nTA 指指镜里的人：「她也是检查的东西？」\n\n皮普不吭声了。远处一面大铜镜里，女人正在给两个孩子分吃的。她每次笑，他都会往前挪一点。\n\n「那是我妈妈。现实里她不记得我，镜子里倒有别的孩子。」他用鞋尖蹭着地面，「你们陪我过去一下？我知道路，不算请你们带路。」",
        "labels": [
          "陪他去看镜中的妈妈",
          "先问问那位女人的事",
          "先逛市场，晚点再去",
          "把她的名字和模样也记下来"
        ]
      },
      "ask_mother": {
        "text": "【pip:neutral】系围巾的，别看卖围巾那个，那是个男的。\n\n【guest:neutral】你来过几回了？\n\n【pip:neutral】记不住了。她一会儿会回头，你们先别出声，我想叫她。",
        "labels": [
          "走，你带路",
          "先教他怎么开口",
          "先不去",
          "信他，陪他去"
        ]
      },
      "market_delay": {
        "text": "【pip:annoyed】你们说晚点，现在算晚点了吗？\n\n【guest:neutral】再逛一会儿。\n\n【pip:annoyed】第三遍了。去不去给个准话，别拿我当傻子哄。",
        "labels": [
          "现在就去",
          "花 2 星砂，买个馒头",
          "今天先走",
          "绕过钟楼再陪他去"
        ]
      },
      "buy_bun": {
        "text": "【pip:neutral】先掰开，上次有个人往里面塞石头。\n\n【guest:neutral】这个没有，吃吧。\n\n【pip:neutral】嗯。剩这点我留着，万一她肯跟我说话，说久了饿。",
        "labels": [
          "吃完就去",
          "今天先走",
          "先记下她的样子"
        ]
      },
      "mirror_mother": {
        "text": "【pip:neutral】妈妈？……妈！\n\n【stage:neutral】镜里的女人接过碗，没有看他。\n\n【pip:neutral】又没听见。我天天来，她天天不认识。我是不是挺烦的？\n\n【guest:neutral】你想走，还是还想等？",
        "labels": [
          "想她就来，不丢人",
          "不想来了，也行",
          "这个我真不知道",
          "帮他记住妈妈的样子",
          "你最怕忘了什么？"
        ]
      },
      "ask_forget": {
        "text": "【pip:neutral】她笑的时候会拽围巾，这边有个坑。\n\n【guest:neutral】酒窝。\n\n【pip:neutral】对，酒窝。颜色我已经忘了，你们也记一下。我说错了就纠正，别光点头。",
        "labels": [
          "行，我们也记",
          "今天先走",
          "镜子里的未必是真的",
          "陪他叫一声妈妈"
        ]
      },
      "comfort": {
        "text": "【pip:neutral】我不是怕，就是不知道怎么办。\n\n【host:neutral】那先坐会儿。\n\n【pip:neutral】坐了也还是不知道。你们教我一句，等她转过来，我别光张嘴。",
        "labels": [
          "教他喊「妈，你看看我」",
          "陪他再叫一次",
          "今天看到这儿吧",
          "我们帮你记着她"
        ]
      },
      "doubt": {
        "text": "【pip:annoyed】知道，镜子会骗人。你们说八百遍了。\n\n【guest:neutral】我们怕你白等。\n\n【pip:annoyed】我又没说她认出我了。我就想多看两眼，也不行？",
        "labels": [
          "我们信你说的",
          "行，再陪你等会儿",
          "不等了，先走",
          "先练练怎么开口"
        ]
      },
      "remember": {
        "text": "【pip:neutral】她缝衣服先咬线。生气不摔碗，哐一下，放得特别响。\n\n【guest:neutral】围巾这边有个结，对吧？\n\n【pip:neutral】对！你们分着记，忘了就互相问。别全指望我，我脑子也不好使。",
        "labels": [
          "陪他再去问",
          "先走吧",
          "教他怎么叫妈妈",
          "我们两个都记着"
        ]
      },
      "teach_word": {
        "text": "【guest:neutral】别在嘴里嘀咕。抬头，说「妈，你看看我」。\n\n【pip:neutral】妈，你看看我。……这样？\n\n【host:neutral】对。\n\n【pip:neutral】那我叫了，她还是不认识呢？我还能来吗？",
        "labels": [
          "想来就还来",
          "不来了也行",
          "我也想不明白",
          "帮他记住她的样子"
        ]
      },
      "the_question": {
        "text": "【pip:annoyed】妈妈，你看看我！\n\n【stage:neutral】女人转身，把饼分给镜里的孩子。\n\n【pip:annoyed】不是看我。我就知道。\n\n【pip:annoyed】你们说，我天天来，是不是很傻？",
        "labels": [
          "不傻，想她就来",
          "不想来了，也行",
          "我替你决定不了",
          "我们帮你记着她"
        ]
      },
      "love_answer": {
        "text": "【pip:neutral】那我今天还来。明天……明天再说。\n\n【guest:neutral】我们陪你坐一会儿。\n\n【pip:neutral】别坐坏篮子，坐我这儿。下次给你们找点软的吃。",
        "labels": []
      },
      "not_love_answer": {
        "text": "【pip:annoyed】行，今天不喜欢她了。\n\n【stage:neutral】他在镜脚边放下一点馒头。\n\n【guest:neutral】还给她留？\n\n【pip:annoyed】掉的。你话怎么那么多。",
        "labels": []
      },
      "unsure_answer": {
        "text": "【pip:neutral】你们也不会啊。\n\n【host:neutral】嗯，这个真不会。\n\n【pip:neutral】那我再等会儿。你们要走就说一声，别悄没声地没了。",
        "labels": []
      },
      "leave": {
        "text": "【pip:neutral】你们走吧，我还等。\n\n【guest:neutral】饿了记得吃东西。\n\n【pip:neutral】知道，别一人说一遍。我在这儿，不乱跑。",
        "labels": []
      }
    },
    "3": {
      "start": {
        "text": "{CITY:pip}\n\n石屋门外，皮普正在跟衣领较劲。刚压平左边，右边又翘起来，最后他恼火地把两边都塞了进去。\n\n「听说她住这儿。我先来确认一下，没想躲着你们。」\n\n门里传来编网的声音。他向前走了半步，又退回来，把鞋底的泥在石阶上蹭干净。\n\nTA 问要不要一起进去，他马上点头，点完又补一句：「你们走后面。让我先说。」\n\n他伸手去碰门，碰到一半停住。\n\n「要是她还问我是谁，你们别跟着问，好吗？」",
        "labels": [
          "陪皮普进去",
          "先在门外陪他聊聊"
        ]
      },
      "talk_first": {
        "text": "【pip:neutral】潮汐石、绳子、纽扣，拿哪个她能想起来？\n\n【guest:neutral】纽扣哪儿来的？\n\n【pip:neutral】忘了。……得，这个先收着。先说名字吧，皮普，两个字，又不难。",
        "labels": [
          "陪他进屋"
        ]
      },
      "find_mother": {
        "text": "【pip:neutral】妈妈，你看，我还会打这个结。帮我捏一下，绳子太短。\n\n【stage:neutral】女人停下补网，问他找谁。\n\n【pip:neutral】找你。我找你好久了。",
        "labels": [
          "先喘口气，慢慢说"
        ]
      },
      "meet_mother": {
        "text": "【stage:neutral】女人摇头：「你认错了。我不记得有过孩子。」\n\n【pip:annoyed】可你教过我啊，外套也是你……\n\n【guest:neutral】皮普，先喘口气。\n\n【pip:annoyed】我还有好多能说的。还问吗？她好像不想听。",
        "labels": [
          "再提醒她几件事",
          "不问了，带皮普走",
          "先查他的来处，找真正的母亲"
        ]
      },
      "demand_1": {
        "text": "【pip:annoyed】十三个结。你说少数一个就重数。还有，得坐左边，右边挡光。\n\n【stage:neutral】女人挪开灯，又把网收回去：「真不记得了，别问了。」\n\n【pip:annoyed】那你怎么挪灯？你刚才明明记得！",
        "labels": [
          "接着讲以前的事",
          "停下，不再逼她想"
        ]
      },
      "demand_2": {
        "text": "【pip:annoyed】你教我数手指。一、二……七……\n\n【stage:neutral】女人接了一声「八」。\n\n【pip:annoyed】你知道！那九后面呢？\n\n【stage:neutral】「十。孩子，我会数数。可我还是想不起你。」",
        "labels": [
          "留不留，让皮普自己选"
        ]
      },
      "demand_end": {
        "text": "【pip:neutral】我坐一会儿，你补你的，不问了。\n\n【stage:neutral】女人伸手压平他的衣领，嘀咕：「这里怎么老翘……」\n\n【pip:neutral】另一边也翘。你给我弄一下。",
        "labels": []
      },
      "accept_1": {
        "text": "【pip:annoyed】行，不问了。\n\n【guest:neutral】走吧，我帮你拿。\n\n【pip:annoyed】不用。你们走慢点，我现在不想说话。",
        "labels": [
          "陪他出去"
        ]
      },
      "accept_2": {
        "text": "【pip:annoyed】等会儿，纽扣掉了。\n\n【guest:neutral】不就在你手里？\n\n【pip:annoyed】……我想等一下。万一她追出来呢。\n\n【host:neutral】那就等一下。",
        "labels": [
          "放慢点，陪着他"
        ]
      },
      "accept_end": {
        "text": "【pip:neutral】走累了，歇会儿。\n\n【guest:neutral】坐这儿。\n\n【pip:neutral】今天不回去了。你们也别走太快，路黑。",
        "labels": []
      },
      "hidden_1": {
        "text": "【pip:neutral】他们说我们是好多孩子的回声，混在一块儿。我会的，不一定都是一个妈妈教的。\n\n【guest:neutral】那你一直找的，可能不是她？\n\n【pip:neutral】我不想听这个。可那边也有人叫我……走，去看看，你们跟着。",
        "labels": [
          "去找那个声音"
        ]
      },
      "hidden_2": {
        "text": "【pip:neutral】这首歌我会！后面是什么来着……\n\n【guest:neutral】声音在前面。\n\n【pip:neutral】抓着我。到那儿也别松，等我说。",
        "labels": [
          "一起走到灯下"
        ]
      },
      "hidden_3": {
        "text": "【stage:neutral】灯下的女人蹲下来：「鞋带又绕两圈，拆不开还得找我。」\n\n【pip:smile】你记得我？\n\n【stage:neutral】「衣领也乱了。过来，左边先压好。」\n\n【pip:smile】妈！你别走，我有好多事没说！",
        "labels": [
          "让他们待一会儿"
        ]
      },
      "hidden_end": {
        "text": "【pip:smile】十枚星砂，你们路上用。我数好了，别推。\n\n【guest:neutral】还跟我们走吗？\n\n【pip:smile】今天不了，我还没说完呢。以后来，喊皮普，我听得见。",
        "labels": []
      }
    }
  }
};
const pending=[];
const originals={};
for(const [person,acts] of Object.entries(rewrites)){
 const npc=G.npcs.find(n=>n.id===person);
 if(!npc)throw new Error('Unknown NPC voice: '+person);
 originals[person]={};
 for(const [act,rows] of Object.entries(acts)){
  const meeting=npc.meetings.find(m=>m.act===Number(act));
  if(!meeting||Object.keys(meeting.nodes).length!==Object.keys(rows).length)throw new Error('Incomplete NPC voice: '+person+':'+act);
  originals[person][act]=JSON.parse(JSON.stringify(meeting.nodes));
  for(const [id,row] of Object.entries(rows)){
   const node=meeting.nodes[id];
   if(!node||typeof row.text!=='string'||row.labels.length!==(node.choices||[]).length||row.labels.some(label=>typeof label!=='string'))throw new Error('Invalid NPC voice: '+person+':'+act+':'+id);
   if(row.hints&&row.hints.length!==row.labels.length)throw new Error('Invalid NPC hint count: '+person+':'+act+':'+id);
   pending.push({node,row});
  }
 }
}
// Validate the complete patch before touching any live node.
for(const {node,row} of pending){
 node.text=row.text;
 (node.choices||[]).forEach((choice,index)=>{
  choice.label=row.labels[index];
  if(row.hints?.[index]!=null)choice.hint=row.hints[index];
 });
}
G.npcNeighborVoiceOriginals=originals;
G.npcNeighborVoices={version:1,nodes:pending.length};
})(window.GAME_DATA);
