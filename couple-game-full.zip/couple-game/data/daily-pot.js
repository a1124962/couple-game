/* Night-shift kitchen: spoken trouble, choices, and consequences. Originals are archived. */
(function(G){
'use strict';
G.dailyScenePacks=G.dailyScenePacks||{};
if(G.dailyScenePacks.pot)return;
G.dailyScenePacks.pot=[
  {
    "id": "daily_pot_1",
    "kind": "duo",
    "act": 1,
    "title": "空凳子还要加饭",
    "purpose": "一个接待客人，一个管锅。先把这顿夜饭送出去。",
    "stage": {
      "background": "kitchen",
      "cast": [
        "innkeeper"
      ]
    },
    "text": "【host:neutral】您说看七分钟锅抵两张床，没说还得接客啊。\n\n【innkeeper:neutral】就一位，吃口热的，能有多难？床给你俩留着了。\n\n【stage】空凳子挪到桌前，锅沿响了两下。\n\n【guest:neutral】人呢？凳子都坐过来了。\n\n【innkeeper:neutral】敲锅的就是他。缺口锅盖别堵，剩下的你们问，我洗个头去。\n\n【host:neutral】哎，您倒是……走得还挺快。行，锅归你，我跟凳子聊。",
    "clues": {
      "host": "你守着空凳子。桌面压着一张打了两个孔的铜餐票，没写名字。凳子往热锅挪；你把饭碗端过去，它反而退了。可以问他要多烫，也可以先问他怎么吃。",
      "guest": "你站在灶边。汤没少，锅上方却有个模糊的嘴印。缺口锅盖搭在锅上时，蒸汽正好从缺口钻出来；把盖拿开，整张桌子都会起雾。"
    },
    "options": {
      "host": [
        "问他要多烫，先接住这单",
        "先问清楚：您用不用碗"
      ],
      "guest": [
        "从锅盖缺口慢慢送出蒸汽",
        "揭开整只锅盖，热气管够"
      ]
    },
    "results": [
      {
        "flag": "daily_pot_1_0",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】烫点是吧？行，您别往锅里坐！\n\n【guest:neutral】我拿盖子挡着。诶，热气往凳子上去了。\n\n【innkeeper:neutral】吃上了就行。楼下炉房的，只吃热气。汤归你们。\n\n【host:neutral】那我不客气了。票呢？\n\n【innkeeper:neutral】留着。两孔夜饭票，下回按这个往楼下送。鱼给我留一条！"
      },
      {
        "flag": "daily_pot_1_1",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】要热的是吧？给您整烫点。\n\n【stage】锅盖一掀，白汽把饭厅填满了。\n\n【guest:neutral】你摸哪儿呢？这是我的脸！\n\n【innkeeper:annoyed】他都吃饱回炉房了，你俩还摸什么？把汤喝了，窗给我开开。\n\n【host:neutral】票落这儿了。两孔这张？\n\n【innkeeper:neutral】收着，下回送夜饭还用。锅盖放下，别再掀了！我刚洗的头又一股鱼味。"
      },
      {
        "flag": "daily_pot_1_2",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】您不用碗啊？那鱼……\n\n【guest:neutral】人家吃缺口冒出来的热气。鱼你问唐婶。\n\n【innkeeper:annoyed】我听见了！你们的鱼在锅底，上头这条是我的。\n\n【host:neutral】您不是洗头去了？\n\n【innkeeper:neutral】就你那嗓门，隔两条街都听得见。吃吧，两孔夜饭票也收好，下回往楼下送。"
      },
      {
        "flag": "daily_pot_1_3",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】不用碗，吃气？那你掀吧，省得端。\n\n【stage】热气卷起两条围裙，直往门外钻。\n\n【guest:neutral】坏了，衣服！你堵门，我捞！\n\n【innkeeper:annoyed】谁把我围裙也上菜了？\n\n【host:neutral】没吃，拿回来了。您摸摸，还挺干爽。\n\n【innkeeper:neutral】少贫。锅底有汤，吃完把这两孔票收好，下回送炉房。围裙给我挂回去！"
      }
    ]
  },
  {
    "id": "daily_pot_2",
    "kind": "duo",
    "act": 2,
    "title": "锅盖里面有人敲门",
    "purpose": "一个对着锅盖问话，一个在后面找声音。两边听见的东西不一样。",
    "stage": {
      "background": "kitchen",
      "cast": [
        "innkeeper"
      ]
    },
    "text": "{DAILY:pot_1}\n\n【innkeeper:neutral】夜饭又退回来了，连热气都没动。你俩听听，他往我锅盖里说什么呢？\n\n【host:neutral】这锅还能骂人？\n\n【innkeeper:neutral】别胡说，炉房那位。换了防风门以后，就这么敲。\n\n【guest:neutral】我去灶后。你问前头，别俩人一块儿喊。\n\n【host:neutral】行。唐婶您别趴盖上，声音都让您袖子捂住了。",
    "clues": {
      "host": "你坐在锅盖前。盖底的声音很轻，说的是“门”，不是“没”。餐票的两个孔连着打，边缘有多年敲出来的凹痕。可以问他哪扇门，也可以照旧敲两下，让他知道有人听见。",
      "guest": "你在灶后。声音沿热水管传上来，锅盖刚好把它放大了。管上有个小铜扣，按住能听清；松开会发出哨声，楼下也会听见。"
    },
    "callbacks": {
      "pot_1": {
        "daily_pot_1_0": "【innkeeper:neutral】上回你们那条细汽喂得挺好，今天怎么一口没动？",
        "daily_pot_1_1": "【innkeeper:annoyed】这回别掀盖！上次雾一起，客人把我一只拖鞋穿走了。",
        "daily_pot_1_2": "【innkeeper:neutral】你们问明白他不用碗，我才省了洗。今天连气都不吃了。",
        "daily_pot_1_3": "【innkeeper:annoyed】围裙我收好了。今天别再往外追。",
        "default": "【innkeeper:neutral】头回来吧？楼下那位吃热气，敲两下要饭。这是他的两孔票，锅盖能传他的声。"
      }
    },
    "options": {
      "host": [
        "问是哪扇门，先把位置弄清楚",
        "照餐票敲两下，告诉他有人在"
      ],
      "guest": [
        "按住铜扣，听清他后半句",
        "松开铜扣，给楼下吹声回哨"
      ]
    },
    "results": [
      {
        "flag": "daily_pot_2_0",
        "bond": 2,
        "gold": 4,
        "text": "【host:neutral】哪扇门？您慢点说。\n\n【guest:neutral】按住铜扣能听清了。炉房外门，他说新门把他关里头了。\n\n【innkeeper:neutral】那门是我让装的，省得热气跑出去……哎哟，他不就是热气吗！\n\n【host:neutral】还有一句。不是辞工，让您放他出来吃饭。\n\n【innkeeper:neutral】行，我去端饭。钥匙夹票里了，四枚跑腿钱也拿着。你们先下去开门。"
      },
      {
        "flag": "daily_pot_2_1",
        "bond": 2,
        "gold": 4,
        "text": "【host:neutral】炉房外门？是那扇新的？\n\n【stage】铜管一声长哨，澡堂客人裹着浴巾跑进饭厅。\n\n【innkeeper:annoyed】别吹了！甲鱼都喊出锅了，你想炖谁啊？\n\n【guest:neutral】我就回个话。\n\n【host:neutral】问清了，新门把师傅关里头了，他想出来吃饭。钥匙呢？\n\n【innkeeper:neutral】给，连票和四枚跑腿钱一起拿走。我去跟客人解释，别再吹！"
      },
      {
        "flag": "daily_pot_2_2",
        "bond": 2,
        "gold": 4,
        "text": "【host:neutral】敲两下是您吧？听见就敲回来。\n\n【guest:neutral】应了。等会儿，铜扣按住……他想出来吃饭，外门关着。\n\n【innkeeper:annoyed】我花钱装的防风门，把自家人关里头了？这钱花的！\n\n【host:neutral】那门上能开个口吗？\n\n【innkeeper:neutral】先放人。钥匙、两孔票都带上，钱在围裙兜里，数四枚。锅底这份别倒，我端下去。"
      },
      {
        "flag": "daily_pot_2_3",
        "bond": 2,
        "gold": 4,
        "text": "【host:neutral】我敲两下，你回一声。\n\n【stage】锅盖、哨声和楼下同时响，什么也听不清。\n\n【innkeeper:annoyed】停！你俩是来问话还是来凑乐队的？\n\n【guest:neutral】我不吹了。你问，他敲。\n\n【host:neutral】被新门关里面了？两下。想出来吃饭？又两下。行，齐活！\n\n【innkeeper:neutral】钥匙夹票里，四枚跑腿钱拿上，锅盖也带着找人。我去盛饭，下楼别再敲了。"
      }
    ]
  },
  {
    "id": "daily_pot_3",
    "kind": "duo",
    "act": 3,
    "title": "炉房师傅也要下班",
    "purpose": "一个叫人，一个找路，把困在炉房里的师傅接出来吃饭。",
    "stage": {
      "background": "bathhouse",
      "cast": [
        "innkeeper"
      ]
    },
    "text": "{DAILY:pot_2}\n\n【host:neutral】门都开了，还不出来？您刚才喊什么了？\n\n【innkeeper:neutral】出来！我还等着呢！就这么喊的。\n\n【guest:neutral】听着像催人干活。您坐下吧，我们试试。\n\n【stage】冷风灌进门，一股热气缩回管子里。\n\n【host:neutral】哎，又吹回去了！光开门没用。\n\n【innkeeper:neutral】那锅和锅盖都拿去挡挡，别让他再钻回去了。饭给你们留着呢。",
    "clues": {
      "host": "两孔餐票还会响，锅盖里能听见两下回应。你可以沿桌边敲票带路，也可以让唐婶坐在饭桌旁正常叫他吃饭。不要再喊“出来干活”。",
      "guest": "炉房门一开，冷风直灌。缺口锅盖能挡住大半风，留下细细的热气通道；也可以把装热汤的大锅挪到门边，让蒸汽一路连到饭桌。"
    },
    "callbacks": {
      "pot_2": {
        "daily_pot_2_0": "【innkeeper:neutral】还是你俩耳朵好使。我还当他嫌饭难吃，闹了半天是门的事。",
        "daily_pot_2_1": "【innkeeper:annoyed】今天谁也别吹哨。甲鱼听见就往外跑，我拦不住。",
        "daily_pot_2_2": "【innkeeper:neutral】四枚跑腿钱数清了吧？今天接着麻烦你们，少不了你俩的饭。",
        "daily_pot_2_3": "【innkeeper:neutral】上回你俩敲得我脑仁疼。今天一个一个来，行不行？",
        "default": "【innkeeper:neutral】炉房那位吃热气，新门把他关里头了。敲两孔票他会答，给，你们试试。"
      }
    },
    "options": {
      "host": [
        "用两孔餐票敲着桌沿，带他过来",
        "让唐婶坐下，好好叫他吃饭"
      ],
      "guest": [
        "用缺口锅盖挡风，留一条热气口",
        "搬来大汤锅，让蒸汽连到饭桌"
      ]
    },
    "results": [
      {
        "flag": "daily_pot_3_0",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】跟票走，这边，再来两步……\n\n【guest:neutral】慢点！我举着锅盖呢，你倒走得轻巧。\n\n【stage】热气沿锅盖的缺口绕过冷风，坐上凳子。\n\n【innkeeper:neutral】可算出来了。坐稳，没人催你。\n\n【host:neutral】他又敲了。要添饭？那我们这两孔票还用还吗？\n\n【innkeeper:neutral】留着。哪天饿了就来。你把锅盖放下，鱼都盛你碗里了！"
      },
      {
        "flag": "daily_pot_3_1",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】跟票声走……你那锅怎么还没抬过来？\n\n【guest:neutral】你来抬！光长嘴了？\n\n【innkeeper:annoyed】票给我，你俩抬。慢点，汤洒了真没你们的了。\n\n【stage】锅摆到门边，蒸汽连上饭桌，炉房师傅坐了下来。\n\n【host:neutral】到了。怎么又敲两下？\n\n【innkeeper:neutral】还要添呢。你们也坐，鱼盛上了。票不用还，饿了再来。"
      },
      {
        "flag": "daily_pot_3_2",
        "bond": 2,
        "heal": 3,
        "text": "【innkeeper:neutral】吃饭！今晚煤我添，不扣工钱，出来！\n\n【guest:neutral】哎，真出来了。锅盖挡这边，别迎着风。\n\n【host:neutral】刚才叫半天都不动。\n\n【innkeeper:neutral】下回我知道怎么叫了。盖放下，坐。\n\n【guest:neutral】这个票——\n\n【innkeeper:neutral】留着。你俩哪天又没饭吃，拿它来。鱼就在碗里，别翻锅。"
      },
      {
        "flag": "daily_pot_3_3",
        "bond": 2,
        "heal": 3,
        "text": "【innkeeper:neutral】不干了，先吃饭！煤我来添。\n\n【guest:neutral】锅摆这儿？你挡门，别躲我后头。\n\n【stage】蒸汽从汤锅连到凳子，一团热气坐了下来。\n\n【host:neutral】坐好了。您从前一直没听懂他敲什么？\n\n【innkeeper:neutral】我还当管子松了，拧紧过两回。真是……明天我全松回来。\n\n【guest:neutral】票我收着了，您先添饭，他又敲了。"
      }
    ]
  }
];
})(window.GAME_DATA);
