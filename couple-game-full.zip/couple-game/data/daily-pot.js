/* The bathhouse kitchen's night shift. Dialogue-led, with choice-specific receipts. */
(function(G){
'use strict';
G.dailyScenePacks=G.dailyScenePacks||{};
if(G.dailyScenePacks.pot)return;
G.dailyScenePacks.pot=[
 {
  id:'daily_pot_1',kind:'duo',act:1,title:'空凳子还要加饭',
  purpose:'一个接待客人，一个管锅。先把这顿夜饭送出去。',
  stage:{background:'kitchen',cast:['innkeeper']},
  text:`【stage】空凳子往桌前挪了一寸。

【host:neutral】这张凳子是不是自己动了？

【innkeeper:neutral】嗯。它那位客人坐得低，你们看不见。

【guest:neutral】客人要吃什么？

【innkeeper:neutral】热的。锅里有汤。盛完把缺口锅盖搁旁边，别拿布堵那个口。

【host:smile】我们就看七分钟锅，真能抵两张床？

【innkeeper:annoyed】能。洗脚水另外烧，不准往汤里兑。

【guest:neutral】这是我能问出来的问题？

【innkeeper:neutral】前一个就是看起来很懂事。

【stage】锅沿响了两声，桌面却没人。

【host:neutral】他敲两下，是要两份？

【innkeeper:neutral】不一定。你们问问。我洗个头就回来。客人催得凶，你们也别往锅里钻。`,
  clues:{host:'你守着空凳子。桌面压着一张打了两个孔的铜餐票，没写名字。凳子往热锅挪；你把饭碗端过去，它反而退了。可以问他要多烫，也可以先问他怎么吃。',guest:'你站在灶边。汤没少，锅上方却有个模糊的嘴印。缺口锅盖搭在锅上时，蒸汽正好从缺口钻出来；把盖拿开，整张桌子都会起雾。'},
  options:{host:['问他要多烫，先接住这单','先问清楚：您用不用碗'],guest:['从锅盖缺口慢慢送出蒸汽','揭开整只锅盖，热气管够']},
  results:[
   {flag:'daily_pot_1_0',bond:2,heal:3,text:`【host:neutral】您要烫一点，还是能直接入口的？

【guest:neutral】先拿手试试。我只开这么大。

【stage】一小股蒸汽在空凳上坐直。

【host:neutral】您手在哪儿？

【guest:smile】刚才问完就吹过来了，应该是这个意思。

【innkeeper:neutral】吃上了？不错，锅也没丢。

【host:neutral】他把汤都吸进去了，碗还是满的。

【innkeeper:neutral】他吃热气。你们吃剩下的汤，别嫌弃，鱼还在。

【guest:neutral】餐票还给他吗？

【innkeeper:neutral】你们收着。两孔是夜班饭，下回沿热水管送到楼下。先喝汤，这碗算我的。`},
   {flag:'daily_pot_1_1',bond:2,heal:3,text:`【host:smile】热汤马上就来，包您吃暖和。

【guest:neutral】我把盖子拿——

【stage】整张桌子被白汽吞掉。

【host:neutral】我人呢？我刚才还在这儿。

【guest:neutral】别摸了，那是我的脸。你左手还端着汤。

【innkeeper:annoyed】我洗个头，你们把饭厅也蒸上了？

【host:neutral】客人说要热的。

【innkeeper:neutral】人家吃饱了，已经回炉房了。你俩倒还没吃上。

【guest:smile】至少不用给饭厅擦灰了。

【innkeeper:annoyed】等雾散了你再说。桌上两孔餐票收好，下次照着这个送夜班饭。先喝汤，别在这儿捧着空锅盖。`},
   {flag:'daily_pot_1_2',bond:2,heal:3,text:`【host:neutral】您用不用碗？用的话，把碗往前推一点。

【stage】碗被推到你面前。

【host:neutral】给我的？

【guest:neutral】他一直冲锅盖那个缺口吸气。是不是只吃热的那一截？

【host:smile】那鱼归我？您要不同意就敲桌子。

【innkeeper:annoyed】少摸我的鱼。你们的在锅底。

【guest:neutral】您不是去洗头了吗？

【innkeeper:neutral】听见有人分鱼，我头发还滴着就来了。

【host:neutral】他把餐票留下了。

【innkeeper:neutral】夜班的，两孔，不写名字。收好，下次往楼下送。汤你们喝，劳驾给我留张凳子。`},
   {flag:'daily_pot_1_3',bond:2,heal:3,text:`【host:neutral】客人不用碗，他大概吃蒸汽。

【guest:smile】那简单。给他敞开吃。

【stage】热气卷走了两条晾着的围裙。

【host:neutral】您先把唐婶的衣服吐出来，那不加菜。

【guest:neutral】别往门外跑！我去堵后门，你捡围裙。

【innkeeper:annoyed】我怎么听见有人点我的衣服？

【host:neutral】没点，蹭上的。已经拿回来了。

【innkeeper:neutral】行，至少你们还知道捡。锅底有汤，一人一碗。

【guest:neutral】这张两个孔的票怎么办？

【innkeeper:neutral】收着，楼下炉房的夜饭票。下回送饭别把整间厨房一起送下去。`}
  ]
 },
 {
  id:'daily_pot_2',kind:'duo',act:2,title:'锅盖里面有人敲门',
  purpose:'一个对着锅盖问话，一个在后面找声音。两边听见的东西不一样。',
  stage:{background:'kitchen',cast:['innkeeper']},
  text:`【stage】唐婶把缺口锅盖倒扣在桌上。

{DAILY:pot_1}

【innkeeper:neutral】楼下刚换了防风门，夜饭就退回来了。汤还热，票没动。你们帮我听听。

【host:neutral】听锅盖？

【innkeeper:neutral】扣上会说话，拿开又没了。修锅的说贵，我就没让他接着说。

【guest:neutral】您是不是把耳朵捂住了？

【innkeeper:neutral】我把钱包捂住了。

【stage】盖底传来两下轻敲。

【host:neutral】跟那张餐票一样，两下。

【innkeeper:neutral】炉房师傅以前也这么叫我开饭。后来他只剩热气，声音越来越小。

【guest:neutral】那您把锅挪开，我到后面听。

【innkeeper:annoyed】别一边听一边拆。这口锅还得做晚饭。`,
  clues:{host:'你坐在锅盖前。盖底的声音很轻，说的是“门”，不是“没”。餐票的两个孔连着打，边缘有多年敲出来的凹痕。可以问他哪扇门，也可以照旧敲两下，让他知道有人听见。',guest:'你在灶后。声音沿热水管传上来，锅盖刚好把它放大了。管上有个小铜扣，按住能听清；松开会发出哨声，楼下也会听见。'},
  callbacks:{pot_1:{
   daily_pot_1_0:'【innkeeper:neutral】上回你们给他留的那条细汽，他吃得挺安稳。今天不对劲。',
   daily_pot_1_1:'【innkeeper:annoyed】这回先别掀盖。上次饭厅起雾，客人把我的拖鞋穿走一只。',
   daily_pot_1_2:'【innkeeper:neutral】上回你们问出他不用碗，省了我每天洗。今天连热气也没动。',
   daily_pot_1_3:'【innkeeper:annoyed】围裙我已经收起来了。今天就查声音，不用再追一次。',
   default:'【innkeeper:neutral】你们没来过这后厨吧？这锅盖能传楼下的声音。喏，这张两孔票也是楼下的。'
  }},
  options:{host:['问是哪扇门，先把位置弄清楚','照餐票敲两下，告诉他有人在'],guest:['按住铜扣，听清他后半句','松开铜扣，给楼下吹声回哨']},
  results:[
   {flag:'daily_pot_2_0',bond:2,gold:4,text:`【host:neutral】哪扇门？说慢点，我听着。

【guest:neutral】铜扣我按住了。现在像是……炉房，外门。

【innkeeper:neutral】那扇新门是挡冷风的。我只说别让热气往外跑。

【host:neutral】他也是热气。

【stage】唐婶没接话，拿来了钥匙。

【innkeeper:neutral】怪不得换完门，他就只能让我送饭。

【guest:neutral】他还说了半句。唐婶，您别贴那么近，声音都进您袖子了。

【innkeeper:neutral】说什么？

【guest:smile】“不是要辞工，先让我出去吃一顿。”

【innkeeper:neutral】行。两孔票拿着，钥匙夹进去。到了炉房敲门，我带最后这锅饭下去。这点跑腿钱先收。`},
   {flag:'daily_pot_2_1',bond:2,gold:4,text:`【host:neutral】您困在哪扇门里面？

【guest:neutral】我先给他个信号。

【stage】铜管叫了一长声。

【innkeeper:annoyed】停停停，客人以为热水烧开了，全跑出来了。

【host:neutral】我已经问到炉房外门。你去跟客人说热水没事，我把锅盖扣住。

【guest:neutral】谁喊的“集体出锅”？

【innkeeper:neutral】别找了，肯定是那只甲鱼。他每回来都喊。

【host:neutral】炉房师傅说想出来吃一顿，不想辞工。

【innkeeper:neutral】知道了。钥匙和跑腿钱拿着，下楼敲两下找他。回哨不用了，半条街都听见有人去接他了。`},
   {flag:'daily_pot_2_2',bond:2,gold:4,text:`【host:neutral】我敲两下。跟您的餐票一样，听见就回一下。

【stage】锅盖轻轻跳了两次。

【guest:neutral】他回了两下。

【host:smile】行，习惯不改也行。您要吃什么？

【innkeeper:annoyed】先问他出不出得来！

【guest:neutral】我听到了。外门关着，他想出来吃，不想总趴在管子上。

【innkeeper:neutral】那扇新门是我叫人装的。我以为能替他挡风。

【host:neutral】他现在给整栋楼烧热水呢。

【innkeeper:neutral】……我去拿外套。钥匙和两孔票你们先带下去，锅底那份别倒。跑腿钱在围裙兜里，自己数四枚。`},
   {flag:'daily_pot_2_3',bond:2,gold:4,text:`【host:neutral】敲两下算我们到了，你回一下就行。

【guest:neutral】我也给他回一声。

【stage】锅盖、铜管和楼下同时响了。

【host:neutral】等等，我现在不知道谁在说话了。

【innkeeper:annoyed】都停。一个一个来。

【guest:neutral】我不吹了，你问。

【host:neutral】要出来吃饭？是就两下。

【stage】两声。

【host:neutral】被外门关里面了？

【stage】又两声。

【innkeeper:neutral】行，我听懂了。锅盖带上，到了下面用它找人。钥匙夹在两孔票里，跑腿钱也给你们。下楼安静些，客人刚把衣服穿回去。`}
  ]
 },
 {
  id:'daily_pot_3',kind:'duo',act:3,title:'炉房师傅也要下班',
  purpose:'一个叫人，一个找路，把困在炉房里的师傅接出来吃饭。',
  stage:{background:'bathhouse',cast:['innkeeper']},
  text:`【stage】饭桌摆在炉房门外，凳子空着。

{DAILY:pot_2}

【host:neutral】门开了，人怎么没出来？

【innkeeper:neutral】我开门就喊过他，他没答。别是还以为我催他干活。

【guest:neutral】唐婶，您刚才喊的是“出来，我还等着呢”。

【innkeeper:neutral】那该怎么喊？

【host:neutral】先别喊。我试试餐票。

【stage】铜票敲了两下，锅盖里也响两下。

【guest:neutral】声音在这儿。他没走丢，是被冷风吹回管子了。

【innkeeper:neutral】我把门关上？

【host:neutral】关上我们又得来接一回。

【guest:neutral】您把汤留在桌上。我们挡住风，给他搭条热乎的路。

【innkeeper:neutral】行。鱼别动，是留给你俩的。他吃气就够了。`,
  clues:{host:'两孔餐票还会响，锅盖里能听见两下回应。你可以沿桌边敲票带路，也可以让唐婶坐在饭桌旁正常叫他吃饭。不要再喊“出来干活”。',guest:'炉房门一开，冷风直灌。缺口锅盖能挡住大半风，留下细细的热气通道；也可以把装热汤的大锅挪到门边，让蒸汽一路连到饭桌。'},
  callbacks:{pot_2:{
   daily_pot_2_0:'【innkeeper:neutral】你们上次按着铜扣听得真仔细。我总算知道那扇新门把谁挡住了。',
   daily_pot_2_1:'【innkeeper:annoyed】今天不吹哨。我已经跟甲鱼说过，这回真不是叫他出锅。',
   daily_pot_2_2:'【innkeeper:neutral】四枚跑腿钱数清了吧？你们替我把话问明白了，今天接着麻烦你们。',
   daily_pot_2_3:'【innkeeper:neutral】上回一屋子一起响，我没听见他吃什么。索性全做了。',
   default:'【innkeeper:neutral】你们来得正好。门里那位吃热气，新门装完反倒出不来了。给，叫他就敲这张两孔票。'
  }},
  options:{host:['用两孔餐票敲着桌沿，带他过来','让唐婶坐下，好好叫他吃饭'],guest:['用缺口锅盖挡风，留一条热气口','搬来大汤锅，让蒸汽连到饭桌']},
  results:[
   {flag:'daily_pot_3_0',bond:2,heal:3,text:`【host:neutral】这边，两下。再往这边一点。

【guest:neutral】别催，我还得举着盖。你走快了，他跟不上。

【stage】细细的热气沿锅盖缺口坐上凳子。

【innkeeper:neutral】今晚在外头吃。明天也行。

【host:neutral】他怎么又敲两下？

【innkeeper:neutral】问有没有添的。以前也是这个毛病。

【guest:smile】我现在能把锅盖放下了吗？胳膊快跟他一起冒气了。

【innkeeper:neutral】放。鱼在你碗里，趁热吃。

【host:neutral】那张票还给您？

【innkeeper:smile】留着。以后想吃夜饭就来，别再在门外站到我收摊。`},
   {flag:'daily_pot_3_1',bond:2,heal:3,text:`【host:neutral】票在这儿，跟声音走。我在桌子这头。

【guest:neutral】锅挪不动，过来搭把手。

【host:neutral】那票谁敲？

【innkeeper:annoyed】我敲，你俩抬。别抬一半互相指挥。

【stage】大锅落在门口，热汽接上了饭桌。

【guest:neutral】他坐下了。您还敲？

【innkeeper:neutral】我手停不下来，他刚才就这么等的？

【host:neutral】先给他添饭吧。又敲两下了。

【innkeeper:neutral】好。你们也坐，搬锅那份我给多盛点。

【guest:smile】票不用退？

【innkeeper:smile】不退。以后认这两个孔，夜里来了就有饭。`},
   {flag:'daily_pot_3_2',bond:2,heal:3,text:`【innkeeper:neutral】吃饭了。

【host:neutral】再说一句，不用干活。

【innkeeper:neutral】今晚不添煤了，锅我看着。你出来歇会儿。

【stage】锅盖后探出一小股热气。

【guest:neutral】慢点，这儿有风。顺着缺口走，对。

【innkeeper:neutral】这张凳子给你留着呢。我还以为是你不愿意出来。

【host:neutral】他坐好了。

【guest:smile】轮到我坐了。我举着锅盖快把自己煎熟了。

【innkeeper:neutral】赶紧放下。汤都盛好了。

【host:neutral】餐票还要交吗？

【innkeeper:smile】不用。你俩收着，哪天又来上夜班，进门先吃饭。`},
   {flag:'daily_pot_3_3',bond:2,heal:3,text:`【innkeeper:neutral】出来吃饭，今晚我来添煤。

【guest:neutral】汤锅搬到这儿行吗？

【host:neutral】再往左，我挡着门，别压脚。

【stage】热汽从锅里连到凳子，一团影子落座。

【innkeeper:neutral】就坐这儿。以后想歇就敲两下，我下来换你。

【host:neutral】您以前不知道他在叫您？

【innkeeper:neutral】装门以后才响，我以为管子松了，叫人拧紧过两回。

【guest:neutral】怪不得越敲越小声。

【innkeeper:neutral】明天全松回来。先吃，你们的鱼都在汤底。

【host:smile】这张两孔票我们就留着了。

【innkeeper:smile】留着。夜班饭管够，毛巾还是得自己洗。`}
  ]
 }
];
})(window.GAME_DATA);
