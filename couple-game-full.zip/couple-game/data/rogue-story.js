/* Short scenes for a combat-led run. The long manuscript remains available below. */
(function(G){
'use strict';
if(G.rogueStoryOriginals)return;
G.rogueStoryOriginals=JSON.parse(JSON.stringify({memories:G.memories,bossScenes:G.bossScenes,endings:G.endings,restTexts:G.restTexts}));
const memoryTexts=[
`【stage】第一页从钟摆后面掉下来，订着一张买伞的收据。

【host:neutral】就这破伞？咱俩淋一路，它还断了根骨头。

【guest:neutral】你当时非说能修，拿胶带缠得比我胳膊都粗。

【host:neutral】……也没漏多久。

【guest:neutral】是，后来雨停了。走吧，第二页在镜城。`,
`【stage】第二页背面的胶被撕开，露出退租那晚的记录。

【host:neutral】那天我叫你先走，你还真走了。

【guest:annoyed】不然呢？你堵着门，脸臭得跟我欠你钱似的。

【host:neutral】我以为你会再问一句。

【guest:neutral】我又没长你脑子里。先别吵了，这张退钥匙的条子得去海底查原件。`,
`【stage】最后一页写着两次签名：退钥匙那天，和你们后来重新见面的那天。

【guest:neutral】我拿箱子回去那次，你问了三遍喝不喝水。

【host:neutral】我不知道说什么。

【guest:neutral】那就直说不知道。别拿壶对着空杯子倒半天。

【host:neutral】行。三页齐了，出去以后，这事还得接着聊。`
];
G.memories.forEach((m,i)=>{m.text=memoryTexts[i];});
const bosses=[
 {title:'她还没骂完',text:`【stage】第一页卡在钟摆里。潮声夫人的布条冲你们喊：“你怎么又来了！”

【guest:annoyed】我头一回来。你骂人能不能看一眼？

【host:neutral】别跟布吵，纸在后头。你绕左边，我把她引开。

【guest:neutral】行。你少站两步，她手已经抬起来了。`,choice:'打过去，把纸拿回来',peace:'带上她没唱完的话，再开打'},
 {title:'别拿半句话来堵我',text:`【stage】镜影举着第二页，学着你们的声音说：“没了，你先走。”

【host:annoyed】又这句。你是不是只会这一句？

【guest:neutral】后面还有呢。你把背面翻过来。

【stage】镜影把纸往身后一藏，另一只手已经伸过来抢卷宗。

【host:neutral】好，讲不明白是吧。`,choice:'揍它，拿回第二页',peace:'拿完整记录，让它把后半句念完'},
 {title:'要清空的可不只那点破事',text:`【stage】遗忘之神把托盘推过来：“卷宗放下。忘干净，就不用出去了。”

【guest:neutral】等会儿，买伞那天也算？

【stage】它点头，又指了指你们两个人。

【host:annoyed】合着连对方是谁都忘了。那你刚才不早说？

【guest:neutral】纸压在盘子底下。我挡它，你去拿。`,choice:'把它打退，拿走原件',peace:'想好了，把记忆都交出去'}
];
G.bossScenes.forEach((d,i)=>Object.assign(d,bosses[i]));
G.restTexts=[
 '【host:neutral】你坐这儿，我去看看有什么吃的。\n\n【guest:neutral】别又买那种会跑的。上回追了半条街，回来汤都凉了。',
 '【guest:neutral】胳膊抬一下。\n\n【host:annoyed】嘶，轻点！\n\n【guest:neutral】知道疼你还往前凑？下回先叫我。',
 '【host:neutral】刚才那下，我是不是挺稳？\n\n【guest:neutral】稳。打完趴地上半天都没动。\n\n【host:neutral】我那是看地形。',
 '【guest:neutral】钱你数了没？\n\n【host:neutral】数了。\n\n【guest:neutral】多少？\n\n【host:neutral】你一说话我忘了，重新数。',
 '【host:neutral】这张凳子不咬人吧？\n\n【guest:neutral】你都坐下了才问。\n\n【host:neutral】不问还能多坐会儿。',
 '【guest:neutral】鞋里进东西了。\n\n【host:neutral】石子？\n\n【guest:annoyed】会动的石子。别笑了，帮我拿一下鞋。'
];
const endings={
 return:{text:`【stage】门外还是那间档案室。咖啡洒了一地，椅子少了条腿。

【host:neutral】回来了？

【guest:neutral】嗯。手机还有电，就是快到上班时间了。

【host:annoyed】他大爷的……这一宿算谁的？

【guest:neutral】先回家。别碰桌上任何要签字的东西。

【stage】你们跨过咖啡，带着三页记录出了门。`,epilogue:'本局通关。选过的事、拿到的结局已保存。'},
 apart:{text:`【guest:neutral】出去以后，咱俩还是分开吧。

【host:neutral】嗯。我也想过了。

【stage】门开了。你们站在路口，各自拿回自己的东西。

【host:neutral】你钥匙在我这儿。

【guest:neutral】给我吧。到家发个消息。

【stage】谁也没再劝。一个往左，一个去了车站。`,epilogue:'你们共同选了分开。记录还在，各自往前走。'},
 stay:{text:`【stage】卷宗放进托盘。字一行行退掉，两个人都没再伸手去拿。

【host:neutral】咱们来这儿干什么来着？

【guest:neutral】……不记得了。饿不饿？

【host:neutral】有点。

【stage】你们顺着饭香往城里走。身后的门关上了，谁也没回头。`,epilogue:'你们交出了记忆，留在骨城。'},
 fallen:{text:`【host:annoyed】别拽了，我腿卡着了。

【guest:annoyed】那你把手给我！

【stage】最后一点光灭了。这次没能走出去。

【guest:neutral】下回先把伤养好再往前冲，行不行？`,epilogue:'本局结束。已发现的故事和结局保留，重新开局可换职业与搭配。'},
 masked:{text:`【stage】门开了。外面的登记员问你们叫什么，两个人同时卡住。

【host:neutral】我叫……

【guest:neutral】别看我，我也没想起来。

【stage】卖掉的名字没跟着回来。你们在登记台站了很久，最后各写了一个新名字。`,epilogue:'你们离开了骨城，卖出去的名字却没能带走。'},
 keeper:{text:`【stage】钟楼的门只能从里面守住。一个人留在门边，另一个把行李背上。

【guest:neutral】你真不走了？

【host:neutral】嗯。这边总得留个人。你出去以后，别再乱签东西。

【guest:neutral】知道了。要是能寄信，就给我写。

【stage】一个人跨过门槛。另一个接过钥匙，等脚步声远了，才把门关上。`,epilogue:'一人回到现实，一人留在骨城守门。'},
 newborn:{text:`【stage】皮普攥着你们的衣角，走到门边又不动了。

【pip:neutral】外边也要数人吗？我走慢了，你们会不会忘了我？

【guest:neutral】不会。你就抓着，抓到想松手再松。

【pip:neutral】那我想先吃点东西。

【host:neutral】行。出了门先找吃的，不让你饿着。`,epilogue:'这回走出骨城的，多了一个人。'},
 echo:{text:`【stage】骨城沉入海底，你们的身体也随之消失。钟里还有两个人的声音。

【host:neutral】喂，听得见吗？

【guest:neutral】听见了。你别喊，整个城都听得见。

【stage】四处传来居民报名字的声音。有的很轻，有的急着把一家人都报上。

【host:neutral】一个个来，别一起喊。

【guest:neutral】你帮我记着。我怕漏了谁。`,epilogue:'你们化作回声，保存城中众人的声音，不能再回到现实。'},
 eternal:{text:`【stage】初星落下，所有没开过的门同时开了。桥那头的人试着走出来，没再被送回原地。

【guest:neutral】真能走了？都能？

【host:neutral】门没拦。先走，等它反悔啊？

【stage】有人哭，有人笑，还有人折回去拿锅。你们混在人群里，把那份盖完章的卷宗夹在胳膊底下。

【guest:neutral】锅别拿了！回去买个新的！`,epilogue:'初星已击败。门向所有人打开。'}
};
for(const e of G.endings)if(endings[e.id])Object.assign(e,endings[e.id]);
const interactionTitles={inspect_1:'钟楼的路牌让人掰反了',inspect_2:'这破机器只放半句话',inspect_3:'退过钥匙，还想装没分开',puzzle_1:'你念符号，我来开门',puzzle_2:'三个倒影抢一只袜子',puzzle_3:'少念一行就得重新排队'};
for(const d of G.interludes)if(interactionTitles[d.id])d.title=interactionTitles[d.id];
G.rogueFinale='【stage】门打开了。档案室就在外面，桌上的咖啡罐还横着。\n\n【guest:neutral】这回看清再签。\n\n【host:neutral】看着呢。回去、分开，还是留下……咱俩先说好。';
})(window.GAME_DATA);
