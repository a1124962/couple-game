/* Card descriptions match the implemented rules. */
(function(G){
const classes=[
 ['blade','切骨者','拆开沉默','擅长攻击与叠加力量。先看见对方的破绽，再把机会交给同伴。','旧伤回声','每场战斗首次攻击后，获得 1 层力量。'],
 ['warden','守门人','留一盏灯','擅长给自己和同伴护盾。挡得住风，也记得让对方走进来。','共护之誓','每回合获得 3 护盾；同伴不足半血时改为 6。'],
 ['weaver','织声者','缝回余温','擅长治疗和补充同伴能量。照顾别人的时候，也可以照顾自己。','缝合余温','你的每次治疗额外回复 2 生命。'],
 ['seer','见隙者','说出明天','擅长虚弱、易伤与眩晕。让同伴的下一击，比自己的预言更准。','预言先机','额外看见敌人下一回合的行动。']
];
classes.forEach(([id,name,title,desc,pn,pd])=>Object.assign(G.classes.find(c=>c.id===id),{name,title,desc,passive:{name:pn,desc:pd}}));
G.classes[0].skills[0].name='护身'; G.classes[0].skills[2].name='反挑';G.classes[0].skills[3].name='破默';
G.classes.forEach(c=>c.skills.forEach(s=>{if(s.id==='warden_link')s.effects=s.effects.filter(e=>e.s!=='shield_link');}));
G.bondCards.unshift({id:'b_hand_in_hand',cls:'bond',name:'执手共振',type:'skill',rarity:'rare',bondCost:24,cost:0,effects:[{op:'dmg',v:16,target:'all'},{op:'block',v:6,target:'both'}],flavor:'不用证明什么。一起出手就够了。'});
const targets={self:'自己',ally:'同伴',both:'两人',enemy:'目标',all:'所有敌人',random:'随机敌人'};
const st={str:'力量',weak:'虚弱',vuln:'易伤',stun:'眩晕',burn:'灼烧',poison:'中毒',regen:'再生',thorns:'荆棘',shield_link:'心盾'};
const mods={atk:'攻击',def:'护盾效果',heal:'治疗效果',maxhp:'生命上限',energy:'每回合能量',crit:'暴击率（%）',regen:'每回合恢复',thorns:'反伤',startBlock:'回合初始护盾',goldGain:'胜利星砂'};
G.describeCard=function(c){if(c.mods)return Object.entries(c.mods).map(([k,v])=>(mods[k]||k)+' +'+v).join('；')+'。';return (c.effects||[]).map(e=>{let t=targets[e.target]||'自己';if(e.op==='draw'){e.op='energy';e.target='self';t='自己';}if(e.op==='dmg')return '对'+t+'造成 '+e.v+(e.hits>1?' × '+e.hits:'')+' 伤害';if(e.op==='block')return t+'获得 '+e.v+' 护盾';if(e.op==='heal')return t+'回复 '+e.v+' 生命';if(e.op==='status')return t+'获得 '+e.v+' 层'+(st[e.s]||e.s);if(e.op==='energy')return t+'获得 '+e.v+' 能量';if(e.op==='maxhp')return t+'生命上限 +'+e.v;if(e.op==='gold')return '星砂 +'+e.v;if(e.op==='bond')return '羁绊 +'+e.v;return '';}).filter(Boolean).join('；')+'。';};
[...G.classes.flatMap(c=>c.skills),...G.cards,...G.bondCards].forEach(c=>c.desc=G.describeCard(c));

[...G.classes.flatMap(c=>c.skills),...G.cards,...G.bondCards].forEach(c=>{c.effects=(c.effects||[]).filter(e=>e.s!=='shield_link');c.oncePerTurn=c.cost===0||(c.effects||[]).some(e=>e.op==='energy');c.desc=G.describeCard(c)+(c.oncePerTurn?' 每回合限一次。':'');});
})(window.GAME_DATA);
