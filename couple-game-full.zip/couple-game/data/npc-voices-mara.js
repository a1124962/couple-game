/* Mara's three meetings, rewritten as a working fisher's story.
 * Load after continuity.js and lively-city.js. Only node text and choice labels
 * change; the full pre-overlay character is retained in data/archive/.
 */
(function(G){
'use strict';
const mara=G.npcs.find(n=>n.id==='mara');
const scenes={
  "1": {
    "start": {
      "text": "{CITY:mara}\n\n你们侧身挤过鱼摊，背包勾住筐沿。两条鱼落地，一条钻到凳子底下，另一条被猫按住了。\n\n玛拉用铁钩拦住猫，完好的手还按着秤。她先把找零递给客人，才抬头看你们。\n\n「别动。你再退一步，我的晚饭也要落地。」\n\nTA 扶住摇晃的筐。你想解释谁先碰到谁，玛拉已经指向凳子下面：「解释的那位，先把鱼捡回来。猫没付钱。」\n\n她肘边压着一张钟楼地图。你们原本就是冲它来的。",
      "labels": [
        "先认下碰翻鱼筐的事，把鱼捡回来",
        "示意 TA 解释：刚才是你先退的",
        "谁也不解释，先等她消气"
      ]
    },
    "self_first": {
      "text": "【host:neutral】行，是我们碰的。我捡。\n\n【mara:neutral】脏的放左边！你倒回去，我这一筐还卖不卖了？\n\n【guest:neutral】那剩下这筐呢？\n\n【mara:neutral】分完给你们五枚。别抢着答应，先看看多少。",
      "labels": [
        "帮她分拣整筐鱼，挣 5 星砂",
        "抢着说都归我，先谈怎么收拾",
        "织声者先缝住破筐，再商量分工"
      ]
    },
    "ta_first": {
      "text": "【host:neutral】你说两句啊。\n\n【guest:neutral】背包是你的，眼色倒全使给我了？\n\n【mara:annoyed】别推了。图十枚，收拾摊子十枚，一共二十。\n\n【host:neutral】刚才还十枚！\n\n【mara:neutral】刚才鱼还在筐里呢。",
      "labels": [
        "付 20 星砂，买地图并付清理费",
        "不买了，离开鱼摊",
        "请 TA 说明情况，由你付 20 星砂"
      ]
    },
    "silence": {
      "text": "【guest:neutral】你倒是吱声啊。\n\n【host:neutral】我以为你要说。\n\n【mara:annoyed】行，猫都叼走半条了，你俩继续客气。\n\n【mara:neutral】图十枚，清理十枚。要买就二十，不买把路让开。",
      "labels": [
        "付 20 星砂，买地图并付清理费",
        "不买了，离开鱼摊",
        "由 TA 开口赔不是，你付 20 星砂"
      ]
    },
    "fish_lesson": {
      "text": "【mara:neutral】这条放左边，这条明天卖。别光挑大的，大的不一定有肉。\n\n【guest:neutral】这条怎么软趴趴的？\n\n【mara:neutral】死了。你还指望它帮你站着？\n\n【mara:neutral】五枚工钱在这儿。最后这筐，谁挑谁刮，你俩定。",
      "labels": [
        "让 TA 先挑，我负责刮鳞和拣漏",
        "我都包了，让 TA 歇一会儿",
        "切骨者示范剔骨，让旅伴接着整理"
      ]
    },
    "love_question": {
      "text": "【mara:neutral】分完这两筐，地图给你们。\n\n【host:neutral】我来就行。\n\n【guest:neutral】你手都占满了，拿脚分啊？\n\n【mara:neutral】赶紧分工。今晚吃的放左边，明天卖的放右边，别给我弄反。",
      "labels": [
        "TA 来挑，我收拾剩下的，彼此检查",
        "都交给我，TA 在旁边等着就好",
        "见隙者找出混装的旧鱼，让旅伴另装"
      ]
    },
    "pay_map": {
      "text": "【mara:neutral】二十星砂已经收下，图拿好。三个空瓶那条巷子，左转。\n\n【guest:neutral】就能到钟楼？\n\n【mara:neutral】能到门口。进去以后那歌能把人唱晕。\n\n【host:neutral】怎么防？\n\n【mara:neutral】不赶时间我教你们两下。赶就走，别站门口犹豫。",
      "labels": [
        "谢过她的指路，收好地图离开",
        "留下听防歌声的办法，找残响线索"
      ]
    },
    "walkaway": {
      "text": "【host:neutral】不买了。\n\n【mara:neutral】随便。右边松了！\n\n【guest:neutral】现在肯便宜了？\n\n【mara:annoyed】桥板！脚收回来！钱没省着再摔下去，你俩图什么？",
      "labels": [
        "先过桥，到对面再找路"
      ]
    },
    "love_ta": {
      "text": "【guest:neutral】这条老鱼谁扔进来的？\n\n【host:neutral】别看我，我刚给它挑出去。\n\n【mara:neutral】行了，这回分对了。图和骨片拿着。\n\n【guest:neutral】图上这团是鱼尾印吧？\n\n【mara:neutral】码头。我画的，凑合看。",
      "labels": [
        "收好地图和示范用的骨片，听她指路"
      ]
    },
    "love_self": {
      "text": "【guest:neutral】你说你全包，连个筐都不让我碰。现在呢？\n\n【host:neutral】……帮我拿下布。\n\n【mara:neutral】活干完了，图归你们。先擦手！\n\n【mara:neutral】我就剩这一张了，别给我拿湿袖子裹走。",
      "labels": [
        "擦干手，收下地图"
      ]
    },
    "map_clue": {
      "text": "【mara:neutral】骨片拴手腕上，进钟楼前敲两下。听歌听迷糊了，先找你旁边那个。\n\n【host:neutral】你进去过？\n\n【mara:neutral】找过人。行了，别问这个。\n\n【guest:neutral】袋子里还有鱼干。\n\n【mara:neutral】路上吃。别到了门口饿得腿软。",
      "labels": []
    },
    "map_only": {
      "text": "【mara:neutral】三个瓶子，左转。说一遍。\n\n【host:neutral】三个瓶子，左转。\n\n【guest:neutral】知道了，走吧。\n\n【mara:neutral】哎！鱼干没拿。一个催一个，东西倒都忘我这儿。",
      "labels": []
    },
    "paid_end": {
      "text": "【guest:neutral】还要给钱吗？\n\n【mara:neutral】没有再收一次。二十收过了，我没那么不要脸。\n\n【host:neutral】那下回碰翻摊子能便宜点？\n\n【mara:annoyed】你还想有下回？",
      "labels": []
    },
    "walkaway_end": {
      "text": "【guest:neutral】三条路，你认得哪条？\n\n【host:neutral】刚才图上好像是左边。\n\n【guest:neutral】好像？你就看了一眼。\n\n【host:neutral】那你找人问，我在这儿看包。今天不能再碰翻一摊了。",
      "labels": []
    }
  },
  "2": {
    "start": {
      "text": "{CITY:mara}\n\n玛拉把鱼车停在镜铺门口，轮子用砖顶着，价签还挂在车把上。她说顺路看看，抹布却已经在手里攥干了。\n\n铜镜里有个穿旧裙子的女孩，站在齐腰深的水里，一遍遍抬手整理袖口。\n\n店主问要不要再续一刻钟。玛拉没回头：「你刚才换过一次沙漏，别当我没看见。」\n\n你们走近，她马上把鱼车往里让了让。女孩又抬了一次手。玛拉盯着那截袖口，迟迟没有把车推出去。",
      "labels": [
        "问她：镜子里的女孩是谁？",
        "先替她扶稳鱼车，陪她看一会儿",
        "问有什么能帮忙的"
      ]
    },
    "mirror_daughter": {
      "text": "【mara:neutral】我女儿，小满。那次出海没回来。\n\n【guest:neutral】店里说能让她出来？\n\n【mara:neutral】我知道人没了。我问他能留多久，他就扯什么手艺好。\n\n【mara:annoyed】他大爷的，问个价比审犯人还费劲。你们帮我听听，他到底卖什么。",
      "labels": [
        "把价钱和能留下什么问清楚",
        "先陪她缓一缓，不急着签字",
        "说这倒影至少留住了小满的样子"
      ]
    },
    "silent_watch": {
      "text": "【mara:neutral】右袖子还缺颗扣子。叫她缝，跟我说这样才分得清左右。\n\n【guest:neutral】倒是有办法。\n\n【mara:neutral】有个屁的办法，懒。\n\n【stage:neutral】她又看了一遍倒影，把推走一半的鱼车拉了回来。",
      "labels": [
        "问店主能不能把这段倒影带走",
        "接过鱼干，分给 TA 一半",
        "给她留点空间，先走开"
      ]
    },
    "offer_help": {
      "text": "【mara:neutral】帮我念念最底下这行。我一问，他就咳嗽。\n\n【guest:neutral】只能取一段倒影，不能让死者复生。还要五星砂和咱俩的记忆税。\n\n【host:neutral】这行藏得够深的啊。\n\n【mara:neutral】所以别急着签。想帮忙我知道，别把你俩也赔进去。",
      "labels": [
        "愿意考虑取影，先核对具体手续",
        "劝她别冒这个险，先不买",
        "说起你们卖过名字时吃的亏"
      ]
    },
    "ask_price": {
      "text": "【guest:neutral】取影五星砂，记忆税扣我们两格羁绊。钱交了，人也活不过来。\n\n【host:neutral】就这些？让他写全。\n\n【mara:neutral】对，收据别拿手挡着。\n\n【stage:neutral】店主递来两张单，各写着五星砂。\n\n【mara:annoyed】等等，怎么还多出一张？",
      "labels": [
        "我先登记，请 TA 核对后共同担保",
        "让 TA 先独自登记，我暂时不签",
        "一起核对条款，共签一张单"
      ]
    },
    "comfort_first": {
      "text": "【mara:neutral】别这么看我。我没糊涂，我就想再摸摸她的手。\n\n【guest:neutral】我们知道。就是这钱还好说，记忆税……\n\n【mara:neutral】不愿意就直说。\n\n【mara:neutral】我又不是你们的债主，不用坐这儿憋着。",
      "labels": [
        "我们愿意考虑这个代价，先核价",
        "不愿拿彼此的记忆承担交易",
        "先试着问问镜子里的小满"
      ]
    },
    "say_reflection": {
      "text": "【host:neutral】至少样子还留着。\n\n【mara:neutral】嗯，裤脚都是我接的。店里那小子还跟我说，跟真人一样。\n\n【guest:neutral】真一样，他能让她自己出来走两步啊。\n\n【mara:neutral】就是。我才问了这一句，他就不吱声了。",
      "labels": [
        "接住鱼干，陪她核对取影价钱",
        "接住鱼干，劝她先别买",
        "把鱼干放回她手里，让她留着"
      ]
    },
    "accept_fish": {
      "text": "【guest:neutral】这半给你。\n\n【mara:neutral】小满也这么分。说自己不饿，转头吃我半碗面。\n\n【host:neutral】那咱们还取影吗？\n\n【mara:neutral】先不了。真只能带出来一会儿，我还得再看着她没一次。让我缓缓。",
      "labels": [
        "尊重她的意思，停止这笔交易",
        "再劝她考虑一次取影，最后由她确认",
        "先问问小满，看看倒影能否回答"
      ]
    },
    "leave_alone": {
      "text": "【host:neutral】给她待会儿吧。\n\n【guest:neutral】你看，她把第三张凳子拖出来了。\n\n【host:neutral】刚才还说不用管她。\n\n【guest:neutral】她嘴上哪次说过要人管？走吧，回去坐会儿，或者让她自己待着。",
      "labels": [
        "回去坐一会儿，陪着她",
        "继续离开，不再介入"
      ]
    },
    "buyback": {
      "text": "【mara:neutral】我问清了，只能留一阵，未必认得现在的我。\n\n【guest:neutral】你还想要？\n\n【mara:neutral】想。可是要扣你们五星砂、两格羁绊，这事你们定。\n\n【mara:neutral】笔还没落，反悔来得及。",
      "labels": [
        "确认代价，付 5 星砂、承担 2 羁绊",
        "在签字前停止交易"
      ]
    },
    "ta_first": {
      "text": "【guest:neutral】你让我先签，现在怎么成两张了？\n\n【mara:annoyed】他说分开担保得分开收。刚才他可没提这茬。\n\n【host:neutral】这不坐地起价吗？\n\n【mara:neutral】十枚星砂，还是扣两格羁绊。接受不了就走，别为了我咽这口气。",
      "labels": [
        "付 10 星砂、承担 2 羁绊，完成取影",
        "不接受这笔收费，停止交易"
      ]
    },
    "together_first": {
      "text": "【host:neutral】就这张，我们一起签。多的不要。\n\n【stage:neutral】玛拉抽走第二张单，塞到了鱼筐底下。\n\n【mara:neutral】五星砂，两格羁绊。再往外掏收费单，我可就骂了。\n\n【guest:neutral】还没签。你真想好了？\n\n【mara:neutral】嗯。你们呢？",
      "labels": [
        "共签一张单：5 星砂、2 羁绊",
        "商量后决定不做这笔交易"
      ]
    },
    "refuse_buy": {
      "text": "【mara:neutral】不买了。对，就这样。\n\n【guest:neutral】那走吗？\n\n【mara:neutral】再坐两分钟。鱼车帮我挡一下，别让他又来推销。\n\n【host:neutral】旁边那种三枚的小镜片呢？\n\n【mara:neutral】只能留一张画面……倒也行，我看看。",
      "labels": [
        "把时间留给她，准备离开",
        "留下陪她坐到市场关门",
        "付 3 星砂，买一面能存画面的小镜片"
      ]
    },
    "ask_daughter": {
      "text": "【host:neutral】小满，你想出来吗？\n\n【stage:neutral】镜子答了句“我知道啦”，又把同一句重放了一遍。\n\n【mara:annoyed】少糊弄人！那是我当年催她穿外套，她回我的。\n\n【mara:neutral】它回答不了今天的事。买的是旧影子，别替我闺女答应什么。",
      "labels": [
        "不把旧话当同意，只考虑取走这段影像",
        "无法确认她的意思，先不买",
        "先替玛拉拿主意：取影手续继续"
      ]
    },
    "return_fish": {
      "text": "【mara:neutral】小满，这回没多放盐。鞋也买了，红的，在床底下。\n\n【stage:neutral】镜子里，女孩又开始卷同一边袖口。\n\n【mara:neutral】行了，跟你说这些也听不见。\n\n【mara:neutral】走吧。再耗一会儿，车上那堆鱼该臭了。",
      "labels": [
        "陪她推着鱼车离开",
        "让她先走，你们再看看市场"
      ]
    },
    "name_sold_understand": {
      "text": "【host:neutral】我们卖过名字。后来想拿回来，人家根本不搭理。\n\n【mara:neutral】怪不得你们盯着小字看。\n\n【guest:neutral】怕再吃一次亏。\n\n【mara:neutral】那更别急。你们肯陪我站这儿，我已经领情了。",
      "labels": [
        "仍考虑取影，但先看清最终代价",
        "不再买，陪玛拉缓一缓",
        "先把鱼干留给她，让她对小满说几句"
      ]
    },
    "buy_result": {
      "text": "【stage:neutral】倒影走出镜柜。你慢了半拍，才认出旅伴伸来的是哪只手。\n\n【guest:neutral】这税……真给扣了啊。\n\n【mara:neutral】小满？手给妈，慢点。\n\n【stage:neutral】玛拉知道这不是女儿复生。店主刚要催时间，她便瞪了回去。\n\n【mara:annoyed】钱都收了，让我好好牵她走两步行不行？",
      "labels": [
        "送她们走到安全出口，记下玛拉的归路",
        "追上玛拉，再陪她说几句"
      ]
    },
    "refuse_result": {
      "text": "【mara:neutral】不取了。收据收回去，别再劝。\n\n【guest:neutral】车我帮你推？\n\n【mara:neutral】我推得动。明早还有一摊子事呢。\n\n【stage:neutral】她握住车把，没能立刻迈步。口袋里的鱼干掉了一块。",
      "labels": [
        "拾起纸包，追上去陪她一段",
        "没有跟上，让她自己离开"
      ]
    },
    "stay_night": {
      "text": "【mara:neutral】几点了？你们怎么不叫我？\n\n【guest:neutral】你才睡着。\n\n【mara:neutral】我睡了，你俩跟着坐一宿？明天不赶路啊。\n\n【host:neutral】先出去吃点热的吧。\n\n【mara:neutral】嗯。今天不取影了。",
      "labels": [
        "帮她推车，一起离开",
        "让她先回去，你们再逛一会儿"
      ]
    },
    "cheap_mirror": {
      "text": "【mara:neutral】三枚，就留这张。她嫌我啰嗦的时候就这表情。\n\n【guest:neutral】包好了，走吧。\n\n【stage:neutral】她推了两次车，轮子纹丝不动。\n\n【host:neutral】砖还没拿。\n\n【mara:neutral】……我知道。刚想拿呢。",
      "labels": [
        "拿开车轮下的砖，陪她离开",
        "让她先走，你们继续逛市场"
      ]
    },
    "follow_mara": {
      "text": "【mara:neutral】今天占了你们这么久，怪不好意思的。\n\n【guest:neutral】你这绳头太短了。给我，我接一截。\n\n【mara:neutral】过两天我下海床修船。到了先喊我，船边有个坏踏板。\n\n【host:neutral】记住了。你别一看见我们又塞一袋鱼。\n\n【mara:neutral】看我乐意。",
      "labels": [
        "记下旧船的位置，答应到了去看看她",
        "向她告别，继续自己的路"
      ]
    },
    "leave_together": {
      "text": "【mara:neutral】汤咸不咸？\n\n【guest:neutral】正好。\n\n【mara:neutral】那就不加盐了。你俩以后下海床，来旧船喊我。\n\n【host:neutral】有事？\n\n【mara:neutral】没事就不能来？顺便帮我看看罗盘，那东西还认回去的路。",
      "labels": [
        "约好到海床时去旧船找她",
        "点点头，送她到路口"
      ]
    },
    "mara_survive_end": {
      "text": "【guest:neutral】往这边，别跟着镜光走，前面全是水。\n\n【mara:neutral】看见了。小满，抬脚。\n\n【stage:neutral】她牵着那段倒影，走过了市场最后一盏灯。\n\n【host:neutral】到正路了。咱们也走吧。",
      "labels": [
        "确认她走上归路，再离开市场"
      ]
    },
    "leave_end": {
      "text": "【guest:neutral】就这么走了？\n\n【host:neutral】她说想一个人待会儿。\n\n【stage:neutral】路口有人伸手戳鱼，玛拉一铁钩挡了回去。\n\n【mara:annoyed】问价就问价！再戳，烂的这条归你！",
      "labels": [
        "继续旅程"
      ]
    },
    "market_end": {
      "text": "【guest:neutral】那边写买一送三，要不要看看？\n\n【host:neutral】你翻后面。\n\n【guest:neutral】……三张欠条。真行。\n\n【host:neutral】走了，这条街我是一分钟也不想逛了。",
      "labels": [
        "离开镜面市场"
      ]
    },
    "end_remember": {
      "text": "【host:neutral】旧船，左边那片。记好了。\n\n【guest:neutral】你画的这是什么，锅？\n\n【host:neutral】船。底下不是写了吗。\n\n【guest:neutral】行，到地方我问谁见过玛拉那口锅。",
      "labels": []
    },
    "end_continue": {
      "text": "【guest:neutral】总算出来了。还有钱没？\n\n【host:neutral】先别数，离这条街远点。\n\n【guest:neutral】也是。站着喘口气，没准都得补张单。",
      "labels": []
    },
    "end_promise": {
      "text": "【mara:neutral】我船在哪儿？说一遍。\n\n【host:neutral】海床左边，挂灯那艘。\n\n【mara:neutral】行。找不着就喊，别闷头乱游。\n\n【guest:neutral】知道了，你也早点回。",
      "labels": []
    },
    "end_nod": {
      "text": "【guest:neutral】够了，真装不下了。\n\n【mara:neutral】压一压就装下了，都是卖剩的。\n\n【host:neutral】你刚才还在挑好的。\n\n【mara:neutral】那你要烂的？拿着走。",
      "labels": []
    }
  },
  "3": {
    "start": {
      "text": "{CITY:mara}\n\n船舷外挂着一盏潮汐灯，撑住一小块能呼吸的地方。玛拉跪在里面补板，一锤下去，钉子弯了。\n\n「卖钉子的还说是新货。新弯的吧。」\n\n她看见你们，先指安全的踏板，再把散落的工具往里踢。船首滚着五枚星砂，旧船舱门也敞着，桌上的纸被鱼罐压住一角。\n\n「想看就看，别踩左边。那块板现在只负责看起来像板。」\n\n她催你们先找个稳当地方落脚，自己又拔出一枚弯钉。你们可以搭把手，也可以看看她留在旧船上的东西。",
      "labels": [
        "先喊她一声，沿安全踏板过去帮忙",
        "没先商量就钻进旧船舱查看",
        "去船首看出海记录，拾起散落的 5 星砂"
      ]
    },
    "alive_call": {
      "text": "【mara:neutral】听见了！先进灯底下，别在外头扯着嗓子喊。\n\n【guest:neutral】这接头漏气。\n\n【mara:neutral】拿布缠住。对，舱门上那个“小满”是她自己刻的。\n\n【mara:neutral】每年量个子，都得踮一下脚。以为我瞎。",
      "labels": [
        "接好通气管，让 TA 先恢复呼吸（旅伴回复 8）",
        "指着刻字问：是小满自己写的吗？",
        "提起她对小满一直没能说完的那句话"
      ]
    },
    "alive_memory": {
      "text": "【mara:neutral】这门板我得拆走，上面有她的名字。\n\n【host:neutral】整块？\n\n【mara:neutral】船拖不走，带这块总行吧。\n\n【guest:neutral】行，你拔钉子，我托着。\n\n【mara:neutral】留神手，卖钉子那混蛋掺了好几根弯的。",
      "labels": [
        "记下小满的名字，和玛拉约定撤离路线",
        "托住木板，陪她慢慢拆下来",
        "催她收拾快点，别再翻这些旧事了"
      ]
    },
    "alive_compass": {
      "text": "【mara:neutral】铜罗盘认回去的水道，十枚星砂是工钱。\n\n【stage:neutral】船尾突然陷下去一截。\n\n【guest:neutral】靠，先出去！\n\n【mara:neutral】你俩上踏台！收不收东西快点定，我还得把这块板拖出去。",
      "labels": [
        "收好罗盘与 10 星砂，记牢她的归路",
        "把罗盘递回她手上，帮她一起撤离",
        "临走仍追问：还有什么话想对小满说？"
      ]
    },
    "alive_end": {
      "text": "【stage:neutral】船尾塌下去时，玛拉已经踩上踏台，手里还拽着门板。\n\n【guest:neutral】人没事吧？\n\n【mara:neutral】没事。钉子倒全沉了，那袋本来就没几个好的。\n\n【mara:neutral】你们去吧。我喘匀了就回，别围着我看。",
      "labels": [
        "确认玛拉已到安全踏台，继续深入海床"
      ]
    },
    "dead_cabin": {
      "text": "【stage:neutral】玛拉从窗缝伸进铁钩，接住了快翻倒的鱼罐。\n\n【mara:annoyed】别吃！去年的！翻东西先喊我一声。\n\n【guest:neutral】桌上这张……能看吗？\n\n【mara:neutral】写给小满的，没写完。旁边七道刻痕，也是那时候划的。",
      "labels": [
        "读那张写了一半、留给小满的纸",
        "问玛拉那七道刻痕是怎么留下的",
        "扶正旧鱼罐，连同纸一起整理好再看"
      ]
    },
    "dead_letter": {
      "text": "【guest:neutral】“小满，鞋在床底。不是不给买，想等你回来试。”\n\n【mara:neutral】后头别念了，我听着难受。\n\n【host:neutral】我们抄一份？\n\n【mara:neutral】抄吧。上面的鱼钱别抄走，隔壁真欠着，还没给。",
      "labels": [
        "征得她同意，抄下这张旧信",
        "不抄了，把原件收回去",
        "用潮汐石压住卷起的纸角"
      ]
    },
    "dead_name": {
      "text": "【mara:neutral】她没回来，我一天划一道。划到第七天，不想划了。\n\n【guest:neutral】名字写得真大。\n\n【mara:neutral】哪儿都写。轮到签收鱼货，又说字多，给我画个圈。\n\n【mara:neutral】我那会儿还骂过她。这个“满”别擦，留着。",
      "labels": [
        "把小满的名字和那条胖鱼记进共同笔记",
        "不另作记录，把这些刻字留在原处",
        "帮她收好旧信和鱼罐，免得再弄湿"
      ]
    },
    "dead_end": {
      "text": "【stage:neutral】玛拉已经补住了漏风的缝，给你们抛来一包鱼干。\n\n【mara:neutral】这包新的，能吃。不是罐里那包！\n\n【guest:neutral】知道了，你别修太晚。\n\n【mara:neutral】最后两根钉子。完事我就走。",
      "labels": [
        "向仍在修船的玛拉道别，继续前行"
      ]
    },
    "hull_carving": {
      "text": "【guest:neutral】这画的是鸡？\n\n【mara:neutral】鱼。我画的，有意见也憋着。\n\n【host:neutral】板缝还有三枚钱。\n\n【mara:neutral】能拿就拿。木刺朝外翘着，别上手硬按，两只手都能给你扎透。",
      "labels": [
        "拓下刻字，捡出板缝里的 3 星砂",
        "徒手帮她固定木板，承受划伤（双方失去 5 生命）",
        "不碰木板，两个人一起辨认刻字"
      ]
    },
    "hull_vow": {
      "text": "【guest:neutral】骨石说能替你记住小满，要拿我们的名字换。\n\n【mara:annoyed】别犯傻。她的名字在这儿，我认得，用得着你俩卖名字？\n\n【host:neutral】我们笔记里也能写。\n\n【mara:neutral】那就写。别信它扯什么永久保管，交出去了真拿不回。",
      "labels": [
        "念出小满的名字，让玛拉听清",
        "用自己的名字作保，把小满刻进骨石（卖出名字）",
        "把小满的名字写进共同笔记"
      ]
    },
    "hull_end": {
      "text": "【stage:neutral】玛拉继续处理船首木板，给你们让出了一条路。\n\n【mara:neutral】钟楼收费员要乱开价，留着收据，回来给我看。\n\n【host:neutral】你还管这事？\n\n【mara:neutral】我就住这儿，谁还没跟他吵过两回。去吧。",
      "labels": [
        "和玛拉约好再见，走向骨城底层"
      ]
    }
  }
};
for(const meeting of mara.meetings){
 const replacements=scenes[meeting.act];
 for(const [id,replacement] of Object.entries(replacements)){
  const node=meeting.nodes[id];
  if(!node||node.choices.length!==replacement.labels.length)throw new Error('Mara voice branch mismatch: '+meeting.act+':'+id);
  node.text=replacement.text;
  node.choices.forEach((choice,i)=>{choice.label=replacement.labels[i];});
 }
}
})(window.GAME_DATA);
