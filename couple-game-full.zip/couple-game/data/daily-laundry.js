/* Original night-bathhouse daily scenes. Dialogue is authored as speech turns;
 * the runtime resolves only callbacks backed by the current run's flags. */
(function(G){
'use strict';
const scenes=[
{
 id:'daily_laundry_1',kind:'duo',act:1,title:'围裙比人先下班',
 purpose:'一个拦门，一个处理围裙。各选一种办法，别把整屋衣服都放跑。',
 stage:{background:'laundry',cast:['laundress']},
 text:`【stage】一条旧围裙从洗衣筐里爬出来。

【host:neutral】你们这里洗完还负责送到家？

【laundress:neutral】负责。一般不让衣服自己送。

【guest:neutral】它是不是要去上班？系带都拖到地上了。

【laundress:annoyed】它刚从烘衣间出来，已经干了一夜。

【host:smile】那是下班。拦人下班不太好吧。

【laundress:neutral】门外有台阶。昨天一件浴袍滚下去，连喊三层楼。

【guest:neutral】浴袍会喊？

【laundress:neutral】里面的客人会。

【stage】围裙搭住门闩，缓缓往下拉。

【host:neutral】等一下，我们送。别再叫别的衣服了。

【laundress:neutral】你守门。你看看它的系带，别一把扯断。

【guest:smile】这么熟练，你以前是不是经常追？

【laundress:annoyed】先追回来，再讨论我的工龄。

【host:neutral】我们是来换床位的，洗衣服也归我们？

【laundress:neutral】帮这一下，我给你们留干床单。别站门口还价了。`,
 clues:{
  host:'你在门边。围裙一直往楼梯方向挪，并不理会烘衣间的铃。门外停着一辆空洗衣车，可以用来跟着它；正面拦住它时，它会停下来等，但很快又要走。',
  guest:'你在洗衣筐旁。围裙右边系带开了线，里面露出一小块硬布牌。缝好系带不会困住它。旁边一双厚袜子总往温暖处爬，拿它们引围裙，也可能把袜子一起放跑。'
 },
 options:{host:['守住门，请它等人送','推上洗衣车，跟它走一趟'],guest:['先把开线的系带缝好','拿厚袜子引它回筐里']},
 results:[
  {flag:'daily_laundry_1_0',bond:2,text:`【host:neutral】门先不开。你的带子快掉了。

【guest:neutral】别往前挪，针还在里面。

【laundress:neutral】针脚收小一点，它走路会蹭。

【stage】围裙停住。硬布牌从破口滑出来。

【guest:neutral】七号。这个是不是领衣牌？

【laundress:neutral】旧式的。先收着，我下班查一下。

【host:smile】它下班有车接，你下班还查牌？

【laundress:annoyed】所以你俩把车推来。

【guest:neutral】缝好了。蓝线，认得出来。

【stage】围裙爬进车里，自己垫好车角。

【host:neutral】看，它明明会等。

【laundress:neutral】你们先把它送到楼梯边。七号牌别塞回去，破口刚补好。

【host:neutral】右边的楼梯？

【laundress:neutral】对，别顺着铃声走。那是叫人干活的。`},
  {flag:'daily_laundry_1_1',bond:2,text:`【guest:smile】这里有袜子，厚的。回来看看？

【host:neutral】你像在叫一条狗。

【stage】围裙卷住袜子，继续拉门闩。

【guest:neutral】现在还多带了两件行李。

【laundress:annoyed】袜子不能出门，客人只穿了一只鞋来领。

【host:neutral】这样，你留下袜子，我们推车送你。

【stage】围裙放下一只，腰带里掉出七号布牌。

【guest:neutral】另一只呢？

【laundress:neutral】在你袖子里。它觉得那儿暖和。

【host:smile】行，送一位，追回两位。

【guest:neutral】七号牌也收好了。别让它算成车费。

【laundress:neutral】把袜子放到炉边那张凳子上。围裙我给它盖块布，今天不再往烘衣间送。

【guest:neutral】腰带松一下，你把车轮也裹住了。`},
  {flag:'daily_laundry_1_2',bond:2,text:`【host:neutral】上车。你指路，我推。

【guest:neutral】慢点，我还牵着针。

【laundress:annoyed】停车缝！这不是一项需要配合速度的工作。

【stage】车轮卡住地缝，围裙替你们拉了一把。

【host:neutral】谢谢。你先休息，我能推。

【guest:neutral】右边补好了，用的蓝线。这里掉出一块牌。

【laundress:neutral】七号？给我看看背面。

【guest:neutral】浆糊糊住了，先别抠，我拿去泡开。

【host:smile】它已经把车角铺好了，像有预订。

【laundress:neutral】我去拿条干布。你们把车停到楼梯边，别停烘衣间门口。

【guest:neutral】布牌我保管。你推车的时候别再替它报名干活。

【host:neutral】知道。铃响了也不停，先把它送到。`},
  {flag:'daily_laundry_1_3',bond:2,text:`【guest:smile】袜子走了，围裙会不会跟？

【host:neutral】会。后面那件裤子也跟了。

【stage】三件衣服绕着洗衣车排成一队。

【laundress:annoyed】裤子回来！你的客人还在隔间里！

【guest:neutral】我把袜子放炉边，你把车横过来。

【host:neutral】哪边是车头？

【laundress:neutral】有我的手的这边。别压。

【stage】袜子停在炉边，围裙爬进空车。

【guest:neutral】抓到一块七号布牌。围裙口袋里掉的。

【laundress:neutral】留着，我查查。裤子先送回去。

【host:smile】刚才他看见了吗？

【laundress:neutral】看见了。他说下次自己来，裤子不认识路。

【guest:neutral】听着挺合理。我们先把这位送到楼梯边。

【host:neutral】袜子别跟了，今天没有第二趟车。`}
 ]
},
{
 id:'daily_laundry_2',kind:'duo',act:2,title:'七号柜里有人打呼',
 purpose:'一个同柜里打交道，一个处理毛巾。先弄清里面住的是谁。',
 stage:{background:'laundry',cast:['laundress']},
 text:`【stage】七号柜的门缝里，伸出半条毛巾。

【laundress:annoyed】谁拿了六条浴巾，只还回来五条？

【host:neutral】这句话要朝客人喊，还是朝柜子喊？

【laundress:neutral】先朝柜子。它今天早上打了两次呼。

【host:neutral】你们连柜子也住客人？

【laundress:neutral】没允许。唐婶倒是想收床位钱，被我拦住了。

{DAILY:laundry_1}

【guest:neutral】门上不是写着放失物吗？

【laundress:neutral】之前写的是别住人。客人嫌不吉利，我改的。

【stage】柜里叮的一声，一只衣架递出来。

【host:smile】它是不是给房租？

【laundress:neutral】这是我丢的衣架。

【guest:neutral】里面很暖。拿走毛巾以后，它睡什么？

【laundress:neutral】先问清楚。楼上有员工床，又不是非得挤在柜子里。

【host:neutral】那我敲门。它要是请我进去，你记得拽住我。`,
 clues:{
  host:'柜门没有锁。普通敲门声会得到两下轻敲的回答，提到“房租”时，里面便会找东西往外递。你可以按领衣流程请它开门，也可以顺着房客的意思谈床位。',
  guest:'最上层毛巾已经被叠成了枕头。柜里只剩一团暖气和那条旧围裙，没人影。阿绫给了你一块刚热好的小手巾：可以先还回浴巾，也可以拿热手巾交换，别把热水倒进柜子。'
 },
 options:{host:['敲三下，请它出来领衣服','拿登记本，问它住了几晚'],guest:['抱回客人的大浴巾','用热手巾换出大浴巾']},
 callbacks:{laundry_1:{
  daily_laundry_1_0:'【guest:neutral】围裙的蓝线露在门边。我们缝的那条，七号牌也还在。',
  daily_laundry_1_1:'【guest:neutral】那条借袜子坐车的围裙。七号布牌还在我这里，袜子已经还了。',
  daily_laundry_1_2:'【guest:neutral】我们推车送过它。七号牌泡开了一半，背面还有字。',
  daily_laundry_1_3:'【guest:neutral】上次领着裤子排队的围裙。七号牌还在，今天别再领一车走。',
  default:'【guest:neutral】门缝挂着条旧围裙，腰带上缝着七号。它是这里的员工吗？'
 }},
 results:[
  {flag:'daily_laundry_2_0',bond:2,text:`【host:neutral】七号，领衣服。麻烦带上自己的东西。

【guest:neutral】浴巾我收了……怎么还在我手里打呼？

【laundress:neutral】把卷边抖开。轻一点。

【stage】一团暖气挤进围裙，系带打了个结。

【host:neutral】哦。它不是裹得严，是根本没有头。

【guest:neutral】我刚拿走它的床了。

【laundress:neutral】柜子本来就不是床。楼上的七号床一直空着。

【host:neutral】你怎么知道它睡七号？

【laundress:neutral】看那种旧布牌，反面写着床位，正面才是领衣号。

【guest:smile】一块牌还得干两份活。

【laundress:neutral】你把牌放登记本里。等这轮衣服烘完，我带它上楼，先别叫它加班。

【host:neutral】我先把柜门敞着，免得它又往回钻。`},
  {flag:'daily_laundry_2_1',bond:2,text:`【host:neutral】七号，开门领衣服。

【guest:neutral】枕头给你换块暖的。大的那条是客人的。

【stage】毛巾松开，一团热气卷住小手巾。

【host:neutral】这就是烘衣间那个？

【laundress:neutral】嗯。锅炉烧出来的热气，套上围裙才不会到处漏。

【guest:smile】它的裤子呢？

【laundress:neutral】热气不用穿裤子。你别给它添活。

【host:neutral】七号牌背面是床位吧？

【laundress:neutral】七号床。门牌被浴袍遮住了，它没找到，就住柜子里。

【guest:neutral】我去把浴袍挪开。

【laundress:neutral】先等我换班。你们把这页床位登记留着，别再往七号柜塞失物了。

【guest:neutral】那我把布牌挂在衣架上，送它上楼时一起带走。`},
  {flag:'daily_laundry_2_2',bond:2,text:`【host:neutral】查房。住几晚了？

【stage】柜里递出一只衣架，又递出半个衣夹。

【guest:neutral】别交了。他拿的是洗衣登记本。

【host:neutral】我没说收钱。我是想问需不需要换床。

【laundress:annoyed】那你开头就说换床。

【guest:neutral】浴巾收回来了。里面这条围裙还抱着一角。

【laundress:neutral】它夜里烘衣服，白天睡觉。不是来偷东西的。

【laundress:neutral】旧布牌反面写着七号床。那张床明明空着。

【host:neutral】那它怎么睡进柜里？

【laundress:neutral】门牌被挂衣服挡了。它找到了同样写七号的柜子。

【guest:neutral】我把登记这一页折个角。下次送它上楼。

【host:neutral】衣架还你。半个衣夹……

【laundress:neutral】也还我。另半个我找两天了。

【host:neutral】我们下次过来帮你搬床单。`},
  {flag:'daily_laundry_2_3',bond:2,text:`【host:smile】客人，查一下床位。这里住得习惯吗？

【guest:neutral】你别真拿腔。手巾给它，我要换回浴巾。

【stage】柜门开了。围裙把热手巾铺在衣架上。

【host:neutral】它请我坐。

【laundress:neutral】那是给自己垫的。你坐下衣架就断了。

【guest:neutral】床位七号……柜号也七号。它认错门了？

【laundress:neutral】楼上门牌被挡着。怪我晾衣服的时候没看。

【host:neutral】那就带它上楼，房租免了。

【laundress:annoyed】员工床本来就不收钱。

【guest:smile】登记本给我。这个“已收房租”是谁先画的勾？

【host:neutral】还没画实，擦得掉。

【laundress:neutral】留这一页，换班后我们去认门。热手巾先给它盖着。`}
 ]
},
{
 id:'daily_laundry_3',kind:'duo',act:3,title:'七号床不收加班的',
 purpose:'一个安顿床铺，一个接住洗衣房的铃。让烘衣工真正休息一回。',
 stage:{background:'bathhouse',cast:['laundress']},
 text:`【stage】员工房门口，围裙紧紧裹着一只枕头。

【laundress:neutral】七号床。木板结实，不用睡柜子。

{DAILY:laundry_2}

【host:neutral】它怎么还不进去？

【guest:neutral】枕头都抱歪了。是不是要有人先试？

【laundress:neutral】它在听铃。洗衣间每来一筐，铃就响一回。

【stage】楼下铃响。围裙立刻转身。

【host:annoyed】等会儿！床位都找到了，你又跑什么？

【laundress:neutral】我去接班。你俩帮它铺床，别把热气扯散。

【guest:neutral】接下来有人送衣服呢？

【host:neutral】我们还有多少要洗？别让它躺一半又被叫下去。

【laundress:neutral】收着，写明早取。锅炉也得停下来擦。

【host:smile】我能写牌子。保证字比那个门牌大。

【laundress:neutral】写准时开门。不要写最后一天，唐婶会追上来的。`,
 clues:{
  host:'你负责七号床。烘衣工没睡过真正的床，反复摸床沿。可以直接铺好让它试，也可以给它画一张从洗衣房到床边的路线；别改它床位，腰带上就是七号。',
  guest:'你负责楼下的铃。阿绫已接班，衣服可以明早取。拆下铃舌就不会响，但客人可能继续摇；把铃挪到你值守的柜台，能当面说明取衣时间。两种办法都不收费，也不用另买工具。'
 },
 options:{host:['铺好床，陪它试着躺下','画条路线，把门牌挂低一点'],guest:['收起铃舌，挂明早取衣的牌','把铃搬到柜台，由我们应门']},
 callbacks:{laundry_2:{
  daily_laundry_2_0:'【guest:neutral】这次没拿你的枕头。上回收浴巾收太快，对不住。',
  daily_laundry_2_1:'【guest:neutral】门口的浴袍挪走了，热手巾也给你带上来了。',
  daily_laundry_2_2:'【host:neutral】不查房，也不收衣夹。我们按登记本送你来睡觉。',
  daily_laundry_2_3:'【guest:neutral】“已收房租”那个勾擦掉了。员工床，真的不收钱。',
  default:'【laundress:neutral】它以前认错门，在七号柜里睡。今天我翻出旧床位登记，总算给它领对了。'
 }},
 results:[
  {flag:'daily_laundry_3_0',bond:2,heal:3,text:`【host:neutral】脚往这边。你没有脚的话，带子往这边。

【guest:neutral】铃舌收起来了。现在只剩客人在门外摇空壳。

【laundress:neutral】我去说。牌子写了明早，总得有人给他指一下。

【stage】枕头慢慢凹下去，床边冒出细细的暖气。

【host:neutral】漏气正常吗？

【laundress:neutral】正常。别给它打结，睡着得松一点。

【guest:smile】七号牌挂好了，总算不用到处认柜子。

【host:neutral】那我们呢？忙完可以躺一下吗？

【laundress:neutral】旁边两张空床。鞋脱了，别把码头的泥带上去。

【stage】两杯热水放在床头。

【guest:neutral】有人摇铃再叫我们。

【laundress:neutral】我还在柜台。你们先歇。`},
  {flag:'daily_laundry_3_1',bond:2,heal:3,text:`【host:neutral】躺下试试。我不走，等你睡着。

【guest:neutral】铃移到柜台了。我说一句明早取，他摇一下。

【host:smile】是在答应，还是没听懂？

【guest:neutral】是个没有嘴的客人。我刚才才看见。

【laundress:neutral】拿张纸给他。客人怎么称呼？

【guest:neutral】写了。三条横线，要把最后一条写长。

【stage】围裙从床边探出一角，又慢慢缩回去。

【host:neutral】收好了，名字也记好了。你睡。

【laundress:neutral】七号那张旧牌留在床头。明天醒来还能认得。

【guest:neutral】我们能在旁边坐会儿吗？

【laundress:neutral】坐什么，旁边就是空床。热水给你们放这儿。

【host:neutral】等我把这张床边的湿鞋挪远一点。`},
  {flag:'daily_laundry_3_2',bond:2,heal:3,text:`【host:neutral】过门，向右，第二张床。图画明白了吗？

【guest:neutral】你画了一条鱼。

【host:neutral】那是床。

【laundress:neutral】我来画。你把门牌挂低一点，它不用把自己撑那么高。

【stage】围裙沿着图上的线，挪到七号床边。

【guest:neutral】铃舌已经收了。这回真安静。

【host:smile】它还把图压在枕头下面。

【laundress:neutral】你画那条鱼也留下吧，别撕一半。

【guest:neutral】以后看到鱼就知道快到家了。

【host:neutral】就你记得那是鱼。

【laundress:neutral】都别聊了，刚躺下又要起来看。旁边空床给你们，热水自己倒。被子不用还到柜里。

【guest:neutral】明早谁先醒，叫一下另一个。我们还得把床单抱下去。`},
  {flag:'daily_laundry_3_3',bond:2,heal:3,text:`【host:neutral】七号，门牌挂这儿。看不见就顺着这条蓝线走。

【guest:neutral】你把自己的袖子也缝到床单上了。

【host:annoyed】先别拉。阿绫，剪刀。

【stage】阿绫剪开线头，围裙抖了两下。

【laundress:smile】它在笑你。别解释，它没有耳朵也看得见。

【guest:neutral】楼下交给我。今晚收衣服，明早拿，不收加急。

【host:neutral】谁教你最后一句的？

【guest:smile】门口已经排了两个抱湿被子的。

【laundress:neutral】我去接。你们忙够了，旁边两张床是空的。

【stage】七号床的枕头轻轻陷下去。

【host:neutral】总算睡了。那块牌没丢吧？

【guest:neutral】床头。七号，字朝外。你也睡。`}
 ]
}
];
G.dailyScenePacks=G.dailyScenePacks||{};
G.dailyScenePacks.laundry=scenes;
})(window.GAME_DATA);
