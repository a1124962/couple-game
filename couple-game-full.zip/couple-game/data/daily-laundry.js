/* Bathhouse laundry: short spoken scenes; original pack is archived. */
(function(G){
'use strict';
G.dailyScenePacks=G.dailyScenePacks||{};
G.dailyScenePacks.laundry=[
  {
    "id": "daily_laundry_1",
    "kind": "duo",
    "act": 1,
    "title": "围裙比人先下班",
    "purpose": "一个拦门，一个处理围裙。各选一种办法，别把整屋衣服都放跑。",
    "stage": {
      "background": "laundry",
      "cast": [
        "laundress"
      ]
    },
    "text": "【stage】围裙翻出洗衣筐，拖着开线的系带去够门闩。\n\n【host:neutral】成精了？还知道自己下班。\n\n【laundress:annoyed】让开！门外全是台阶，摔下去我还得一层层捡！\n\n【guest:neutral】那你让它歇会儿，带子都快跑断了。\n\n【laundress:annoyed】我喊它搭车，它听成加班了。把车推来，别傻站着。\n\n【host:neutral】我们不是来领干床单的吗？\n\n【laundress:neutral】帮我拦住，床单给你留双份。",
    "clues": {
      "host": "你在门边。围裙一直往楼梯方向挪，并不理会烘衣间的铃。门外停着一辆空洗衣车，可以用来跟着它；正面拦住它时，它会停下来等，但很快又要走。",
      "guest": "你在洗衣筐旁。围裙右边系带开了线，里面露出一小块硬布牌。缝好系带不会困住它。旁边一双厚袜子总往温暖处爬，拿它们引围裙，也可能把袜子一起放跑。"
    },
    "options": {
      "host": [
        "守住门，请它等人送",
        "推上洗衣车，跟它走一趟"
      ],
      "guest": [
        "先把开线的系带缝好",
        "拿厚袜子引它回筐里"
      ]
    },
    "results": [
      {
        "flag": "daily_laundry_1_0",
        "bond": 2,
        "text": "【host:neutral】门先不开，针还扎你身上呢！\n\n【guest:neutral】好了好了，蓝线补的。咦，掉了块七号牌。\n\n【laundress:neutral】旧式的，留着我查。车推过来，别让它再自己爬楼。\n\n【stage】围裙爬上车，缩进干布里。\n\n【host:neutral】看，这不挺乖的吗。\n\n【laundress:neutral】你再说一句，它要你抱着上楼了。"
      },
      {
        "flag": "daily_laundry_1_1",
        "bond": 2,
        "text": "【guest:neutral】嘿，厚袜子，要不要？回来我就给你。\n\n【host:neutral】你逗狗呢？哎，它真拿走了！\n\n【laundress:annoyed】袜子给我！客人还光着脚在那儿等！\n\n【stage】围裙放下一只袜子，另一只钻进袖口。七号布牌也掉了出来。\n\n【guest:neutral】靠，跑我袖子里了。袜子、布牌，都在。\n\n【host:neutral】那我推它去楼梯。今天这趟车满员了，别再往上爬！"
      },
      {
        "flag": "daily_laundry_1_2",
        "bond": 2,
        "text": "【host:neutral】上车！我来推。\n\n【guest:neutral】别动，针还穿着呢！你再推，把我也缝车上了。\n\n【laundress:annoyed】停车！一个补，一个推，很难分吗？\n\n【stage】系带补好，围裙松开车轮。七号布牌从破口滑了出来。\n\n【guest:neutral】好了，蓝线。牌背面糊住了，我拿去泡泡。\n\n【host:neutral】这回真走了，我送它去楼梯。你把手收回去！"
      },
      {
        "flag": "daily_laundry_1_3",
        "bond": 2,
        "text": "【host:neutral】围裙跟着袜子跑了，后头还跟着条裤子！\n\n【laundress:annoyed】裤子回来！你主人还蹲隔间里呢！\n\n【guest:neutral】我拿袜子去炉边，你横车，快！\n\n【stage】袜子停了，围裙爬进车里，掉下一块七号布牌。\n\n【host:neutral】七号，谁的？\n\n【laundress:neutral】围裙的，留着。你去还裤子，你送围裙去楼梯。别换了。"
      }
    ]
  },
  {
    "id": "daily_laundry_2",
    "kind": "duo",
    "act": 2,
    "title": "七号柜里有人打呼",
    "purpose": "一个同柜里打交道，一个处理毛巾。先弄清里面住的是谁。",
    "stage": {
      "background": "laundry",
      "cast": [
        "laundress"
      ]
    },
    "text": "【laundress:annoyed】少一条浴巾。你俩谁拿了？\n\n【host:neutral】先别看我，七号柜在打呼，你听。\n\n【stage】柜门开了条缝，一只衣架递出来。\n\n【guest:neutral】这是干吗，交房租？\n\n【laundress:annoyed】那是我丢的衣架！门里那位，出来！\n\n{DAILY:laundry_1}\n\n【host:neutral】毛巾搂这么紧，来硬的啊？\n\n【guest:neutral】你先把它叫醒，我看看毛巾。",
    "clues": {
      "host": "柜门没有锁。普通敲门声会得到两下轻敲的回答，提到“房租”时，里面便会找东西往外递。你可以按领衣流程请它开门，也可以顺着房客的意思谈床位。",
      "guest": "最上层毛巾已经被叠成了枕头。柜里只剩一团暖气和那条旧围裙，没人影。阿绫给了你一块刚热好的小手巾：可以先还回浴巾，也可以拿热手巾交换，别把热水倒进柜子。"
    },
    "options": {
      "host": [
        "敲三下，请它出来领衣服",
        "拿登记本，问它住了几晚"
      ],
      "guest": [
        "抱回客人的大浴巾",
        "用热手巾换出大浴巾"
      ]
    },
    "callbacks": {
      "laundry_1": {
        "daily_laundry_1_0": "【guest:neutral】蓝线是我们缝的。七号牌还挂着，没认错。",
        "daily_laundry_1_1": "【guest:neutral】还是那条抢袜子的围裙。七号牌我拿着，袜子可没欠它。",
        "daily_laundry_1_2": "【guest:neutral】我们送过它。七号牌泡开了，背面还有字。",
        "daily_laundry_1_3": "【guest:neutral】上回带一群衣服跑的就是它。七号牌在我这儿，今天别再领裤子走了。",
        "default": "【guest:neutral】门缝这条围裙，腰上缝着七号。它也在这儿干活？"
      }
    },
    "results": [
      {
        "flag": "daily_laundry_2_0",
        "bond": 2,
        "text": "【host:neutral】七号，出来领衣服！\n\n【guest:neutral】浴巾拿到了，怎么还打呼？\n\n【stage】一团暖气从毛巾里挤出来，钻进围裙。\n\n【laundress:neutral】你把人枕头拿了，能不醒吗。烘衣房那个，干了一夜。\n\n【host:neutral】那也不能睡柜子啊。\n\n【laundress:neutral】七号牌翻过来，写的是床位。楼上门牌让浴袍挡了……怪我。登记本拿着，等会儿带它上去。"
      },
      {
        "flag": "daily_laundry_2_1",
        "bond": 2,
        "text": "【host:neutral】七号，醒醒，领衣服了。\n\n【guest:neutral】这块热的给你，大浴巾还我。对，慢点。\n\n【stage】围裙抱着小手巾从柜里挤了出来。\n\n【host:neutral】还真是烘衣房的。它为什么睡柜子？\n\n【laundress:neutral】认错了。布牌背面是七号床，楼上门牌让浴袍挡了。谁晾的……哦，我。\n\n【guest:neutral】我去挪。床位记这页，手巾让它带着吧。"
      },
      {
        "flag": "daily_laundry_2_2",
        "bond": 2,
        "text": "【host:neutral】查房！住几晚了？\n\n【stage】柜里递出衣架，又递出半个衣夹。\n\n【guest:neutral】别交别交，他不收钱。浴巾给我，你这枕头得换。\n\n【laundress:annoyed】你哪来这么大官瘾？吓得它把我衣夹都拆了。\n\n【host:neutral】我就想给它换张床！\n\n【laundress:neutral】牌背面是七号床。楼上门牌被衣服遮了，才睡错地方。登记本给我，写清楚，别再查房了。"
      },
      {
        "flag": "daily_laundry_2_3",
        "bond": 2,
        "text": "【host:neutral】查一下床位，您住得还习惯吧？\n\n【guest:neutral】少装。来，热手巾换你的大浴巾。\n\n【laundress:annoyed】等等，你在“已收房租”上画什么？\n\n【host:neutral】顺手……我擦，马上擦。\n\n【laundress:annoyed】员工床不收钱！七号牌翻面是床号，楼上门牌被浴袍挡了，才睡这儿。\n\n【guest:neutral】记下了。手巾给它盖着，等换班咱们带它去认门。"
      }
    ]
  },
  {
    "id": "daily_laundry_3",
    "kind": "duo",
    "act": 3,
    "title": "七号床不收加班的",
    "purpose": "一个安顿床铺，一个接住洗衣房的铃。让烘衣工真正休息一回。",
    "stage": {
      "background": "bathhouse",
      "cast": [
        "laundress"
      ]
    },
    "text": "【stage】围裙抱着枕头刚迈进门，楼下的铃一响，它又掉头往回跑。\n\n【host:neutral】哎哎，床就在这儿，你又跑哪儿去？\n\n【laundress:neutral】一响铃就以为来活了。你们安顿它，我接班。\n\n{DAILY:laundry_2}\n\n【guest:neutral】楼下还来人呢，那个抱被子的都排三回了。\n\n【laundress:annoyed】让他明早取。今晚谁也别加班，锅炉还得停下来清灰呢。\n\n【host:neutral】牌子我来写。\n\n【laundress:neutral】写明早开门。上回有人写“歇业”，唐婶差点把我开了。",
    "clues": {
      "host": "你负责七号床。烘衣工没睡过真正的床，反复摸床沿。可以直接铺好让它试，也可以给它画一张从洗衣房到床边的路线；别改它床位，腰带上就是七号。",
      "guest": "你负责楼下的铃。阿绫已接班，衣服可以明早取。拆下铃舌就不会响，但客人可能继续摇；把铃挪到你值守的柜台，能当面说明取衣时间。两种办法都不收费，也不用另买工具。"
    },
    "options": {
      "host": [
        "铺好床，陪它试着躺下",
        "画条路线，把门牌挂低一点"
      ],
      "guest": [
        "收起铃舌，挂明早取衣的牌",
        "把铃搬到柜台，由我们应门"
      ]
    },
    "callbacks": {
      "laundry_2": {
        "daily_laundry_2_0": "【guest:neutral】这回没拿你枕头。上回手快了，对不住啊。",
        "daily_laundry_2_1": "【guest:neutral】楼上浴袍挪走了。热手巾给你带着，没人抢。",
        "daily_laundry_2_2": "【host:neutral】不查房，衣夹也还了。我真是来送你睡觉的。",
        "daily_laundry_2_3": "【host:neutral】房租那勾擦了，没收钱！你别一见我就掏东西。",
        "default": "【laundress:neutral】它把七号柜当床了，挤得系带都打结。登记本在这儿，这回是七号床。"
      }
    },
    "results": [
      {
        "flag": "daily_laundry_3_0",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】躺吧，我不走。脚——算了，带子往里收收。\n\n【guest:neutral】铃舌拆了。客人还在外头摇，摇得挺卖力。\n\n【laundress:neutral】我去说。你俩别围着它，这边又不是看猴。\n\n【stage】枕头凹下去，床边冒出细细的暖气。\n\n【host:neutral】睡了。那我们……\n\n【laundress:neutral】旁边两张空床，躺。鞋脱了！"
      },
      {
        "flag": "daily_laundry_3_1",
        "bond": 2,
        "heal": 3,
        "text": "【guest:neutral】铃挪柜台了。我说一句明早取，他摇一下。\n\n【host:neutral】嫌晚？\n\n【guest:neutral】没有嘴。我问半天才看见。\n\n【laundress:neutral】拿纸给他写。你守着七号，别让它又下来。\n\n【stage】围裙探头看见柜台有人接待，又慢慢缩回被子里。\n\n【host:neutral】睡吧，有人管了。等你睡着，我也躺旁边。"
      },
      {
        "flag": "daily_laundry_3_2",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】出洗衣房，右拐，第二张床。看懂没？\n\n【guest:neutral】没。你把床画成了一条鱼。\n\n【laundress:neutral】给我，我画。你去挂门牌，挂低点。\n\n【stage】围裙沿着图上的线挪到七号床，爬进被子。\n\n【guest:neutral】铃也拆了，总算消停。\n\n【host:neutral】能躺了吗？我站着都要睡着了。\n\n【laundress:neutral】旁边空床。那条鱼别撕了，它刚塞枕头底下。"
      },
      {
        "flag": "daily_laundry_3_3",
        "bond": 2,
        "heal": 3,
        "text": "【guest:neutral】路画完了？楼下那俩湿被子，我让他们明早来。\n\n【host:neutral】好了。哎，袖子怎么动不了？\n\n【laundress:annoyed】你把自己缝床单上了！剪刀给我。\n\n【stage】阿绫剪开线头。围裙抖了两下，钻进七号床的被子。\n\n【guest:neutral】它笑你呢。牌挂这儿，字朝外。\n\n【host:neutral】行，至少记住床了。让我在旁边躺会儿，谁也别叫我缝东西。"
      }
    ]
  }
];
})(window.GAME_DATA);
