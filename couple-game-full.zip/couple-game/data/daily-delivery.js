/* Short night-shift delivery scenes. Full previous pack is archived; choices and rewards stay intact. */
(function(G){
'use strict';
G.dailyScenePacks=G.dailyScenePacks||{};
G.dailyScenePacks.delivery=[
  {
    "id": "daily_delivery_1",
    "kind": "duo",
    "act": 1,
    "title": "这顿饭送给墙上的三位",
    "purpose": "一人招呼客人，一人摆灯送饭。两个人各选一种做法。",
    "stage": {
      "background": "kitchen",
      "cast": [
        "porter"
      ]
    },
    "text": "【stage】阿钉把三个饭盒摞到你们手上。\n\n【porter:neutral】帮我送一趟，送完请你俩吃饭。\n\n【host:neutral】你请？\n\n【porter:neutral】唐婶请。我负责请你们干活。拿稳，红绳三个结别解，盒子都要还的。\n\n【guest:neutral】你倒挺会省事。送哪儿？\n\n【porter:neutral】洗衣房后头，墙里那三个洗锅的影子。灯带上，别找门了，我刚找过半天。",
    "clues": {
      "host": "墙里敲了三下，接着有人喊“下班了，别叫客官”。他们还在争谁洗的锅最多。你负责招呼：可以照旧喊送餐，也可以招呼他们过来开饭。",
      "guest": "饭盒里是热饭。纸条写着：这三位只吃饭的影子，米饭留给跑腿的。灯靠近，饭影很大；灯放远些，三个饭盒的影子刚好并排。红绳的三个结分别对着三个提梁。"
    },
    "options": {
      "host": [
        "喊“十七号客人，送餐到了”",
        "喊“收工开饭，勺子先放下”"
      ],
      "guest": [
        "把灯挪近，让饭影大一点",
        "把灯放远，让三份饭排整齐"
      ]
    },
    "results": [
      {
        "flag": "daily_delivery_1_0",
        "bond": 2,
        "text": "【host:neutral】十七号客人，送餐！\n\n【guest:neutral】灯近一点……哎，饭怎么照成床了？\n\n【stage】三个影子吃了两口，往饭影上躺平。\n\n【porter:annoyed】完了，真躺上了。唐婶来我怎么说？\n\n【host:neutral】都躺下了，你还给人拽起来？今天就算客人呗。\n\n【guest:smile】饭影给他们躺，真饭咱们吃。三个结的红绳我收着，别催我再送一趟。"
      },
      {
        "flag": "daily_delivery_1_1",
        "bond": 2,
        "text": "【host:neutral】十七号客人，开饭！\n\n【guest:neutral】灯放远了，一人一份。左边的，勺子收回去！\n\n【porter:neutral】它一向够不着自己的菜，就够得着别人的。\n\n【host:neutral】我把灯往右挪挪，看它还怎么抢。\n\n【stage】那影子端碗跟着光挪，又挤到隔壁。\n\n【porter:neutral】得，咱吃真的。三个结的红绳你们收着，明天——哎，怎么都不看我？"
      },
      {
        "flag": "daily_delivery_1_2",
        "bond": 2,
        "text": "【host:neutral】下班，开饭！勺子搁下！\n\n【guest:neutral】灯挪近点，馒头照大点。\n\n【porter:neutral】你那手别挡——\n\n【stage】一个影子张嘴，咬住了灯前的手影。\n\n【host:annoyed】靠！我送个饭还搭只手？\n\n【porter:annoyed】松口！那玩意儿没馒头香。来，往饭这边照。红绳三个结还在吧？\n\n【guest:smile】在。手也在，咱吃饭去吧。"
      },
      {
        "flag": "daily_delivery_1_3",
        "bond": 2,
        "text": "【host:neutral】收工开饭！坐哪儿吃哪份！\n\n【guest:neutral】灯放远，三只盒子排一排。\n\n【stage】三个影子来回换座，谁都想抢中间那碗。\n\n【host:neutral】干活没见他们这么勤快。\n\n【porter:neutral】嫌少呗。灯摆正，照红绳三个结，一盒对一个。\n\n【guest:neutral】总算一样大了。三个结都留着，下次你自己照着摆。\n\n【porter:smile】先吃饭再骂我，真的那份都快凉了。"
      }
    ]
  },
  {
    "id": "daily_delivery_2",
    "kind": "duo",
    "act": 2,
    "title": "送进去三盒，回来四盒",
    "purpose": "一人守住领餐口，一人处理混进来的影子。",
    "stage": {
      "background": "workshop",
      "cast": [
        "porter"
      ]
    },
    "text": "【porter:neutral】救个急。三盒饭送出去，回来四盒，怎么跟唐婶交代？\n\n【host:neutral】多一盒你还不乐？\n\n【stage】多出来的饭盒咳嗽了一声。\n\n【porter:annoyed】我刚差点把它当剩汤倒了！唐婶知道得拿我熬汤。\n\n{DAILY:delivery_1}\n\n【guest:neutral】那你掀盖啊。\n\n【porter:neutral】我掀了，里面喊“有人”！跟占着茅房似的。帮我把它请下车行不行？",
    "clues": {
      "host": "领餐口很窄，影子能贴着墙走，饭盒提过去会卡。阿钉昨晚答应带它下班，却忘了回来。你可以报“送晚饭”，也可以说明“来接你下工”。",
      "guest": "盒底发出三下敲击，里面只有一个影子。它在学饭盒开工的铃声。把灯照到墙上能给它铺出路；拿新饭在旁边扇香味，也能把它引出来。"
    },
    "options": {
      "host": [
        "照规矩喊“开盖领晚饭”",
        "敲三下，说“来接你下工了”"
      ],
      "guest": [
        "把灯转向墙壁，留出一条影路",
        "掀开新饭盒，往领餐口扇香味"
      ]
    },
    "callbacks": {
      "delivery_1": {
        "daily_delivery_1_0": "【porter:neutral】上回睡饭影那三位，还问今晚能不能加枕头。这又来了个住盒子的。",
        "daily_delivery_1_1": "【porter:neutral】不是上回抢菜的那位。这个连勺子都没带，光带了张请假条。",
        "daily_delivery_1_2": "【porter:smile】你手那事，我替你骂过它了。它说认错了，手没有馒头香。",
        "daily_delivery_1_3": "【porter:neutral】上回按三个结摆的盒子，一只没丢。多的这只也系着，镜子给我照出来的。",
        "default": "【porter:neutral】我盒子都系着三个结的红绳，好认。谁知道镜子把绳也照了一份。"
      }
    },
    "results": [
      {
        "flag": "daily_delivery_2_0",
        "bond": 2,
        "text": "【host:neutral】领晚饭！出来吃，盒里没座。\n\n【guest:neutral】灯照好了，沿墙走。\n\n【stage】阿钉伸手收盒子，挡住灯；影子卡在了墙角。\n\n【host:annoyed】阿钉，往下蹲！你把人腰给卡住了！\n\n【porter:neutral】出来了出来了。我就想早点洗完，谁知道还有人……\n\n【guest:neutral】把“关灯前问有没有人”写灯上，正反都写。请假条拿去交，别又塞饭盒里。"
      },
      {
        "flag": "daily_delivery_2_1",
        "bond": 2,
        "text": "【host:neutral】开盖领晚饭，今天有炖萝卜！\n\n【guest:neutral】热的，闻见没有？\n\n【stage】四只盒盖一齐掀开，影子全伸手要饭。\n\n【porter:annoyed】那三个不是吃过了吗？\n\n【host:neutral】你昨天忘了接人，今天是不是也没喊下班？\n\n【porter:annoyed】他大爷的，还真忘了！都下班，都回！灯给我，我挨个送。萝卜算加班饭，请假条我交，别跟唐婶提这茬。"
      },
      {
        "flag": "daily_delivery_2_2",
        "bond": 2,
        "text": "【host:neutral】敲三下。接你下工来了！\n\n【stage】盒里回了三下，等了一会儿，又重重敲了一下。\n\n【porter:neutral】多一下什么意思？\n\n【guest:neutral】催你呢。路断了，红绳抻直，灯照过去！\n\n【porter:neutral】这么细，踩断了怎么办？\n\n【host:neutral】人家踩影子！你少问一句，早点送它回去。"
      },
      {
        "flag": "daily_delivery_2_3",
        "bond": 2,
        "text": "【host:neutral】敲三下。来接你下工了！\n\n【guest:neutral】路上吃点？新饭，热着呢。\n\n【stage】影子探出头，一手拎走一份饭影。\n\n【host:neutral】拿两份？你等——\n\n【porter:neutral】夜班那位还没吃，它替人捎的。灯借我，前头黑。真饭给你俩留着。\n\n【guest:neutral】跟它走完。回来洗四只盒，别跟我说账上只有三只。\n\n【porter:neutral】四只就四只。多的留着，下回别再挤一盒了。"
      }
    ]
  },
  {
    "id": "daily_delivery_3",
    "kind": "duo",
    "act": 3,
    "title": "最后一班，先把人送回去",
    "purpose": "两个人配合灯光和红绳，送夜班影子过断开的回廊。",
    "stage": {
      "background": "bathhouse",
      "cast": [
        "porter"
      ]
    },
    "text": "【stage】回廊缺了两块地砖，下面全是海水。影子挤在断口边。\n\n【porter:annoyed】快来搭把手！今晚收炉，灯一灭，这群下夜班的就走不了了！\n\n{DAILY:delivery_2}\n\n【host:neutral】你不是说今天能自己送？\n\n【porter:neutral】我哪知道桥塌了！红绳接了三段，灯、盒子都在，手不够。\n\n【guest:neutral】饭盒挂上绳，拿它们的影子接过去。带队还是举灯，咱俩分一下。\n\n【porter:neutral】行。别让我拆手，前回借人开罐头，三天才还。",
    "clues": {
      "host": "你守着回廊这一端。三个洗锅影子排在前面，还有一个瘦影子在等同伴。喊名字会乱：他们用的是主人的名字，重复很多。你可以按红绳三个结分批叫号，也可以让走过的人敲盒报数。",
      "guest": "你负责稳住灯和饭盒。把灯压低，三个盒底的影子能接成宽桥，但手得举稳；缓缓转动灯，路会一段段向前延伸，过桥的人得跟着走。两种办法都行，先提醒对方怎么带队。"
    },
    "options": {
      "host": [
        "每批三个，按绳结叫号过桥",
        "让过桥的人敲饭盒，边走边报数"
      ],
      "guest": [
        "把灯压低，举稳一座宽影桥",
        "慢慢转灯，让影路跟着队伍走"
      ]
    },
    "callbacks": {
      "delivery_2": {
        "daily_delivery_2_0": "【porter:neutral】“关灯前问有没有人”，灯两面都写了。你看，我没忘。就是现在人太多了。",
        "daily_delivery_2_1": "【porter:neutral】今天没喊炖萝卜，喊的下班！这回真不是馋的，是真过不去。",
        "daily_delivery_2_2": "【porter:neutral】上回那根红绳我带着。人太多，光照绳子不够，得搭宽点。",
        "daily_delivery_2_3": "【porter:neutral】上回给夜班带饭那位也在，今天别人替它带。好不容易轮到它歇。",
        "default": "【porter:neutral】你们没送过影子吧？它们只能走影路，照不到的地方就过不去。"
      },
      "delivery_1": {
        "daily_delivery_1_0": "【porter:neutral】躺饭影那三个，起来走！这回不是给你们铺床！",
        "daily_delivery_1_1": "【porter:neutral】抢隔壁菜那位，排中间，别再往边上够了！",
        "daily_delivery_1_2": "【porter:neutral】上回咬手那位，我看着你呢。今天再张嘴就走最后！",
        "daily_delivery_1_3": "【porter:neutral】照上回饭盒那样排！对，就你们三个，挤什么挤。",
        "default": "【porter:neutral】前头三个，洗锅的，袖子擦干再走，别把灯碰灭了。"
      }
    },
    "results": [
      {
        "flag": "daily_delivery_3_0",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】三个人一拨，走到绳结这儿停一下！\n\n【guest:neutral】灯压低了，路够宽，下一拨上。\n\n{DAILY:delivery_1}\n\n【stage】最后一个影子到了对岸，仍拽着阿钉的围裙不松。\n\n【porter:neutral】它等我呢。我以前送到门口就跑，饭都没吃完。\n\n【host:neutral】去吧，灯我们拿着。回来端三碗汤，别又少算你自己。\n\n【porter:neutral】行，三碗。这回我送到家，谁喊洗盒子都不好使。"
      },
      {
        "flag": "daily_delivery_3_1",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】三个人一拨，跟着饭盒走！后头的等等！\n\n【guest:neutral】我慢慢转灯。停，前头那位鞋跟还没过！\n\n{DAILY:delivery_1}\n\n【porter:neutral】齐活，可以关灯——\n\n【host:neutral】你自己的影子还在后头呢！\n\n【porter:annoyed】我靠，忙得把自己忘了。今天盒子泡着，不洗了。\n\n【guest:neutral】那还站着？端三碗热汤来，你也坐。"
      },
      {
        "flag": "daily_delivery_3_2",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】过去一个，敲一下！不许替后头的敲！\n\n【guest:neutral】灯压低了，我稳着，你慢慢数。\n\n{DAILY:delivery_1}\n\n【stage】最后一个影子踮着脚，用脑袋够饭盒底。\n\n【porter:neutral】怎么少一个？它过没过？\n\n【host:neutral】它没手！盒子放低，没看见人家跳半天了？\n\n【porter:neutral】咚，齐了！绳子收一收，我去端汤，三碗。\n\n【guest:neutral】第三碗你自己喝，别端出去送人了。"
      },
      {
        "flag": "daily_delivery_3_3",
        "bond": 2,
        "heal": 3,
        "text": "【host:neutral】边走边敲，别堵在中间！\n\n【guest:neutral】你别赶，我灯都快追不上了！\n\n{DAILY:delivery_1}\n\n【stage】最后一队到了廊尾，阿钉还提着一只饭盒。\n\n【host:neutral】都走完了，你还端谁的？\n\n【porter:neutral】守灯的。咱走了，它还得收灯呢，总不能又漏一个。\n\n【guest:neutral】那就等它一块儿喝汤。凳子拿来，别一吃饭就装忙。\n\n【porter:smile】行，今天我坐着吃。谁再喊送饭，先等我把这碗喝完。"
      }
    ]
  }
];
})(window.GAME_DATA);
