/* Night-bathhouse delivery shifts. Dialogue-first, with saved, choice-specific callbacks. */
(function(G){
'use strict';
G.dailyScenePacks=G.dailyScenePacks||{};
G.dailyScenePacks.delivery=[
 {
  id:'daily_delivery_1',kind:'duo',act:1,title:'这顿饭送给墙上的三位',
  purpose:'一人招呼客人，一人摆灯送饭。两个人各选一种做法。',
  stage:{background:'kitchen',cast:['porter']},
  text:`【stage】阿钉把三个饭盒摞到你们手上。

【porter:neutral】十七号，三份。红绳先别解，盒子不算赠品。

【host:neutral】十七号在哪？

【porter:neutral】洗衣房后面。看见一堵没门的墙，就是了。

【guest:neutral】你把路说成这样，还好意思收跑腿钱？

【porter:annoyed】我没收！掌柜让我拿剩饭。昨天剩了半根葱。

【host:neutral】没门，怎么敲？

【porter:neutral】敲墙。里面三个洗锅的影子，刚下工。他们的主人早睡了。

【guest:smile】人回去睡觉，影子留下洗锅？

【porter:neutral】所以别提睡觉。他们听见会摔勺。

【guest:neutral】那我们端真的饭来干什么？

【porter:neutral】没饭就没饭影。你拿空碗来，照一天也是空的。

【host:neutral】三份饭，三个结。绳也是按人头算的？

【porter:neutral】那是点人数用的。我数着数着，他们老往一块儿站。`,
  clues:{
   host:'墙里敲了三下，接着有人喊“下班了，别叫客官”。他们还在争谁洗的锅最多。你负责招呼：可以照旧喊送餐，也可以招呼他们过来开饭。',
   guest:'饭盒里是热饭。纸条写着：这三位只吃饭的影子，米饭留给跑腿的。灯靠近，饭影很大；灯放远些，三个饭盒的影子刚好并排。红绳的三个结分别对着三个提梁。'
  },
  options:{host:['喊“十七号客人，送餐到了”','喊“收工开饭，勺子先放下”'],guest:['把灯挪近，让饭影大一点','把灯放远，让三份饭排整齐']},
  results:[
   {flag:'daily_delivery_1_0',bond:2,text:`【host:neutral】十七号客人，送餐到了！

【stage】墙上三个影子同时伸手。

【guest:neutral】慢点，我把灯挪——

【porter:annoyed】太近了！你把一碗饭照成了一张床！

【host:neutral】那他们怎么都躺下了？

【porter:neutral】你喊的客人。客人可以躺，伙计不行。

【guest:smile】行，今天算客人。汤的影子放床头。

【porter:neutral】别教他们。我明天还得送。

【host:neutral】绳子归谁？

【porter:neutral】先替我拿着。三个结，回头少一个，你们进墙里数。

【guest:neutral】饭影吃完，米饭真归我们？

【porter:smile】归。葱留我一点。

【host:neutral】我给你留半盒，别只挑葱。

【porter:neutral】先给右边那位照一下。它刚才睡着，没吃上。`},
   {flag:'daily_delivery_1_1',bond:2,text:`【host:neutral】十七号客人，饭到了！

【stage】三个影子沿着墙根坐成一排。

【guest:neutral】一人一份，别往中间挤。

【porter:neutral】左边那个，把勺子放回自己的碗里。

【host:neutral】他只是够不着菜。

【porter:neutral】他从上个月就够不着，一直够不着右边那份。

【guest:smile】我把灯往右挪一点，菜自己过去。

【stage】左边的影子端碗跟了过去。

【host:neutral】现在人也过去了。

【porter:annoyed】算了，先吃。红绳给你们收着，明天靠三个结认盒子。

【guest:neutral】谁规定明天还是我们送？

【porter:smile】你们刚才说了“明天”？我没说。

【host:neutral】我们明天不一定过来，先把路教给别人。

【porter:neutral】行。今晚这顿你们先吃，我去找人接班。`},
   {flag:'daily_delivery_1_2',bond:2,text:`【host:neutral】收工开饭！勺子先放下！

【stage】墙里响了三声，锅勺落了一地。

【porter:neutral】放下就行，也不用扔。

【guest:neutral】灯挪近点，今天管饱。

【host:neutral】这么大一只馒头，三个一起吃吧。

【porter:neutral】那不是馒头，是你的手。

【stage】你连忙把手从灯前抽开。

【guest:smile】还没送到饭，先送了个厨子。

【porter:smile】他们爱开这种玩笑。真夹住了就叫我，我有油。

【host:neutral】你为什么随身带这个？

【porter:neutral】别问。三个结的红绳替我留着，下次把手拿远点。

【guest:neutral】先把饭摆好。我们还等着吃那份真的。

【porter:neutral】你们坐凳子，我蹲着就行。

【guest:neutral】挤一挤，别端着碗躲墙角。

【porter:neutral】那你别压我衣摆。还得穿呢。`},
   {flag:'daily_delivery_1_3',bond:2,text:`【host:neutral】收工开饭，今天不用排队！

【guest:neutral】三个盒子，三把勺。坐哪儿吃哪份。

【porter:smile】这就对了，省得他们又吵——

【stage】三个影子开始交换座位。

【host:neutral】这回又怎么了？

【porter:neutral】嫌自己的那份小。

【guest:neutral】一样大。我拿绳子量给他们看。

【host:smile】先别量。你把灯摆正。

【stage】饭影齐了，勺子终于动起来。

【porter:neutral】红绳收好，三个结都别动。以后换人送饭，也按这个摆。

【guest:neutral】“以后换人”是多久？

【porter:smile】得看掌柜什么时候再捡到两个会干活的。

【host:neutral】我们只答应帮这一趟。

【porter:neutral】知道。碗放着，我来洗，你们先把饭吃完。`}
  ]
 },
 {
  id:'daily_delivery_2',kind:'duo',act:2,title:'送进去三盒，回来四盒',
  purpose:'一人守住领餐口，一人处理混进来的影子。',
  stage:{background:'workshop',cast:['porter']},
  text:`【stage】阿钉蹲在四只饭盒前。

【porter:neutral】这事别让掌柜知道。我只送了三盒，回来四盒。

【host:neutral】多一盒，还不好？

【porter:annoyed】多的那盒会咳嗽。我不敢洗。

{DAILY:delivery_1}

【guest:neutral】红绳呢？

【porter:neutral】都系着。那三个结，镜子也学会了。

【guest:neutral】先别洗。里头有人，你还往里挤洗碗水？

【porter:neutral】我只倒了一点。他说太凉。

【host:neutral】开盖数饭不就行了？

【porter:neutral】一开，里面就说“有人”。我都给它道歉两次了。

【guest:neutral】送去哪里？

【porter:neutral】锅炉后边。昨晚有个影子没赶上下工，跟着饭盒出来了。

【host:neutral】所以不是多了一份饭，是多了个乘客。

【porter:neutral】你先帮我把乘客请下来。今天这锅饭还没送。`,
  clues:{
   host:'领餐口很窄，影子能贴着墙走，饭盒提过去会卡。阿钉昨晚答应带它下班，却忘了回来。你可以报“送晚饭”，也可以说明“来接你下工”。',
   guest:'盒底发出三下敲击，里面只有一个影子。它在学饭盒开工的铃声。把灯照到墙上能给它铺出路；拿新饭在旁边扇香味，也能把它引出来。'
  },
  options:{host:['照规矩喊“开盖领晚饭”','敲三下，说“来接你下工了”'],guest:['把灯转向墙壁，留出一条影路','掀开新饭盒，往领餐口扇香味']},
  callbacks:{delivery_1:{
   daily_delivery_1_0:'【guest:smile】先不说四盒。那三个睡饭影里的，起床了吗？\n\n【porter:neutral】起了，还问今晚能不能加枕头。',
   daily_delivery_1_1:'【host:neutral】上回抢隔壁菜的那位，又跟着饭跑了？\n\n【porter:neutral】不是。这位连勺子都没带，光带了张请假条。',
   daily_delivery_1_2:'【host:neutral】先说好，今天不许咬我的手影。\n\n【porter:smile】我替你说了。它说上回认错了，手没馒头香。',
   daily_delivery_1_3:'【guest:neutral】不是让他们一人拿一只吗？\n\n【porter:neutral】原来那三只没错。问题在第四只，我连收据都没有。',
   default:'【porter:neutral】先认一下：我的饭盒，提梁上有根三个结的红绳。\n\n【host:neutral】好认。你这四只上面都有。'
  }},
  results:[
   {flag:'daily_delivery_2_0',bond:2,text:`【host:neutral】开盖领晚饭，别在盒里吃！

【stage】盒盖掀开，一只影手伸向墙面。

【guest:neutral】路在这边。跟着灯走。

【porter:neutral】别急，我把旧盒收——

【stage】阿钉挡住灯，墙上的路断了。

【host:annoyed】先别收！你把人夹在拐角了。

【guest:neutral】灯举高，你从下面钻过去。

【porter:neutral】好，好。骨头瘦还是有点用。

【host:neutral】出来了。请假条贴哪儿？

【porter:neutral】我替它交。以后熄灯前，得先问还有没有人。

【guest:smile】把这句写在灯上。你别只写本子里。

【porter:neutral】有笔吗？

【host:neutral】有。写大一点，别让灯把字烤没了。

【porter:neutral】你帮我扶着。我这指头写小字还行，写大字老打滑。`},
   {flag:'daily_delivery_2_1',bond:2,text:`【host:neutral】开盖领晚饭！今天有炖萝卜！

【guest:neutral】还有汤，闻见没？

【stage】四只盒盖一起抬了起来。

【porter:annoyed】怎么全醒了？原来三个不是吃过了吗？

【host:neutral】你喊过“下班”没有？

【porter:neutral】忘了。

【guest:neutral】那是你让他们一直等着加菜。

【porter:neutral】今天下班！明天还开，明天再来！

【stage】四道影子提着饭影，沿墙挪走。

【host:neutral】最后一位没路了。灯往那边转。

【guest:smile】以后先清场再关灯。你今天多送的那份，算加班饭。

【porter:neutral】行，别拿萝卜给掌柜打小报告。

【host:neutral】不打。先把请假条交了，人家还等着。

【porter:neutral】揣好了，这回揣在饭盒外面。`},
   {flag:'daily_delivery_2_2',bond:2,text:`【host:neutral】来接你下工了。三下，是这个声吧？

【stage】盒里回敲三下，又轻轻敲了一下。

【porter:neutral】最后那下什么意思？

【guest:neutral】催你的。灯我举着，快接。

【stage】影子从盒边走到墙上，指了指自己脚下。

【host:neutral】路断了。绳子绷直，把灯照过去。

【porter:neutral】红绳这么细，踩得住吗？

【guest:smile】人家又不踩绳子，踩的是影子。

【porter:neutral】哦。你早说，我刚才还想找块木板。

【host:neutral】先送它回去。你答应了就别把灯关了。

【porter:neutral】记住了。我送到门口，再回来刷盒。

【guest:neutral】绳头给我，你别一边提盒一边拽。

【porter:neutral】对。刚才一紧张，差点把它送回锅里。`},
   {flag:'daily_delivery_2_3',bond:2,text:`【host:neutral】敲三下。来接你下工了！

【guest:neutral】路上吃点？新煮的，别客气。

【stage】影子探出头，先伸手拿饭。

【porter:smile】慢点，饭影归你，真饭留给我们。

【host:neutral】它怎么提着两盒走？

【porter:neutral】还有一盒是夜班。它替没休息的那位带。

【guest:neutral】原来不是贪吃。刚才差点拦它。

【stage】影子在灯照不到的地方停住了。

【host:neutral】阿钉，灯举过来。你送人，光送饭盒哪行。

【porter:neutral】来了。红绳给我，我牵着灯走。

【guest:smile】回来记得刷四只。别又说账上只有三只。

【host:neutral】多的那只留着，别退进镜子里。

【porter:neutral】留。下回再有晚班的，就不用挤一盒了。`}
  ]
 },
 {
  id:'daily_delivery_3',kind:'duo',act:3,title:'最后一班，先把人送回去',
  purpose:'两个人配合灯光和红绳，送夜班影子过断开的回廊。',
  stage:{background:'bathhouse',cast:['porter']},
  text:`【stage】回廊缺了两块地砖，下面全是海水。

【porter:neutral】别跨，昨天掉下去一只鞋。鞋自己回来了，人还在找鞋。

【host:neutral】你在这儿等谁？

【porter:neutral】下夜班的。今晚收炉，灯一灭，他们就回不去了。

{DAILY:delivery_2}

【guest:neutral】主人不回来接？

【porter:neutral】有的回来了，正贴在墙那头等。水上接不上影子，谁都过不来。

【guest:neutral】红绳够长吗？

【porter:neutral】够。我接了三段，昨天就在试。

【host:neutral】墙上那块湿的，照不出路。

【guest:neutral】把饭盒挂绳子上，灯从这边照。三个盒底能接起来。

【porter:neutral】盒子会晃。我一只手稳灯，一只手收绳，少只手。

【host:smile】我们有。你别把自己的拆下来。

【porter:neutral】本来也不打算。上回借给人开罐子，三天才还。`,
  clues:{
   host:'你守着回廊这一端。三个洗锅影子排在前面，还有一个瘦影子在等同伴。喊名字会乱：他们用的是主人的名字，重复很多。你可以按红绳三个结分批叫号，也可以让走过的人敲盒报数。',
   guest:'你负责稳住灯和饭盒。把灯压低，三个盒底的影子能接成宽桥，但手得举稳；缓缓转动灯，路会一段段向前延伸，过桥的人得跟着走。两种办法都行，先提醒对方怎么带队。'
  },
  options:{host:['每批三个，按绳结叫号过桥','让过桥的人敲饭盒，边走边报数'],guest:['把灯压低，举稳一座宽影桥','慢慢转灯，让影路跟着队伍走']},
  callbacks:{delivery_2:{
   daily_delivery_2_0:'【guest:neutral】灯上真写了“先问还有没有人”？\n\n【porter:neutral】写了，正反两面。省得我把它转过去就忘。',
   daily_delivery_2_1:'【host:neutral】今天别再拿炖萝卜当下班铃了。\n\n【porter:neutral】知道。这回先送人，再发饭。',
   daily_delivery_2_2:'【guest:neutral】还是上回那办法，拿红绳的影子铺路？\n\n【porter:neutral】这回人多，得搭宽点。总不能让他们侧着身子下班。',
   daily_delivery_2_3:'【host:neutral】给夜班带饭的那位，也在这队里？\n\n【porter:neutral】在。今天终于有人替它带了。',
   default:'【porter:neutral】先说明白：他们只能走灯照出来的影路。\n\n【guest:neutral】所以这根绳，是拿来把影子接过去的。'
  },delivery_1:{
   daily_delivery_1_0:'【porter:smile】最前面三个，是上回躺饭影里的。今天让他们走两步。',
   daily_delivery_1_1:'【porter:neutral】爱够隔壁菜的那位也来了。这回让它排中间，别往边上伸。',
   daily_delivery_1_2:'【porter:smile】认错你手影的那位说，今天保证不咬。你可以放心举灯。',
   daily_delivery_1_3:'【porter:neutral】灯照正一点。他们认得上回排饭盒的样子，照着站就行。',
   default:'【porter:neutral】最前面三个是洗锅的。我替他们把袖口擦过了，不会弄湿你们的灯。'
  }},
  results:[
   {flag:'daily_delivery_3_0',bond:2,heal:3,text:`【host:neutral】三个一批。到第一个结，先停一下。

【guest:neutral】灯稳了，下一批可以上。

{DAILY:delivery_1}

【stage】最后一个影子站在桥边，等前面的回头。

【porter:neutral】它是在等我。我每次把它送到门口就跑。

【host:neutral】那你这回送到底。灯我们替你拿。

【porter:smile】行。饭盒一会儿再刷。

【guest:neutral】绳子还给你，三个结，一个没少。

【porter:neutral】先别走，灶上还有热汤。你们一人一碗。

【host:smile】这回喝真的。

【porter:smile】知道，影子那两碗另外盛。

【guest:neutral】你的呢？

【porter:neutral】放柜上了。

【host:neutral】端过来。我们坐着，你站旁边看，喝不下去。

【porter:neutral】哦。那我把围裙摘了，都是洗碗水。`},
   {flag:'daily_delivery_3_1',bond:2,heal:3,text:`【host:neutral】三个一批，跟着饭盒走。别抢，后边还有路。

【guest:neutral】我转灯了。停一下，前面那位鞋跟还没过去。

{DAILY:delivery_1}

【porter:neutral】全过去了，可以关灯——

【host:neutral】等等。你背后那道，也是来下班的？

【porter:neutral】那是我的。

【guest:smile】你自己都没下班，着什么急。

【stage】阿钉看了看红绳，把饭盒放到一边。

【porter:neutral】不送了，吃饭。热汤还在，我给你们盛。

【host:neutral】盒子呢？

【porter:smile】泡着。今天先泡着。

【guest:neutral】这汤里还是半根葱？

【porter:neutral】今天有萝卜。我切的，有几块大了点。

【host:smile】给我。大的也不收你加工钱。

【porter:neutral】别逗了，趁热喝。`},
   {flag:'daily_delivery_3_2',bond:2,heal:3,text:`【host:neutral】过去一个，敲一下盒子。别替后面的敲！

【guest:neutral】灯我稳着，你慢慢数。

{DAILY:delivery_1}

【stage】盒子响到第七下，第八下迟迟没来。

【porter:neutral】少一个。最后那个是不是——

【host:neutral】它没手，正拿头顶盒底。你把盒子放低点。

【stage】咚。最后一个影子也过去了。

【guest:smile】齐了。关灯吧，这次真齐了。

【porter:neutral】你们把红绳卷好，我去端汤。灶上留了两碗热的。

【host:neutral】你呢？

【porter:smile】我喝第三碗。今天葱放够了。

【guest:neutral】凳子拖过来，就坐这儿。

【porter:neutral】我衣服还湿，怕沾你们身上。

【host:neutral】都湿了一晚上了。坐吧，汤快凉了。`},
   {flag:'daily_delivery_3_3',bond:2,heal:3,text:`【host:neutral】边走边敲，别停在中间。后边的影子也有脚！

【guest:neutral】灯跟得上，你喊慢一点。

{DAILY:delivery_1}

【stage】阿钉提着最后一只饭盒，跟到廊尾。

【porter:neutral】到了。今晚这顿，给还没吃上的留着。

【host:neutral】都下班了，还送给谁？

【porter:neutral】守灯的。我们走了，总得有人把灯关好。

【guest:neutral】那给它留一碗，我们在这儿等。

【stage】三个人坐到灶旁，分了锅里的热汤。

【porter:smile】我头一回不是端着饭往外跑。

【host:smile】那先坐稳。你凳子下面还压着红绳。

【porter:neutral】好，收起来。明天还用。

【guest:neutral】明天别忘了找人轮班。

【porter:neutral】会找。找的时候我就坐这儿问，谁来谁先喝汤。`}
  ]
 }
];
})(window.GAME_DATA);
