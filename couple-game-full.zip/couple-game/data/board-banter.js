/* Short board reactions. This module never mutates a run, its counters or its RNG.
 * boardBanter(a, trigger, actor, target) -> one Chinese line.
 * actor: host/guest, class id, enemy uid/id, or the corresponding unit object.
 * Canonical actor keys (host/guest/uid) are preferred by the authoritative caller.
 * For deliberate rotation, call boardBanter.key(trigger, actor), read the line,
 * then increment that key in combat.presentation.counts after emitting it.
 * Repeated reads and previews are pure; no counters are initialized here.
 */
(function(root){
'use strict';
const lines={
 blade:{
  push:[
   '别挤我同伴。地方不够，我给你往那边腾一点。',
   '刀还没出鞘呢，你先替我试试那边的地结不结实。',
   '说了借过你不听，现在好了，连路费都省下了。'
  ],
  trap:[
   '别看我，看脚下。算了，你现在想看也来不及了。',
   '我同伴放的东西，你最好用脚好好表示一下尊重。',
   '刚才谁嫌这机关寒酸？现在怎么站着不肯走了。'
  ],
  slide:[
   '看见没有，这地比我还急着送你去那边站着。',
   '站稳再瞪我，省得一会儿又说我专挑你没准备。',
   '我就推了那么一下，后头这段路是地板自己加的。'
  ],
  barrel:[
   '桶的脾气比我还差。你往后站，别跟它讲道理。',
   '刚才那声不是我吼的。记账的时候别全算我头上。',
   '这桶也太不禁碰了，回头搬东西的活儿别叫我。'
  ],
  dodge:[
   '我没躲，我是过来看看你这边有没有人添乱。',
   '打空气都打这么响，真碰上我，你嗓子受得了吗。',
   '别急着夸我，先确认你自己也站到安全的地方了。'
  ],
  collision:[
   '别往我这边倒。我同伴还站着呢，你换个方向丢人。',
   '这墙也挺横啊，连句借过都不听，有我当年的脾气。',
   '撞这么响还装没事？行，嘴硬这门手艺你也学会了。'
  ],
  coop:[
   '接得不错。别笑，我夸人就这一次，你好好记着。',
   '我把麻烦送过去，你还给我这么大一份惊喜。',
   '先别松手，等站稳了再说刚才谁配合得更漂亮。'
  ]
 },
 warden:{
  push:[
   '慢一点，我是让你离远些，没让你去撞人家的墙。',
   '请你挪一挪。礼貌的话说完了，接下来我真推了。',
   '别堵着路，后面还有人。对，就是我护着的那个人。'
  ],
  trap:[
   '我提醒过脚下了。你要是不听，机关可没我耐心好。',
   '站着别动，越挣越紧。这句是关心，笑是没忍住。',
   '放得挺稳，就是位置缺德。算了，对面也没客气过。'
  ],
  slide:[
   '鞋底沾油了吧？我就说出门得多带一块擦地布。',
   '慢一点，前面有墙。你们怎么都只听我说的前半句。',
   '这地得找人修。打完我去说，不能天天这么接客。'
  ],
  barrel:[
   '都退后，别围着看。这个桶炸起来可不认熟人。',
   '我数三下再点火。谁刚才已经把一二三全省了？',
   '东西坏了可以赔，人都站远一点，先别惦记桶。'
  ],
  dodge:[
   '站这里，我看过了。你不放心的话，我再看一遍。',
   '我护着你，不代表我就得站在原地让它白打。',
   '你看，少挨一下就少喝一口那种苦得要命的药。'
  ],
  collision:[
   '你自己撞上来的啊。我这回真没把门往你脸上关。',
   '怎么又撞墙？墙不会让路，我刚才已经替你问过了。',
   '撞完记得看一眼后头，别把你的同伴也带倒了。'
  ],
  coop:[
   '接住了。下回提前说一声，虽然我多半还是接得住。',
   '原来有人替我守着后头，是这么让人省心的事。',
   '配合得不错，等打完了你再教教我刚才那一下。'
  ]
 },
 weaver:{
  push:[
   '借你一点力气，不用还。落在哪儿就看你自己了。',
   '别紧张，我们只是觉得你站的位置不太适合挨打。',
   '往那边一点，谢谢。你这么听话，早说多好呀。'
  ],
  trap:[
   '别急着抬脚，另一只也看看。我是好心，真的。',
   '你踩得真准，省得我们还得琢磨怎么请你过去。',
   '机关做得粗糙了些，委屈你亲自替我们验一验。'
  ],
  slide:[
   '慢慢来，地上没有人跟你抢。墙就更不会跑了。',
   '你走得这么流畅，我都不好意思提醒你刹一下。',
   '别怕丢脸，先把人站稳。刚才那段我们会记住的。'
  ],
  barrel:[
   '先离远一点，烧坏衣服我能补，烧掉脾气可难缝。',
   '这一桶挺热情的，就是招呼客人的声音大了些。',
   '闻到焦味先看自己，别忙着夸对面烤得很均匀。'
  ],
  dodge:[
   '空招就不用替你缝了吧？它看起来也没有受伤。',
   '你慢慢打，我往旁边挪一点，大家都不用太辛苦。',
   '刚才躲得很好，等会儿请继续保持，我能少拆点线。'
  ],
  collision:[
   '疼就说出来，墙听不懂，我还是能帮你笑小声些。',
   '两位站得这么亲近，是打算省下一份伤药钱吗。',
   '别怪墙，是你先过去的。它连往后退的地方都没有。'
  ],
  coop:[
   '你把人送得很准，我这回连针都不用多找一根。',
   '刚好接上。下次你放心一点，别把肩膀绷这么紧。',
   '我们两个人这么懂事，对面多少得自己想想办法。'
  ]
 },
 seer:{
  push:[
   '这个位置不好。主要是对你不好，我们就不换了。',
   '刚才算了一下，你往后退，比我们往前走省事。',
   '我看见你下一步了。别惊讶，那一步是我推的。'
  ],
  trap:[
   '这机关的命中率不高，幸好你愿意主动帮它。',
   '你看，地上写的危险两个字，有时候真的只是提醒。',
   '本来还在担心布置太明显，看来是我高估了你。'
  ],
  slide:[
   '路线算好了，没算鞋底。下回把地板也请来开会。',
   '多走一格没加钱，算这里难得不坑人的服务。',
   '刚才那步不在计划里，不过计划现在已经承认了。'
  ],
  barrel:[
   '这是附近最有意见的桶，而且它只发表一次意见。',
   '原来解决分歧这么简单，点一下，大家就散开了。',
   '离远一点，我能看见下一秒，不能替你长回眉毛。'
  ],
  dodge:[
   '这里比较安全。证据就是你刚才在那里打了个空。',
   '它提前把要打哪儿画出来了，我们最好表示感谢。',
   '刚才那个位置已经不适合居住，我建议立刻搬家。'
  ],
  collision:[
   '墙的意见已经表达得很清楚了，建议你认真听。',
   '两个撞在一起，至少说明你们对路线的判断一致。',
   '这次没算错距离，只是忘了距离中间还有一堵墙。'
  ],
  coop:[
   '刚才算的是两个人。你在，所以这一次没有算错。',
   '我负责想，你负责让想法成真。听着比一个人省事。',
   '下次还按这个来，至少我们现在有一次成功经验。'
  ]
 },
 monster:{
  push:[
   '我自己会走！你们问都不问就给我换地方站着？',
   '等一下，我刚站稳，为什么你们又替我安排方向？',
   '有事好好说，怎么聊着聊着就把我聊到这边来了？',
   '你们两个能不能先商量完，再决定往哪边推我？'
  ],
  trap:[
   '谁把这东西放路中间的？你们自己来走一次试试！',
   '我就停一下，没说要在这里一直站到你们打完！',
   '等会儿再动手，我先看看这玩意到底从哪儿解开。',
   '不是，这机关刚才还没有吧？你们当着面放的？'
  ],
  slide:[
   '停一下！我是来拦路的，怎么现在变成自己找路了！',
   '地上这么滑，你们开门做生意也不立个提醒的牌子？',
   '我想停在刚才那一格，谁允许这地板替我多走的？',
   '别笑了！等我站稳了再打，刚才那段不许算进去！'
  ],
  barrel:[
   '谁把会炸的东西当普通木桶放着，这不是坑人吗？',
   '我跟那个桶又不熟，它炸的时候为什么非得叫上我？',
   '能不能给我个准话，这附近还有几个会响的桶？',
   '刚才那个声儿把我吓的，我准备好的狠话全忘了！'
  ],
  dodge:[
   '我都瞄了半天了，你们怎么还能一边聊天一边躲？',
   '站回去，我那一下准备得挺久的，至少让我打完吧！',
   '谁让你们挪开的？我刚才明明记得人就在这儿啊！',
   '不是说两个人一起行动吗，怎么躲的时候也这么齐？'
  ],
  collision:[
   '墙在那里你们看不见吗？看见了还专门往这儿推？',
   '别往我身上倒，我也没站稳，你当我是柱子啊？',
   '刚才谁说这边宽敞的？出来，我给你也安排一下。',
   '这下我知道墙有多硬了，你们能不能换个人问？'
  ],
  coop:[
   '一个把我送过去，一个在那儿等，你们平时就这样？',
   '两个人还打配合，给我一点时间找个帮手行不行？',
   '你们关系好也不用拿我证明吧，我已经看出来了！',
   '打完再互相夸行不行，我还在中间站着听呢！'
  ]
 },
 fallback:{
  push:['先让出一点地方，再看看这一推能把麻烦送到哪里。'],
  trap:['机关已经替大家开口了，这回最好认真看一眼脚下。'],
  slide:['地板多送了一段路，站稳以后再决定要不要道谢。'],
  barrel:['这只桶的脾气实在太急，劝架之前最好先站远一点。'],
  dodge:['先从危险的地方挪开，没说完的话留着等会儿再聊。'],
  collision:['路到这里忽然有了意见，撞上的那位已经听清楚了。'],
  coop:['一个人把机会递过去，另一个人刚好伸手接住了。'],
  default:['先看清彼此站在哪里，这座城总会留出下一步的路。']
 }
};
const triggers=new Set(['push','trap','slide','barrel','dodge','collision','coop']);
const own=(o,k)=>!!o&&Object.prototype.hasOwnProperty.call(o,k);
const normTrigger=t=>triggers.has(t)?t:'default';
const actorKey=actor=>typeof actor==='string'?actor:actor&&typeof actor==='object'?String(actor.uid||actor.role||actor.cls||actor.id||'unknown'):'unknown';
function identity(a,actor){
 const key=actorKey(actor),players=a?.players||{},enemies=a?.combat?.enemies||[];
 const unit=typeof actor==='object'&&actor?actor:own(players,key)?players[key]:enemies.find(e=>e.uid===key||e.id===key);
 const cls=unit?.cls||(own(lines,key)&&!['monster','fallback'].includes(key)?key:null);
 if(cls&&own(lines,cls)&&!['monster','fallback'].includes(cls))return cls;
 if(unit&&enemies.some(e=>e===unit||unit.uid&&e.uid===unit.uid||unit.id&&e.id===unit.id))return 'monster';
 if(key==='monster'||unit?.hero===false)return 'monster';
 return 'fallback';
}
function safeInt(value){return typeof value==='number'&&Number.isFinite(value)?Math.max(0,Math.floor(value)):0;}
function hash(value){let n=0;for(const ch of String(value))n=(n*31+ch.codePointAt(0))>>>0;return n;}
function keyFor(trigger,actor){return 'board:'+actorKey(actor)+':'+normTrigger(trigger);}
function boardBanter(a,trigger,actor,target){
 const kind=normTrigger(trigger),voice=identity(a,actor),pool=lines[voice]?.[kind]||lines.fallback[kind]||lines.fallback.default;
 const p=a?.combat?.presentation,counts=p?.counts,key=keyFor(trigger,actor);
 const explicit=own(counts,key)&&typeof counts[key]==='number'&&Number.isFinite(counts[key]);
 const cursor=explicit?safeInt(counts[key]):safeInt(a?.combat?.board?.round??a?.combat?.turn)+safeInt(p?.seq);
 // Keep each speaker's enemy reactions independent. Target affects only the
 // starting offset; caller-supplied counters advance one line at a time.
 const offset=hash(actorKey(actor)+'|'+actorKey(target)+'|'+kind);
 return pool[(cursor+offset)%pool.length];
}
for(const voice of Object.values(lines)){for(const pool of Object.values(voice))Object.freeze(pool);Object.freeze(voice);}Object.freeze(lines);
boardBanter.key=keyFor;
boardBanter.lines=lines;
root.boardBanter=boardBanter;
})(typeof window!=='undefined'?window:globalThis);
