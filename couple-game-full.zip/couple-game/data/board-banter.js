/* Short board reactions. This module never mutates a run, its counters or its RNG.
 * boardBanter(a, trigger, actor, target) -> one Chinese line.
 * actor: host/guest, class id, enemy uid/id, or the corresponding unit object.
 * Canonical actor keys (host/guest/uid) are preferred by the authoritative caller.
 * For deliberate rotation, call boardBanter.key(trigger, actor), read the line,
 * then increment that key in combat.presentation.counts after emitting it.
 * Repeated reads and previews are pure; no counters are initialized here.
 */
(function(root){
'use strict';
const lines={
 "blade": {
  "push": [
   "挪开。我得过去。",
   "后退，别踩我鞋。",
   "就这点分量？再远点。"
  ],
  "trap": [
   "踩实了？那别动。",
   "你忙，我先拔刀。",
   "我就说那块地能用。"
  ],
  "slide": [
   "哎，还没停呢。",
   "这油谁洒的？干得好。",
   "站不住就别瞪我了。"
  ],
  "barrel": [
   "耳朵还嗡嗡响。",
   "早知道拿刀挑远点。",
   "我只碰了一下！"
  ],
  "dodge": [
   "差点。就差点而已。",
   "慢了，再练练。",
   "别看了，我没伤着。"
  ],
  "collision": [
   "这一声可真脆。",
   "撞晕了？省我事了。",
   "再退呀，怎么不退了。"
  ],
  "coop": [
   "行，这刀算你的。",
   "送得正好，省得追了。",
   "还有吗？照这样来。"
  ]
 },
 "warden": {
  "push": [
   "让让，我转不过盾。",
   "往后点。对，再一点。",
   "我还没使劲呢。"
  ],
  "trap": [
   "卡住了吧。",
   "别扭，越扭越紧。",
   "这个夹子还挺牢。"
  ],
  "slide": [
   "慢点，前头到头了。",
   "我得把油擦了。打完再擦。",
   "鞋底沾上了，别踩过来。"
  ],
  "barrel": [
   "都退后！碎木头会扎人。",
   "桶没了。应该不用赔吧。",
   "我盾上怎么多了块桶箍？"
  ],
  "dodge": [
   "这边空，过来。",
   "躲过去了。省一口药。",
   "你也没挨着吧？"
  ],
  "collision": [
   "没散架吧？",
   "这声音，我听着都疼。",
   "别倒过来，我还没站稳。"
  ],
  "coop": [
   "我拦住了，快打。",
   "你够得着吧？",
   "准。再往这边送一个。"
  ]
 },
 "weaver": {
  "push": [
   "往那边去，别碰我线。",
   "肩膀借我使一下劲。",
   "挺沉。你昨晚吃什么了？"
  ],
  "trap": [
   "老实站会儿。",
   "先别挣，省得我再捆。",
   "夹子比我打的结还牢。"
  ],
  "slide": [
   "脚收好，别带倒别人。",
   "鞋底擦擦，地上全是油。",
   "慢着——算了，追不上了。"
  ],
  "barrel": [
   "袖子收回来！",
   "烫着没？先别摸。",
   "头发焦了。你的。"
  ],
  "dodge": [
   "躲得不错，线省下了。",
   "胳膊收回去就没事。",
   "我刚让你挪的时候不挪。"
  ],
  "collision": [
   "别瞪了，先站稳。",
   "这回真得揉一会儿了。",
   "我听着都疼。"
  ],
  "coop": [
   "按住，线快勒紧了。",
   "还挺顺。就照刚才来。",
   "别撒手，再给我一下。"
  ]
 },
 "seer": {
  "push": [
   "两步。不，一步就够。",
   "站错地方了，换这里。",
   "现在推，来得及。"
  ],
  "trap": [
   "位置没算错。",
   "它居然真踩了。",
   "夹住了，先别靠近。"
  ],
  "slide": [
   "算漏了这块油。",
   "还要滑？我得重算。",
   "比我想的多了一步。"
  ],
  "barrel": [
   "比预计响多了。",
   "火星出来了，退！",
   "嗯，下回再站远点。"
  ],
  "dodge": [
   "这次提前了半步。",
   "等它收手再回来。",
   "我就知道——还好赶上了。"
  ],
  "collision": [
   "到头了。别推第二下。",
   "距离没错，后头没看。",
   "差一格，正好撞上。"
  ],
  "coop": [
   "就是这个位置。",
   "早半拍也行，赶上了。",
   "别换位置，还能来一次。"
  ]
 },
 "monster": {
  "push": [
   "它踉跄着退开，刚要扑回来。",
   "它想抓住地面，没抓牢。",
   "它回过头，才发现自己挪了位置。",
   "它站稳以后，死死盯着推它的人。"
  ],
  "trap": [
   "它猛地一挣，铁夹纹丝不动。",
   "它开始撕扯夹住自己的机关。",
   "它挣不开，冲你们叫了一声。",
   "它顾不上你们了，先跟夹子较劲。"
  ],
  "slide": [
   "它往前扑，自己先滑了出去。",
   "它越想停，滑得越远。",
   "它扒着地面，又滑出一截。",
   "它站起来，发现还在往后滑。"
  ],
  "barrel": [
   "火光一闪，它缩了回去。",
   "木屑粘了它一身。",
   "它抖掉碎木头，动作慢了不少。",
   "它转头去找那只桶，桶已经没了。"
  ],
  "dodge": [
   "它扑了个空。",
   "它猛地回头，又找了一遍。",
   "它伸得太远，一下没收住。",
   "它冲着原来的位置又补了一下。"
  ],
  "collision": [
   "咚。它停了。",
   "它撞到墙上，半天没转过来。",
   "它刚站住，又被顶了一下。",
   "它贴着墙，找不着退路。"
  ],
  "coop": [
   "它刚转向一个人，另一个又动手了。",
   "它试图挡住两边，慢了一步。",
   "它挣脱这边，另一边已经到了。",
   "它盯着刚才那个人，没防住身后。"
  ]
 },
 "fallback": {
  "push": [
   "目标被推开了。"
  ],
  "trap": [
   "陷阱合上，目标动不了。"
  ],
  "slide": [
   "踩上油地，又滑了一格。"
  ],
  "barrel": [
   "木桶炸开了，碎片飞向四周。"
  ],
  "dodge": [
   "这一击打空了。"
  ],
  "collision": [
   "撞到了，退不动了。"
  ],
  "coop": [
   "另一位旅伴跟上了攻击。"
  ],
  "default": [
   "先看看脚下。"
  ]
 }
};
const triggers=new Set(['push','trap','slide','barrel','dodge','collision','coop']);
const own=(o,k)=>!!o&&Object.prototype.hasOwnProperty.call(o,k);
const normTrigger=t=>triggers.has(t)?t:'default';
const actorKey=actor=>typeof actor==='string'?actor:actor&&typeof actor==='object'?String(actor.uid||actor.role||actor.cls||actor.id||'unknown'):'unknown';
function identity(a,actor){
 const key=actorKey(actor),players=a?.players||{},enemies=a?.combat?.enemies||[];
 const unit=typeof actor==='object'&&actor?actor:own(players,key)?players[key]:enemies.find(e=>e.uid===key||e.id===key);
 const cls=unit?.cls||(own(lines,key)&&!['monster','fallback'].includes(key)?key:null);
 if(cls&&own(lines,cls)&&!['monster','fallback'].includes(cls))return cls;
 if(unit&&enemies.some(e=>e===unit||unit.uid&&e.uid===unit.uid||unit.id&&e.id===unit.id))return 'monster';
 if(key==='monster'||unit?.hero===false)return 'monster';
 return 'fallback';
}
function safeInt(value){return typeof value==='number'&&Number.isFinite(value)?Math.max(0,Math.floor(value)):0;}
function hash(value){let n=0;for(const ch of String(value))n=(n*31+ch.codePointAt(0))>>>0;return n;}
function keyFor(trigger,actor){return 'board:'+actorKey(actor)+':'+normTrigger(trigger);}
function boardBanter(a,trigger,actor,target){
 const kind=normTrigger(trigger),voice=identity(a,actor),pool=lines[voice]?.[kind]||lines.fallback[kind]||lines.fallback.default;
 const p=a?.combat?.presentation,counts=p?.counts,key=keyFor(trigger,actor);
 const explicit=own(counts,key)&&typeof counts[key]==='number'&&Number.isFinite(counts[key]);
 const cursor=explicit?safeInt(counts[key]):safeInt(a?.combat?.board?.round??a?.combat?.turn)+safeInt(p?.seq);
 // Keep each speaker's enemy reactions independent. Target affects only the
 // starting offset; caller-supplied counters advance one line at a time.
 const offset=hash(actorKey(actor)+'|'+actorKey(target)+'|'+kind);
 return pool[(cursor+offset)%pool.length];
}
for(const voice of Object.values(lines)){for(const pool of Object.values(voice))Object.freeze(pool);Object.freeze(voice);}Object.freeze(lines);
boardBanter.key=keyFor;
boardBanter.lines=lines;
root.boardBanter=boardBanter;
})(typeof window!=='undefined'?window:globalThis);
