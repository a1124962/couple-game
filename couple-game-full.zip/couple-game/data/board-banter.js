/* Short board reactions. This module never mutates a run, its counters or its RNG.
 * boardBanter(a, trigger, actor, target) -> one Chinese line.
 * actor: host/guest, class id, enemy uid/id, or the corresponding unit object.
 * Canonical actor keys (host/guest/uid) are preferred by the authoritative caller.
 * For deliberate rotation, call boardBanter.key(trigger, actor), read the line,
 * then increment that key in combat.presentation.counts after emitting it.
 * Repeated reads and previews are pure; no counters are initialized here.
 */
(function(root){
'use strict';
const lines={
 "blade": {
  "push": [
   "滚开点，挡着我了。",
   "走你——哎，还挺沉。",
   "往那边去，别往我身上扑。"
  ],
  "trap": [
   "夹住了？这回你再跑。",
   "哟，脚拔不出来了吧。",
   "别急，我过来了。"
  ],
  "slide": [
   "哎哎哎，还滑呢？",
   "这油泼得好，谁干的？",
   "别瞪我，地又不是我擦的。"
  ],
  "barrel": [
   "靠！这桶怎么会炸！",
   "谁说空桶没事的？",
   "耳朵嗡嗡的。你说什么？"
  ],
  "dodge": [
   "没打着，气不气？",
   "就这？……靠，差点。",
   "看我干吗，接着打啊。"
  ],
  "collision": [
   "哎哟，这声听着都疼。",
   "墙在那儿，你非往上撞。",
   "行了，别退了，没地儿了。"
  ],
  "coop": [
   "漂亮！再给我送一个。",
   "来得正好，我正想揍它。",
   "别撒手，我补一下。"
  ]
 },
 "warden": {
  "push": [
   "借过。……借不过就算了。",
   "往后站，别挤着人。",
   "别碰我后头那个。"
  ],
  "trap": [
   "夹住了，别贴过去。",
   "手别伸，连你一块儿夹。",
   "它自己踩的，我可没动。"
  ],
  "slide": [
   "别跟过去，地上都是油。",
   "这地脏的，打完还得擦。",
   "停不住了吧，刚才跑挺快。"
  ],
  "barrel": [
   "低头！木片飞过来了。",
   "桶谁的？先说好，我没钱。",
   "等会儿，盾上扎了根木头。"
  ],
  "dodge": [
   "这边，站我后头。",
   "你没挨着吧？给我看看。",
   "躲开就行，别回去较劲。"
  ],
  "collision": [
   "嘶……听着都硌牙。",
   "别倒这边，砸着人了。",
   "好了，堵住了，你来。"
  ],
  "coop": [
   "我顶着呢，赶紧的。",
   "这个角度够得着不？",
   "行，照刚才那样再来。"
  ]
 },
 "weaver": {
  "push": [
   "往边上去，我线要断了。",
   "还挤？这儿没你地方。",
   "挺能吃啊，推都推不动。"
  ],
  "trap": [
   "老实待着，别费我线。",
   "再挣，把另一条腿也夹了。",
   "哟，刚才不是挺能跑吗。"
  ],
  "slide": [
   "你们当心，鞋底全是油。",
   "停——行，当我没说。",
   "别拽我，我可拽不住你。"
  ],
  "barrel": [
   "袖子！先把袖子收回来！",
   "先别摸，烫着呢。",
   "头发糊了。不是我，是你。"
  ],
  "dodge": [
   "这回知道躲了？",
   "手收回去，别欠那一下。",
   "早这么躲，我能省半瓶药。"
  ],
  "collision": [
   "脸别往墙上蹭，疼不疼啊。",
   "哎哟，牙还在不在？",
   "先别爬起来，省得又挨一下。"
  ],
  "coop": [
   "按着点，我这儿快好了。",
   "对，就这样，别乱动。",
   "还差一口气，你给它补上。"
  ]
 },
 "seer": {
  "push": [
   "就推这里，信我一回。",
   "两步。不，一步够了。",
   "它背后没路，推。"
  ],
  "trap": [
   "这么大个夹子，它没看见？",
   "别碰，我也不知道怎么开。",
   "嗯，这次算对了。"
  ],
  "slide": [
   "坏了，忘了算地上那摊油。",
   "怎么还滑？都过了。",
   "我说的一步，不包括这一下。"
  ],
  "barrel": [
   "声音不对，离远点！",
   "比我想的大。大多了。",
   "下回我肯定站后面。"
  ],
  "dodge": [
   "看吧，我就——好险。",
   "等一下，它还没收手。",
   "差半步。差得有点少。"
  ],
  "collision": [
   "到墙了，别再推了。",
   "我只算了前面。忘了后面。",
   "正好撞上。这个真是我算的。"
  ],
  "coop": [
   "现在打！对，就现在。",
   "早了点。没事，也打着了。",
   "别挪，还能再来一下。"
  ]
 },
 "monster": {
  "push": [
   "它四脚乱蹬，没站住。",
   "它伸手去抓，抓了把空气。",
   "它刚扑上来，又被推回去了。",
   "它扭头瞪着你，鼻子里直喷气。"
  ],
  "trap": [
   "咔。它立刻尖叫起来。",
   "它咬住铁夹，咬出一嘴铁锈。",
   "它一通乱挣，夹子没开。",
   "它低头跟夹子较上劲了。"
  ],
  "slide": [
   "它扑过头，四脚朝天滑了出去。",
   "脚蹬得越快，它滑得越远。",
   "它扒了两下地，没刹住。",
   "它刚站起来，又滑了个跟头。"
  ],
  "barrel": [
   "轰！它缩着脖子往后蹦。",
   "它浑身是木屑，连嘴里都有。",
   "它甩了甩脑袋，没找着你们。",
   "它还想踢那只桶，桶没了。"
  ],
  "dodge": [
   "它扑了个空，差点栽地上。",
   "它咬了口空气，牙磕得直响。",
   "它伸手太猛，自己踉跄了一下。",
   "它朝原地又打了一下，还是空的。"
  ],
  "collision": [
   "咚。墙没事，它有事。",
   "它撞墙后转了一圈，方向更乱了。",
   "它刚站稳，又挨了一下。",
   "它背贴着墙，还想往后挪。"
  ],
  "coop": [
   "它刚挡住这边，后脑勺又挨了一下。",
   "它两头都想挡，一头也没挡住。",
   "它刚挣脱，就又被按住了。",
   "它只顾瞪你，漏了你旁边那位。"
  ]
 },
 "fallback": {
  "push": [
   "推开了，再往前跟。"
  ],
  "trap": [
   "夹住了，趁现在。"
  ],
  "slide": [
   "脚下打滑，又溜了一格。"
  ],
  "barrel": [
   "桶炸了，离碎片远点。"
  ],
  "dodge": [
   "没打着，躲过去了。"
  ],
  "collision": [
   "撞墙了，退不动。"
  ],
  "coop": [
   "搭档赶上来补了一击。"
  ],
  "default": [
   "当心脚底下。"
  ]
 }
};
const triggers=new Set(['push','trap','slide','barrel','dodge','collision','coop']);
const own=(o,k)=>!!o&&Object.prototype.hasOwnProperty.call(o,k);
const normTrigger=t=>triggers.has(t)?t:'default';
const actorKey=actor=>typeof actor==='string'?actor:actor&&typeof actor==='object'?String(actor.uid||actor.role||actor.cls||actor.id||'unknown'):'unknown';
function identity(a,actor){
 const key=actorKey(actor),players=a?.players||{},enemies=a?.combat?.enemies||[];
 const unit=typeof actor==='object'&&actor?actor:own(players,key)?players[key]:enemies.find(e=>e.uid===key||e.id===key);
 const cls=unit?.cls||(own(lines,key)&&!['monster','fallback'].includes(key)?key:null);
 if(cls&&own(lines,cls)&&!['monster','fallback'].includes(cls))return cls;
 if(unit&&enemies.some(e=>e===unit||unit.uid&&e.uid===unit.uid||unit.id&&e.id===unit.id))return 'monster';
 if(key==='monster'||unit?.hero===false)return 'monster';
 return 'fallback';
}
function safeInt(value){return typeof value==='number'&&Number.isFinite(value)?Math.max(0,Math.floor(value)):0;}
function hash(value){let n=0;for(const ch of String(value))n=(n*31+ch.codePointAt(0))>>>0;return n;}
function keyFor(trigger,actor){return 'board:'+actorKey(actor)+':'+normTrigger(trigger);}
function boardBanter(a,trigger,actor,target){
 const kind=normTrigger(trigger),voice=identity(a,actor),pool=lines[voice]?.[kind]||lines.fallback[kind]||lines.fallback.default;
 const p=a?.combat?.presentation,counts=p?.counts,key=keyFor(trigger,actor);
 const explicit=own(counts,key)&&typeof counts[key]==='number'&&Number.isFinite(counts[key]);
 const cursor=explicit?safeInt(counts[key]):safeInt(a?.combat?.board?.round??a?.combat?.turn)+safeInt(p?.seq);
 // Keep each speaker's enemy reactions independent. Target affects only the
 // starting offset; caller-supplied counters advance one line at a time.
 const offset=hash(actorKey(actor)+'|'+actorKey(target)+'|'+kind);
 return pool[(cursor+offset)%pool.length];
}
for(const voice of Object.values(lines)){for(const pool of Object.values(voice))Object.freeze(pool);Object.freeze(voice);}Object.freeze(lines);
boardBanter.key=keyFor;
boardBanter.lines=lines;
root.boardBanter=boardBanter;
})(typeof window!=='undefined'?window:globalThis);
