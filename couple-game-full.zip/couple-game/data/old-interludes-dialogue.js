/* Short dialogue for the nine optional interactions. Branches, clues and rewards stay intact. */
(function(G){
'use strict';
if(G.oldInterludeDialogueOriginals)return;
const lines=(...rows)=>rows.join('\n\n');
const edits={
 inspect_1:{
  stage:{background:'workshop',cast:[]},
  text:lines('【stage】路牌的箭头冲右，字却写着“钟楼向左”。抽屉还在夹桌腿。','【host:neutral】这地方能不能有一样东西是正常的？','【guest:neutral】有。收据上还欠两条鱼，很正常。','【host:neutral】我说路。','【guest:neutral】看背面啊，玛拉把路写背面了。'),
  spots:[
   lines('【host:neutral】背后写了：箭头被潮水拧了，字没错。面向钟楼，左边鱼市，右边废码头。','【guest:neutral】幸好没听你的。你刚说往右走。','【host:neutral】谁让它画那么大一个箭头。'),
   lines('【guest:neutral】背对大海，经过鱼市，进挂三个空瓶的小巷。就这条。','【host:neutral】下面还欠两条鱼，签的是个零。','【guest:neutral】你别应啊！让你认路，没让你认账。'),
   lines('【stage】蟹横着挪开，地上露出一串通往鱼市的脚印。','【host:neutral】让让，借个道。','【guest:neutral】它还真让了？','【host:neutral】没有，它在夹我鞋。拿根棍来！')
  ],
  success:lines('【host:neutral】三个空瓶，没错，门就在这儿。','【guest:neutral】还有张告示：别再把箭头掰回去。','【host:neutral】我就说嘛，肯定不止我一个想掰。','【guest:neutral】这有什么好得意的？推门。'),
  fail:lines('【host:neutral】死路。要不翻墙？','【guest:neutral】你包都过不去。回去看收据，别折腾了。')
 },
 inspect_2:{
  stage:{background:'workshop',cast:[]},
  text:lines('【host:neutral】它说，你那句“我没事”是真的，咱俩已经沟通成功了。','【guest:neutral】它知道个屁。前面那条呢？','【host:neutral】没印。','【guest:neutral】后面那条也没印吧？就这还收钱？把纸摊开，我给你看。'),
  spots:[
   lines('【host:neutral】晚上十点：“我没事，你先忙。”下面盖了个“沟通成功”。','【guest:neutral】日期呢？章把日期都盖了，拿灯照照。'),
   lines('【host:neutral】前面是“医院打来电话，我不知道怎么办”。你那会儿在等消息？','【guest:neutral】嗯，手机攥了一晚上。后头还有一条，没发出去。','【host:neutral】“算了，明天再说。”你该叫我的。','【guest:neutral】我知道。那天就是没说出口。'),
   lines('【guest:neutral】售后写了：只保证原话不假，不保证事情说全。','【host:neutral】它怎么好意思？','【guest:neutral】后头还有“完整记录请问本人”。问我不就完了，白花这钱。')
  ],
  success:lines('【guest:neutral】三行都装上，一张不少。','【host:neutral】这个“沟通成功”的章还留吗？','【guest:neutral】留着。下次它再胡说，拿这个堵它出纸口。'),
  fail:lines('【host:neutral】门把纸吐回来了。','【guest:neutral】少了两条当然不认。把折角扒开，别光信那个章。')
 },
 inspect_3:{
  stage:{background:'laundry',cast:[]},
  text:lines('【host:neutral】“从未分开证明”？这玩意儿也能补办？','【guest:neutral】还包邮吗？','【host:neutral】你正经点。','【guest:neutral】我很正经啊。钥匙都退过一回了，它怎么算咱俩没分开？看看小字。'),
  spots:[
   lines('【guest:neutral】旧钥匙圈的断口都锈了，换的这个还亮着。','【host:neutral】对。还钥匙的时候用的旧圈，拿回来以后才换。','【guest:neutral】你还嘴硬，说一直没换过。'),
   lines('【host:neutral】这张是退钥匙，这张是取钥匙。中间隔了好久。','【guest:neutral】日期写着呢。两张都留，别把旧的当废纸扔了。'),
   lines('【host:neutral】小字写着：“允许删除与证明不符的记忆。”','【guest:neutral】我就知道没好事。笔给我，别签。','【host:neutral】没签，我在划那行字。')
  ],
  success:lines('【host:neutral】退的在前，拿回来的在后。中间就空着？','【guest:neutral】不然呢，咱俩那会儿又没在一块儿。','【host:neutral】行。照实交，别让它乱补。'),
  fail:lines('【host:neutral】退回来了，还多给个夹子。什么意思？','【guest:neutral】让你把两张都夹上啊。不是纸越少越好，拿来。')
 },
 puzzle_1:{
  stage:{background:'workshop',cast:[]},
  text:lines('【host:neutral】我这块全是符号，钟、鱼、破伞。你呢？','【guest:neutral】推哪扇门。你念，我找。','【host:neutral】你别先推啊。','【guest:neutral】我没推！门把手自己过来了。你快点。'),
  success:lines('【host:neutral】钟，然后鱼。','【guest:neutral】左门！帮我顶一下，这把手怎么老往回弹？','【stage】门开了，干燥的补给箱滑到两人脚边。','【host:neutral】行，没白折腾。箱子抬走，门留给下一个倒霉蛋。')
 },
 puzzle_2:{
  stage:{background:'laundry',cast:[]},
  text:lines('【host:neutral】那边三个你，哪个是真的？','【guest:neutral】有个替我收袜子呢。要不把活留给它？','【host:neutral】少来。纸条上的暗号还记得吧？','【guest:neutral】记得。你说，我听着。'),
  success:lines('【host:neutral】咖啡凉了也别倒。','【guest:neutral】杯子还要洗。行，过来吧。','【stage】镜门打开。三个倒影还在抢同一只袜子。','【host:neutral】要不劝劝？','【guest:neutral】不用。它们爱洗就洗，反正不是我的。')
 },
 puzzle_3:{
  stage:{background:'workshop',cast:[]},
  text:lines('【host:neutral】这儿连垃圾桶都分三种？','【guest:neutral】那叫归档口。你念卷宗，我翻分类。','【host:neutral】签名有俩，后头……','【guest:neutral】别“后头”了，念全！漏一行又得排队。'),
  success:lines('【host:neutral】签名齐，最后还没填。','【guest:neutral】送未结口。好了，走。','【host:neutral】等会儿，笔是不是让它卷进去了？','【guest:neutral】你耳朵上夹着呢。快走，后面有人瞪你了。')
 },
 duo_1:{
  stage:{background:'kitchen',cast:['mara','quill']},
  text:lines('【mara:neutral】我去讨个账，帮我看七分钟。','【host:neutral】不是，你怎么连围裙都给我套好了？','【mara:neutral】怕你跑。罗婶来了，招呼着。我的晚饭别卖！','【stage】罗婶递来两个饭盒，隔着灶台说了一长串要求。','【guest:neutral】我只听清“两份饭”和“千万别”。别什么啊？','【host:neutral】等一下，我也在记。'),
  results:[
   lines('【host:neutral】两份都挑刺，鱼头朝里面。','【guest:neutral】你别在外头喊快了，我眼睛快挑瞎了！灯举过来。','【mara:neutral】我才走七分钟，你把镊子都找出来了？','【guest:neutral】你不是说不能砸招牌吗？','【mara:neutral】行，工钱拿着。鱼干再拿一包，这个不用挑刺。'),
   lines('【guest:neutral】装鱼饼吧，没刺也没鱼头。','【host:neutral】她问鱼去哪儿了。','【guest:neutral】我剁了。你就这么说。','【host:neutral】说完了。她尝了一口，让再装一份。','【mara:neutral】行啊，替我卖光了。工钱在盒里，别连盒子也顺走。'),
   lines('【guest:neutral】挑刺哪有这么快？你把“马上好”给我收回去。','【host:neutral】罗婶，要不您坐——哎，凳子自己带了？','【quill:neutral】她家那位换鞋要半小时，这点儿不算事。茶呢？','【mara:neutral】七分钟给我开出个茶馆。行，鱼没糊，工钱照给。'),
   lines('【guest:neutral】鱼饼热好了，两盒都没刺。','【host:neutral】罗婶拿了。后头五个也说照样来。','【quill:neutral】那我呢？','【host:neutral】您不是来等玛拉还书的？','【quill:neutral】书又不能当饭。添一勺。')
  ]
 },
 duo_2:{
  stage:{background:'workshop',cast:['holt']},
  text:lines('【holt:neutral】钟又停了。谁会修？','【host:neutral】我瞅瞅。','【stage】摊主朝街口喊：“修钟的来了！”一圈人立刻围了过来。','【guest:neutral】你会个屁啊，刚才自己表带都扣不上。','【host:neutral】我说瞅瞅，没说会！你去后头看看，我拖着。','【holt:neutral】先别拆，装不上我可赔不起。'),
  results:[
   lines('【host:neutral】小毛病，我们熟得很。','【guest:neutral】锅扶稳……接住了！','【stage】蟹落进锅里，钟摆晃了起来。','【holt:neutral】拿锅修的？我记一下。','【host:neutral】您别往外传。','【holt:neutral】晚了，旁边卖锅的全听见了。来喝汤吧。'),
   lines('【host:neutral】我这搭档厉害，听声就能修。','【stage】锅响两下，钟里的蟹敲了三下。','【guest:neutral】少吹两句，它真跟我聊上了！','【host:neutral】那就聊，先把它哄出来。','【holt:neutral】出来了！这汤给你们。下回我这儿坏了，还找你俩。','【guest:neutral】……你看你吹的。'),
   lines('【host:neutral】不是钟坏了，是里面那位想搬家。','【guest:neutral】新家在底下，锅这么大，你下来试试。','【stage】蟹爬进锅里，转头夹起自己的倒影。','【holt:neutral】又吵上了？','【host:neutral】嗯，它嫌室友长得丑。汤我们端走了啊。'),
   lines('【stage】两下锅声，三下蟹钳声。','【holt:neutral】你不是懂它吗？说什么了？','【host:neutral】有口音，没听清。','【guest:neutral】出来了！别扯了，把锅端稳。','【holt:neutral】钟走了就行。汤在后头，喝完把锅还人家。')
  ]
 },
 duo_3:{
  stage:{background:'bathhouse',cast:['pip','mara','quill','holt','quiet']},
  text:lines('【pip:neutral】生日是不是想哪天过，就哪天过？','【guest:neutral】你想今天？','【pip:neutral】明天你们可能走了。','【mara:neutral】那就今天。吃面还是鱼饼？','【pip:neutral】奎尔也留下吗？','【quill:neutral】吃完再走。别盯着我了，挪张凳子来。'),
  results:[
   lines('【pip:neutral】鱼饼蛋糕上还撒葱啊？','【host:neutral】没奶油，将就一下。来，唱！','【stage】赫尔特起高了，玛拉跟不上，奎尔非要从头重来。','【pip:neutral】行了行了，别唱了！','【guest:neutral】嫌难听？','【pip:neutral】蜡烛都烧到鱼上了！'),
   lines('【pip:neutral】玛拉最好，卖鱼从来不缺斤。','【mara:neutral】这话能不能出门再说？','【pip:neutral】奎尔也好，说坐五分钟，现在坐了半小时。','【quill:neutral】你再磨蹭，鱼饼就凉透了。','【pip:neutral】最后这俩，明年还得来。我换个奖给你们。'),
   lines('【pip:neutral】他们是不是忘了谁过生日？','【guest:neutral】赫尔特都唱到自己名字了，你先吃。','【host:neutral】明天那份给你盖好了，别今晚一起吃完。','【pip:neutral】我能闻闻吗？','【host:neutral】闻吧。手里的筷子先放下。'),
   lines('【pip:neutral】我先说两句，今天——','【mara:neutral】面要坨了。','【pip:neutral】那我说一句。你们走之前来喊我。','【guest:neutral】喊你干吗？','【pip:neutral】我送你们。哪条路近，我不告诉别人。')
  ]
 }
};
const originals={};
for(const [id,edit] of Object.entries(edits)){
 const d=G.interludes.find(d=>d.id===id);
 if(!d)throw new Error('Missing original interaction: '+id);
 if(edit.results&&edit.results.length!==d.results.length)throw new Error('Interaction result count changed: '+id);
 if(edit.spots&&edit.spots.length!==d.spots.length)throw new Error('Interaction evidence count changed: '+id);
 originals[id]=JSON.parse(JSON.stringify(d));
}
for(const [id,edit] of Object.entries(edits)){
 const d=G.interludes.find(d=>d.id===id);
 for(const key of ['text','success','fail','stage'])if(edit[key]!=null)d[key]=edit[key];
 if(edit.results)edit.results.forEach((text,i)=>d.results[i].text=text);
 if(edit.spots)edit.spots.forEach((text,i)=>d.spots[i][1]=text);
}
G.oldInterludeDialogueOriginals=originals;
})(window.GAME_DATA);
