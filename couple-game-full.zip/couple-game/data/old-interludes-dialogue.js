/* Dialogue staging for the nine existing interactions; answers, choices,
 * private clues, rewards and persistent flags remain the same. */
(function(G){
'use strict';
if(G.oldInterludeDialogueOriginals)return;
const lines=(...rows)=>rows.join('\n\n');
const edits={
 inspect_1:{
  stage:{background:'workshop',cast:[]},
  text:lines('【stage】路牌、收据、抽屉。抽屉正在夹桌腿。','【host:neutral】牌上写钟楼向左，箭头朝右。','【guest:neutral】先别转它。上回你转地图，我们多走了半条街。','【host:neutral】那张地图本来就是倒的。','【guest:neutral】是你倒着拿的。','【stage】抽屉伸出一只蟹钳。','【host:neutral】这位会认路吗？','【guest:smile】不知道。先让它松开桌子。'),
  spots:[
   lines('【host:neutral】背面有字：箭头被潮水拧转，文字没变。','【guest:neutral】还有呢？','【host:neutral】面向钟楼正门，左边鱼市，右边废弃码头。','【guest:neutral】记文字。别记它现在指哪儿。'),
   lines('【guest:neutral】玛拉的鱼摊收据。背对大海，经过鱼市，进挂三个空瓶的小巷。','【host:neutral】背面还欠两条鱼。署名是个零。','【guest:neutral】我看路线，你别顺手认账。'),
   lines('【stage】蟹横挪一步，露出一串朝鱼市去的脚印。','【host:smile】谢谢，借过。','【stage】蟹又挪回来。','【guest:neutral】先别谢。它在堵你另一只脚。')
  ],
  success:lines('【host:neutral】鱼市到了。三个空瓶，都在。','【guest:neutral】这就是钟楼外墙。','【host:neutral】墙上还挂着牌：别再把箭头拧回去。','【guest:smile】你刚才伸手的时候，我就想拦你。','【host:neutral】我只是想扶正。','【guest:smile】别人可能也是这么想的。'),
  fail:lines('【stage】巷子尽头只有一堵墙。','【host:neutral】敲一敲？','【guest:neutral】敲过了。疼的是我的手。','【host:neutral】那回去。再看一次收据。','【guest:neutral】这次别跟着蟹走。')
 },
 inspect_2:{
  stage:{background:'workshop',cast:[]},
  text:lines('【stage】道歉机吐出一张记录，章盖得比字还大。','【host:neutral】它说，你那句“我没事”是真的。','【guest:neutral】它把前面那行拿出来没有？','【host:neutral】这张只有一句。','【guest:neutral】后面那行呢？','【host:neutral】也没有。','【guest:neutral】把纸角展开。先别替我按“你说得都对”。','【host:smile】我是在看哪个按钮能退钱。'),
  spots:[
   lines('【host:neutral】晚上十点：“我没事，你先忙。”','【guest:neutral】下面那个大章是什么？','【host:neutral】沟通成功。','【guest:neutral】日期都盖住了，先把章边折开。'),
   lines('【host:neutral】前面是：“今天医院打来电话，我不知道怎么办。”','【guest:neutral】后面也读。','【host:neutral】“消息没发出去。算了，明天再说。”','【guest:neutral】我当时一直捏着手机。你只看见中间那句。'),
   lines('【guest:neutral】售后写：保证每句话单独读有道理，不保证拼起来还是原来的事。','【host:neutral】这也能写在售后里？','【guest:neutral】最后一句是“完整记录请问本人”。','【host:neutral】那我现在问你。纸先留着。')
  ],
  success:lines('【host:neutral】三行一起放进去？','【guest:neutral】嗯，纸角别折回去。','【stage】机器伸出夹子，试图再盖一次章。','【host:neutral】不用，别碰日期。','【guest:smile】它好像还挺不乐意。','【host:neutral】让它歇会儿。我们自己带去。'),
  fail:lines('【stage】镜门退回纸条，只映出中间那句话。','【guest:neutral】还是缺。','【host:neutral】把那两个折角都展开。','【guest:neutral】这回别让章把它们盖住。')
 },
 inspect_3:{
  stage:{background:'laundry',cast:[]},
  text:lines('【stage】失物柜台摆着钥匙、两张收据和一叠空白证明。','【host:neutral】“从未分开证明”。这也能补？','【guest:neutral】先看下面的小字。','【host:neutral】字怎么越往下越小。','【guest:neutral】把灯挪近一点。钥匙也给我。','【host:neutral】你认得这把？','【guest:neutral】认得。这个旧圈断的时候，刮过我的手。'),
  spots:[
   lines('【guest:neutral】旧钥匙圈的断口生锈了，新圈还是亮的。','【host:neutral】换圈以前，钥匙还回去过。','【guest:neutral】后来才拿回来。不是一直带着。'),
   lines('【host:neutral】第一张，退钥匙。第二张，取钥匙。','【guest:neutral】念一下日期。','【stage】两个日期隔得很远，落款都是你们。','【host:neutral】得分开放。别夹成同一天的收据。'),
   lines('【host:neutral】“允许删除与证明不符的记忆。”','【guest:neutral】笔放下。','【host:neutral】我还没写。','【guest:neutral】我知道。先把证明翻过去，看看有没有别的条款。')
  ],
  success:lines('【host:neutral】退的在前，取的在后。','【guest:neutral】中间空着。','【host:neutral】就这么交？','【guest:neutral】就这么交。那段时间本来就不在一起。','【stage】柜台收下两张收据，零号档案的日期对上了。'),
  fail:lines('【stage】材料从柜台下退回来，多了一枚回形针。','【host:neutral】没过。','【guest:neutral】两张收据都拿出来。','【host:neutral】我怕纸太多。','【guest:neutral】现在还好，它连夹子都给了。')
 },
 puzzle_1:{
  stage:{background:'workshop',cast:[]},
  text:lines('【stage】两块铭牌钉在侧门两边，中间隔着一个转角。','【host:neutral】我这边是图例。你那边呢？','【guest:neutral】路线表。站远点，我得看清最下面。','【host:neutral】我过来一起看？','【guest:neutral】你一走，谁读你那块？','【host:neutral】行。你别边读边走。','【guest:smile】这次只有三扇门，我走不远。'),
  success:lines('【host:neutral】钟，然后鱼。','【guest:neutral】对上了，左门。','【stage】门后响了一声，两个人同时抓住门把。','【host:neutral】你推，我扶着，别又弹回去。','【guest:smile】开了。里面的补给箱还是干的。','【host:neutral】先拿补给。那张牌我一点也不想再看。')
 },
 puzzle_2:{
  stage:{background:'laundry',cast:[]},
  text:lines('【stage】晾衣廊的镜面亮起，转眼多出六个人影。','【host:neutral】你在哪边？','【guest:neutral】晾衣杆后面。我这边有三个你。','【host:neutral】我这边也有三个。其中一个已经开始替我收袜子了。','【guest:neutral】先别跟它走。看我们写的纸条。','【host:neutral】你那张没被镜子照见吧？','【guest:neutral】压在手心里。它们只能看我后脑勺。'),
  success:lines('【host:neutral】咖啡凉了也别倒。','【guest:neutral】杯子还要洗。','【stage】两侧镜门退开，几个倒影还站在原地争抢袜子。','【host:smile】收得这么认真，要不给它们留一双？','【guest:neutral】不留。上回就少一只。','【host:neutral】你怎么一脚深一脚浅？','【guest:neutral】鞋进水了。先借我扶一下。')
 },
 puzzle_3:{
  stage:{background:'workshop',cast:[]},
  text:lines('【stage】归档口分成三格，卷宗和分类册一人一份。','【host:neutral】我读卷宗，你查放哪格。','【guest:neutral】慢一点。这个分类册还夹着去年的账单。','【host:neutral】账单也要交？','【guest:neutral】不是我们的。别什么纸都往里塞。','【host:neutral】签名在这儿，后面还有一栏。','【guest:neutral】你把那栏读完，我再选。'),
  success:lines('【host:neutral】签名齐，最后的决定还没填。','【guest:neutral】未结口。我扶着，你放。','【stage】卷宗被收进去，门锁一格格松开。','【host:neutral】它把笔也卷走了？','【guest:smile】没有，在你袖口。','【host:neutral】别告诉别人。就剩这点体面了。')
 },
 duo_1:{
  stage:{background:'kitchen',cast:['mara','quill']},
  text:lines('【mara:neutral】我去隔壁讨账。七分钟。','【host:neutral】鱼摊呢？','【mara:smile】现在归你们。钱在盒里，别卖我的晚饭。','【guest:neutral】我进灶台，你接客。她写的备菜单我拿着。','【stage】罗婶提着两只饭盒过来，隔着蒸汽报了一长串要求。','【host:neutral】我听见了。你那边听清没有？','【guest:neutral】只听见“两份”和“千万别”。你得告诉我别什么。','【quill:neutral】我等玛拉还书。','【host:neutral】那您为什么拿着碗？','【quill:smile】等多久不好说。'),
  results:[
   lines('【host:neutral】两份都挑刺，鱼头朝里面。','【guest:neutral】别催，最后一根。你帮我把灯举稳。','【quill:neutral】我来发号。一号罗婶，二号还是罗婶，她有两个盒。','【stage】罗婶验过鱼肉，合上饭盒付了钱。','【mara:neutral】我回来一看，还以为你们在给鱼做手术。','【guest:neutral】刺挑完了。','【mara:smile】工钱拿好。鱼干也拿着，别饿得把镊子吃了。'),
   lines('【host:neutral】没刺，头也不朝着您。','【stage】鱼饼落进盒里，罗婶找了一圈鱼头。','【guest:neutral】鱼在饼里。头没放。','【quill:smile】这份肯定不会看您。','【stage】罗婶尝了一口，把第二只盒也推了过来。','【mara:neutral】谁把鱼饼卖得这么快？','【host:smile】没有动您晚饭。','【mara:smile】算你们记得。工钱，还有鱼干。'),
   lines('【host:neutral】很快！马上好！','【guest:neutral】你进来看一眼。我才挑完一边。','【host:neutral】罗婶，对不住，去刺还得等。','【stage】罗婶从袋里掏出折凳，招呼后面的客人也坐。','【quill:neutral】我去拿水。罗婶，刚才您说谁把袜子扔进了汤锅？','【mara:neutral】七分钟不在，你们还添了茶座。','【guest:neutral】鱼好了。','【mara:smile】工钱照给。下回说快之前，先问后厨。'),
   lines('【host:neutral】两份饭，很快。鱼头不单独装。','【guest:neutral】已经热好了，接一下。','【stage】罗婶付钱走了，后面的人都点了鱼饼。','【quill:neutral】我的碗可以用了吗？','【host:neutral】您排在谁后面？','【quill:neutral】我一直站这里。','【mara:smile】我晚饭还在就行。给，工钱。奎尔那碗别算你们头上。')
  ]
 },
 duo_2:{
  stage:{background:'workshop',cast:['holt']},
  text:lines('【holt:neutral】钟不走了。上过弦，这页写着。','【host:neutral】我们看看。','【stage】旁边摊主已经喊出“两位修钟的来了”。','【guest:neutral】你什么时候会修的？','【host:neutral】我说的是看看。你先看后面。','【stage】钟壳里伸出蟹钳。赫尔特把手缩回来。','【holt:neutral】记一下，会夹。已经夹过，不用再试。','【guest:neutral】借来的锅放哪？','【host:neutral】你拿着。我先应付外面。'),
  results:[
   lines('【host:neutral】小问题，我们很懂。','【guest:neutral】锅往里一点……行，接到了。','【stage】蟹落进锅，钟摆重新晃动。','【holt:neutral】拿什么修好的？','【guest:neutral】锅。','【host:smile】您先别往本子上写。','【holt:smile】写完了。锅师傅。先来喝汤，凉了。'),
   lines('【host:neutral】我这位搭档，听声音就知道哪儿有问题。','【stage】锅响两下，钟里的蟹回了三下。','【guest:neutral】你说慢点，它真开始接了。','【host:neutral】我已经说完了。','【stage】蟹爬出钟壳，铃声响起，围观的人拍起手。','【holt:neutral】两下锅，三下蟹。这样记？','【guest:smile】先别记。把汤喝了，蟹我们放回水沟。'),
   lines('【host:neutral】它大概想换地方住。','【guest:neutral】新地方在下面。锅很宽，你下来试试。','【stage】蟹爬进锅，立刻开始夹锅里自己的倒影。','【holt:neutral】它还说什么？','【host:neutral】别给新家装镜子。','【holt:neutral】行，那个小镜片我收起来。','【guest:smile】钟走了。先去喝汤，别让它再钻回去。'),
   lines('【host:neutral】我懂一点它的脾气。','【stage】两下锅声，三下蟹钳声。','【holt:neutral】这句是什么意思？','【host:neutral】有口音，得再听听。','【guest:neutral】出来了！先别翻译，把锅端稳。','【holt:smile】你们听懂没有不要紧，钟能走了。','【guest:smile】喝汤去。它的那份放水沟旁边。')
  ]
 },
 duo_3:{
  stage:{background:'bathhouse',cast:['pip','mara','quill','holt','quiet']},
  text:lines('【stage】海底澡堂的干燥后间，玛拉借来一张矮桌。','【pip:neutral】生日一般先吃，还是先大一岁？','【host:neutral】你想先干哪个？','【pip:smile】吃。今天就能算生日吗？','【guest:smile】大家都在，就今天。','【quill:neutral】我只待五分钟。谁把椅子给我挪一下？','【mara:neutral】鱼饼、面都有，奶油没有。别翻柜子了。','【holt:neutral】今天谁过？我记本上。','【pip:smile】我！写大一点。'),
  results:[
   lines('【pip:neutral】蛋糕上为什么有葱？','【host:neutral】先别拔，蜡烛快倒了。','【stage】大家唱起来，赫尔特第二句开始哼，玛拉拍桌子跟上。','【pip:smile】我许完了，你们可以停了。','【guest:smile】还没唱到后面。','【pip:smile】留明年。明年我还得许一次。','【stage】大家分着吃了鱼饼。玛拉把皮普明天那块单独包好。'),
   lines('【pip:smile】我当主持。先给玛拉发“多装一条鱼奖”。','【mara:neutral】小点声，别让买鱼的听见。','【pip:smile】赫尔特是“写了还是问奖”，奎尔是“五分钟不走奖”。','【quill:neutral】我帮你们收拾完就走。','【guest:smile】我们俩呢？','【pip:neutral】把今天记下来。算你们的奖。','【stage】日期写在干净的纸上，皮普签好名字，才让大家切鱼饼。'),
   lines('【stage】第一遍，赫尔特把寿星唱成了自己。','【pip:smile】不是您！我！','【quill:neutral】重新起。刚才高了。','【mara:neutral】皮普先吃，他们唱熟了再叫你。','【guest:smile】明天那份也装好了。盖子写你名字。','【pip:neutral】给我看看。底下也给我看看。','【host:neutral】怕跑了？','【pip:smile】我就是看看。面很好吃。'),
   lines('【pip:smile】谢谢大家，谢谢凳子，谢谢这盏——','【mara:neutral】先谢谢面。它要坨了。','【pip:neutral】那我边吃边说。奎尔得“本来很忙奖”。','【quill:neutral】我现在也忙。忙着给你递碗。','【guest:smile】奖品归谁？','【pip:smile】先寄我这儿。你们走之前来拿。','【host:neutral】行，走之前来找你。','【stage】皮普把明天的面盒收好，又回来把今天那碗吃干净。')
  ]
 }
};
const originals={};
for(const [id,edit] of Object.entries(edits)){
 const d=G.interludes.find(d=>d.id===id);
 if(!d)throw new Error('Missing original interaction: '+id);
 if(edit.results&&edit.results.length!==d.results.length)throw new Error('Interaction result count changed: '+id);
 if(edit.spots&&edit.spots.length!==d.spots.length)throw new Error('Interaction evidence count changed: '+id);
 originals[id]=JSON.parse(JSON.stringify(d));
}
for(const [id,edit] of Object.entries(edits)){
 const d=G.interludes.find(d=>d.id===id);
 for(const key of ['text','success','fail','stage'])if(edit[key]!=null)d[key]=edit[key];
 if(edit.results)edit.results.forEach((text,i)=>d.results[i].text=text);
 if(edit.spots)edit.spots.forEach((text,i)=>d.spots[i][1]=text);
}
G.oldInterludeDialogueOriginals=originals;
})(window.GAME_DATA);
