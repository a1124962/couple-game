/* Everyday co-op scenes. Load after engine/narrative-ui and before app.js.
 * The long manuscript stays intact; only three optional-style main-route interludes
 * are replaced. The original interludes/openings are retained below for comparison.
 */
(function(G){
'use strict';
if(G.livelyCity?.version===1)return;
const originals={interludes:G.interludes.filter(d=>d.kind==='duo').map(d=>JSON.parse(JSON.stringify(d))),openings:{},events:{}};
const scenes=[
 {
  id:'duo_1',kind:'duo',act:1,title:'玛拉离开鱼摊的七分钟',
  purpose:'一个接单，一个配菜。把各自听见的要求告诉 TA，再决定怎么招呼这位客人。',
  text:'玛拉把围裙塞过来，说去隔壁讨一笔账，七分钟就回来。\n\n「钱在盒里，鱼在锅里。有人问我脾气好不好，你们自由发挥。」\n\n{A}站在摊前，{B}钻进灶台后面。第一位客人已经到了：提着两只饭盒的罗婶，刚从钟楼值完夜班。\n\n她隔着蒸汽说了一长串要求，灶台后面只能听见「两份」和「千万别」。与此同时，锅边压着玛拉的备菜纸，摊前又看不到。\n\n隔壁的奎尔端着空碗挪过来。「我等她还书。」\n\n「您为什么带着碗？」\n\n「等的时间不好说。」她把碗往前推了一点。',
  clues:{
   host:'你在前台。罗婶说：一份给牙不好的老伴，要没刺；自己那份可以慢一点，但别让鱼头正对着她。她今天看够值班人的脸了。她没有催出餐，队伍后面倒是有人不停看锅。',
   guest:'你在灶台后。整鱼刚熟，认真去刺需要一点时间；旁边有玛拉提前做好、已经挑净刺的鱼饼，热一下就能出锅。鱼饼不是废料，但客人还不知道它长什么样。纸条最后写：别把我的晚饭也卖了。'
  },
  options:{host:['答应仔细去刺，鱼头也不对着您','先说能很快出餐，鱼头会另放'],guest:['把整鱼细细拆肉，逐根挑刺','用已经去刺的鱼饼配两份饭']},
  results:[
   {flag:'city_fish_careful',bond:6,gold:14,text:'「两份都会仔细挑过。」{A}答应下来。\n\n灶台后的{B}捏着最后一根小刺，认真得像在拆钟楼的机关。队伍越来越长，奎尔干脆替你们发号：「一号是罗婶。二号也是罗婶，她有两只盒。」\n\n罗婶打开饭盒，鱼头已经转向锅里。她很满意：「这条总算识相。」\n\n玛拉回来时，{A}在收钱，{B}在对着灯找刺，奎尔在问三号昨晚到底跟谁吵了架。\n\n「你们给我开了几种生意？」玛拉把工钱拍进你们手里，又塞来一包鱼干。「这个不算报酬，省得你们饿着继续拆我的鱼。」'},
   {flag:'city_fish_cakes',bond:6,gold:14,text:'{A}刚说完「没有刺」，{B}就端出两块圆圆的鱼饼。罗婶低头看了很久。\n\n「鱼呢？」\n\n「在里面。」\n\n「头呢？」\n\n{A}看向{B}。{B}看向锅。奎尔终于从空碗后面抬头：「罗婶，您不是不想让它看您吗？这份做得很彻底。」\n\n罗婶尝了一口，顺手把另一盒也推过来。「就这个。老头要问是什么鱼，我就说是方的。」\n\n玛拉回来，听见大家叫你们「鱼饼师傅」，先把自己的那份藏进柜子，再发了工钱。你们走时，她嘴上说只送两条鱼干，手上数到了五。'},
   {flag:'city_fish_queue',bond:6,gold:14,text:'「很快就好！」{A}说得十分响亮。灶台后的{B}正在挑第一根刺。\n\n一阵非常有内容的沉默。\n\n{A}探头进去，发现两条鱼都还在。{B}举起镊子：「它长刺的速度比我们吹牛快。」\n\n你们向罗婶说明情况。她反而从袋里掏出凳子：「早说嘛。我只是来买饭，又不是来抓你们。」\n\n奎尔一边替队伍倒水，一边说自己本来还有很多书要整理，随即问罗婶：「所以您说老伴昨天把什么放进洗衣桶了？」\n\n玛拉回来后听了半分钟，认定鱼摊没有亏，故事倒赚了不少。她照发工钱，另塞来鱼干：「下次说很快之前，先看看锅。」'},
   {flag:'city_fish_fast',bond:6,gold:14,text:'{A}说「很快」，{B}已经把热鱼饼盛进两只饭盒。两个人第一次觉得自己可能有点经商天赋。\n\n罗婶却问：「说好的鱼头呢？」\n\n{A}正要找，罗婶摆手：「我只是确认，别单独给我包回来。回家一开盖，四目相对，多累。」\n\n她买得痛快，后面的人也跟着要鱼饼。奎尔端着空碗站到队尾，又很自然地站回队首：「我不是插队。我替玛拉检查库存。」\n\n玛拉回来时，鱼饼卖完了，晚饭还好好留着。她把工钱给你们，又多装了几条鱼干。\n\n「别得意。你们今天卖得快，是因为没轮到我跟人讲价。」'}
  ]
 },
 {
  id:'duo_2',kind:'duo',act:2,title:'你负责吹，我负责接住',
  purpose:'一个向围观的人解释，一个在钟后面处理麻烦。说法和做法可以不同。',
  text:'赫尔特把一只不响的旧座钟抱到镜市，打算找人修。才放下，便有一面镜子用他的声音问：「是不是你又忘记上弦？」\n\n老人低头翻手写本，翻到「已经上弦，别被镜子说服」那一页，抬头很有底气地说：「不是。」\n\n{B}绕到钟后检查。{A}被几位摊主围住，一句「我们看看」刚出口，就被传成了「这两位专修疑难杂钟」。\n\n旁边只有一口从鱼汤摊借来的锅。钟里咔哒一声，伸出一只湿淋淋的蟹钳。\n\n赫尔特赶紧补记：「会夹人。已经夹过。不要再用手确认。」\n\n现在大家都看着{A}，等一句像样的解释。',
  clues:{
   host:'你在钟前。摊主们相信你会修钟，赫尔特只担心钟被拆散后装不回去。你可以吹一句手艺好，也可以说是在请蟹搬家。不要答应换零件：身后真的只有一口锅。',
   guest:'你在钟后。小蟹夹住了钟摆，齿轮并没坏。把锅垫在底下能接住它；敲锅也能让它探头，但它可能跟着敲起来。你听不清前面正在把你夸成什么人。'
  },
  options:{host:['宣布：小问题，我们很懂修钟','宣布：先别急，我懂一点蟹的脾气'],guest:['把锅稳稳垫在钟底，等蟹自己下来','敲敲锅边，请里面那位出来谈谈']},
  results:[
   {flag:'city_clock_pot',bond:6,heal:6,text:'「很懂修钟。」{A}背起手。{B}在后面蹲下，把锅往前挪了半寸。\n\n小蟹松开钳子，咚地落进锅里。钟摆重新晃动，整点铃声响了。\n\n围观的人看得十分敬畏。\n\n「主要用了什么工具？」\n\n「锅。」{B}据实回答。\n\n{A}赶紧补上：「这一行也分流派。」\n\n赫尔特在本上写下「两位锅师傅，修得好」。你们试图解释只修过这一只，他点头，又添一句：「暂时不接第二只。」\n\n鱼汤摊主收回锅，发现里面多了一只蟹，坚决不让你们给工钱。大家坐下喝了一碗热汤，小蟹被放回了水沟。'},
   {flag:'city_clock_band',bond:6,heal:6,text:'{A}正在讲「听声音就知道哪里坏了」，背后突然当当两声。\n\n是{B}敲锅。钟里那只蟹也跟着敲，节奏甚至更稳。\n\n{A}没有回头，硬着头皮说：「现在正在听。」\n\n有人开始拍手。蟹探出半个身子，以为外面开席了，松钳爬出来。钟摆一动，铃声恰好接上。整条街把这当成了结尾。\n\n赫尔特严肃记下「修钟请敲两下，第三下可能收钱」。你们赶紧请他把后半句划掉。\n\n「那写什么？」\n\n「写别照着做。」\n\n他照写了。热汤端上来时，隔壁摊主还在拿勺子敲碗，{B}只好先把锅藏到桌下。'},
   {flag:'city_clock_translator',bond:6,heal:6,text:'「它不是故意的，」{A}说，「它可能想换个地方住。」\n\n钟后的{B}很配合地把锅送到蟹脚下。蟹伸出腿试了试，觉得比齿轮宽敞，立刻搬了进去。\n\n赫尔特盯着你们：「它还说了什么？」\n\n{A}也盯着蟹。蟹正在试图夹自己的倒影。\n\n「说……别给新家装镜子。」\n\n老人认真摘下旁边的小镜片，夹进本子。「这句有道理。」\n\n他把你们记成「能听懂蟹的两位」，还特意画了一只蟹，免得自己忘记字是什么意思。画完有六条腿，{B}替他补了两条。\n\n鱼汤摊主请大家喝汤。你们把蟹送回水边，它头也没回，结束了这场不太准确的翻译。'},
   {flag:'city_clock_dialect',bond:6,heal:6,text:'「我懂一点它的脾气。」{A}刚说完，{B}就在钟后敲了两下锅。\n\n蟹敲了三下。\n\n{B}又敲了两下。蟹索性伸出两只钳子。\n\n「它什么意思？」赫尔特问。\n\n{A}沉默片刻：「有口音。得多听一会儿。」\n\n围观的人笑起来。蟹被热闹勾得爬出钟壳，钟摆终于恢复，{B}趁机用锅接住它，免得它转身再钻回去。\n\n赫尔特在本子上写「有口音」，又问这是说蟹还是说人。你们一致决定给他换一支更好写的笔。\n\n修好的钟响了。老人请你们喝热汤，还替蟹在锅边放了一个小碟：「翻译不准也没事。它确实出来了。」'}
  ]
 },
 {
  id:'duo_3',kind:'duo',act:3,title:'皮普今天最大',
  purpose:'一个准备吃的，一个安排开场。寿星没有标准答案，弄砸了也照样过生日。',
  text:'皮普说他很会过生日，随即问：「一般是先吃，还是先变大一岁？」\n\n他想不起自己的生日。{A}问今天行不行，他立刻点头，又赶紧补了一句：「我本来也是这么打算的。」\n\n玛拉借出船边那块有潮汐灯照着的平台，把一张矮桌擦得发亮。海水挡在灯光外，里面刚好够挤下几张凳子。\n\n奎尔说自己只来五分钟，外套却已经搭在椅背上。赫尔特带着手写本，说这次保证不会记错寿星。静默者抱来茶壶，顺便把五个旧杯垫摆得整整齐齐。\n\n你们分头准备。皮普背着手走来走去，假装视察，已经第三次路过放食物的箱子。',
  clues:{
   host:'你负责吃的。玛拉有去刺鱼饼、热面和一小块能捏成装饰的土豆泥，没有奶油。鱼饼能叠起来装成蛋糕；热面更像一顿家常饭。皮普刚才悄悄问你，可不可以多留一口明天吃。',
   guest:'你负责开场。赫尔特记不住第二句歌词，奎尔坚持自己唱得不难听，玛拉已经明确拒绝独唱。皮普嘴上说不怕丢人，却一直检查大家有没有空椅子留给他。可以一起唱，也可以让他自己当主持。'
  },
  options:{host:['把鱼饼叠成蛋糕，认真插上小蜡烛','煮一大碗热面，另留一小份给明天'],guest:['拉大家一起唱，忘词就哼过去','请皮普主持，给在场每个人发个奖']},
  results:[
   {flag:'city_birthday_fishsong',bond:8,heal:10,text:'鱼饼蛋糕端上来，皮普绕着看了两圈，没舍得问为什么有葱。\n\n歌声一响，他就顾不上葱了。赫尔特唱到第二句开始哼，奎尔主动补词，玛拉嫌两人不在一个调上，干脆拍桌子带节奏。静默者默默把茶杯挪远，保住了桌面。\n\n皮普捂着脸：「我许愿了。你们可以停了。」\n\n「这么快？」\n\n「怕等唱完，愿望就来不及了。」\n\n他笑得肩膀直抖，吹蜡烛时还吹了三次。玛拉把最大一块给他，剩下的分到每个人碗里；赫尔特把今天的日期写进本子，让他亲手画了个圈。\n\n散席时，皮普把留给明天的那块抱得很紧。「下次还这样过。」他想了想，「歌可以练练。」'},
   {flag:'city_birthday_fishaward',bond:8,heal:10,text:'皮普站上矮凳，看着鱼饼蛋糕，清清嗓子：「现在开始发奖。奖品暂时都由我保管。」\n\n他给玛拉发了「最会多装一条鱼奖」，给赫尔特发了「写得最多但还是要问奖」。奎尔正准备鼓掌，听见自己的奖名：「说五分钟却一直不走奖。」\n\n「我那是怕你们收拾不完。」她把椅子往桌边又挪了一点。\n\n静默者领到「最担心桌子湿奖」，低头把杯垫推回茶杯正下方，没有反驳。\n\n轮到你们，皮普忽然卡住。他抓着衣角，最后说：「把今天记下来奖。」\n\n你们把日期写在蛋糕底下那张干净的纸上，留出一个位置，让他签了一个特别大的名字。皮普宣布可以开吃，自己却先把纸折好了。'},
   {flag:'city_birthday_noodlesong',bond:8,heal:10,text:'热面上桌时，皮普立刻坐直。然后歌也开始了。\n\n第一遍，赫尔特把寿星的名字唱成了自己的。第二遍，奎尔说大家起高了。第三遍之前，玛拉把筷子往皮普手里一塞：「你先吃。他们唱熟了再叫你。」\n\n皮普边吃边点头，偶尔很给面子地举一下碗。静默者替他扶着快滑下来的杯垫，另一只手把水递近。\n\n最后大家终于唱到同一个结尾。皮普咽下嘴里的面，认真鼓掌：「这遍好。下回第一遍就唱这遍。」\n\n你们把明天那份装进小盒，盒盖写上他的名字。皮普用指头描了一遍，又把盒子翻过来检查底下。\n\n「我知道不会跑。」他说，「我就是看看。」'},
   {flag:'city_birthday_noodleaward',bond:8,heal:10,text:'皮普端着热面宣布自己是今天的主持人。开场词准备得很长，面也很长。\n\n他先感谢大家，又感谢凳子，最后要感谢潮汐灯的时候，玛拉伸手敲了敲碗：「再谢下去，你就可以感谢面自己把汤喝光了。」\n\n皮普低头一看，立刻宣布吃饭优先。\n\n各个奖项改在嚼东西的间隙发。奎尔得了「本来很忙现在不忙奖」，赫尔特得了「带了本子就值得表扬奖」。静默者听见「杯垫总管奖」，还替自己的杯垫调整了一下位置。\n\n最后皮普给你们一人夹了一根面，说这是「明年还来奖」。\n\n你们没有替未来拍胸口，只跟他约好：离开骨城前，还要再来打声招呼。皮普点点头，把明天那盒饭藏进外套，又忍不住拿出来看了一眼。'}
  ]
 }
];
const flagLabels={
 city_fish_careful:'仔细挑过每根鱼刺',city_fish_cakes:'把鱼做得没机会瞪人',city_fish_queue:'一起招呼过等饭的队伍',city_fish_fast:'留下玛拉的晚饭',
 city_clock_pot:'两位锅师傅',city_clock_band:'修钟修出一支乐队',city_clock_translator:'不太准确的蟹语翻译',city_clock_dialect:'听过带口音的蟹',
 city_birthday_fishsong:'皮普的鱼饼蛋糕合唱',city_birthday_fishaward:'皮普的鱼饼颁奖礼',city_birthday_noodlesong:'皮普边吃面边听歌',city_birthday_noodleaward:'皮普的热面颁奖礼'
};
for(const d of scenes){const at=G.interludes.findIndex(x=>x.id===d.id);if(at>=0)G.interludes[at]=d;}
Object.assign(G.flagNames,flagLabels);
const extraOpenings={
 holt:[
  '赫尔特又从袖口掏出一张折得很小的纸。第一行写「别忘了看袖口」，第二行写「先问来意，不要先问吃了没」。他看完，抬头问你们：「吃了没？」随后很不满意地把纸翻过去。',
  '老人把笔拴在本子上，把本子拴在腰带上。TA 问会不会太重，他想了想：「比忘了轻。」说完又找起笔来。你们没提醒，只把连着笔的绳头轻轻递过去。',
  '赫尔特的手写本比上回厚了。夹进去的纸大小不一，有的背面还是鱼摊的价签。他翻得慢，你们便等着。找到那页时，他先松了口气，才装作本来就知道。'
 ],
 mara:[
  '玛拉说话时一直没停手。你们明明看着她数了两条鱼，纸包合上时却鼓得不像两条。TA 刚开口，她先瞪过来：「大小不一样。少问，拿稳。」',
  '她在秤旁挂了块「不赊账」。皮普一探头，她立刻把牌翻成「小孩先吃」。发现你们看见了，玛拉又翻回去：「看什么？牌也要透气。」',
  '她递来一包鱼干，又从你们手里拿回去。你以为她改了主意，结果她只是嫌包得太少，添了一条才重新系好。「这回拿稳。别逼我第三次送东西。」'
 ],
 quill:[
  '奎尔桌上有一摞待整理的书。她把最上面那本翻到第二页，刚听见门外有人提到鱼市，便拿起杯子：「是谁先说的？我只是核对来源。」杯里其实早没水了。',
  '门口写着「今日务必归还全部借书」。奎尔拿笔在「今日」下面画了一道线，旁边又补了个日期。你仔细看，昨天的日期也在。她把纸翻面：「保存工作痕迹。」',
  '奎尔已经把外套穿好，说今晚一定早走。你们才提起路上出了点事，她又坐下，解开袖口：「说重点。从头说。」'
 ],
 pip:[
  '皮普问你们有没有在市场听见他的名字。你们问是哪件事，他立刻背起手：「也没什么大事。昨天我一个人把那个很紧的罐子拧开了。」停了一下，又说：「玛拉只帮我敲了两下。」',
  '他刚给你们带完路，就很随意地问：「下次还认得我吧？」你还没回答，他又补充：「我很好认。这里数我走路最快。」说完故意慢下来，等你们跟上。',
  '皮普今天把衣角掖得特别整齐。TA 夸了一句，他马上抬起下巴：「平常也这样。」过了一会儿，他小声问，离开这里之前，你们会不会还来跟他说一声。'
 ],
 quiet:[
  '静默者把两只杯子放到你们面前，却迟迟没松手。你们以为还有什么条件，他只是在找杯垫。找到后垫好，才把写着「一切终会消散」的石板重新扶正。',
  '风把一张旧杯垫吹到桌下。静默者俯身去捡，面具差点碰到桌角。TA 替他按住茶壶。他接过杯垫，掸了很久的灰，才继续写那句「不必执着于旧物」。',
  '你们看见他的行李：一件换洗的袍子，一小包茶，以及包得最仔细的那几张旧杯垫。静默者察觉你们的目光，把布包往里收了收，提笔写：「会弄湿。」没有说是怕什么弄湿。'
 ]
};
for(const n of G.npcs)for(const m of n.meetings){
 const key=n.id+':'+m.act;originals.openings[key]=m.nodes.start.text;
 const callback=m.act>1?`{CITY:${n.id}}\n\n`:'';
 m.nodes.start.text=callback+m.nodes.start.text+'\n\n'+extraOpenings[n.id][m.act-1];
}
const fishCallbacks={
 city_fish_careful:'玛拉看见你们，先把镊子收进抽屉。「今天不用挑刺。」她停了一下，「那天罗婶又来了，说你们手稳。夸一次就够了，别指望我转述第二遍。」',
 city_fish_cakes:'玛拉一见你们就喊「鱼饼师傅」。TA 说那是她提前做好的，她摆摆手：「我知道。罗婶不知道。她还问你们能不能把鲨鱼也做得这么圆。」',
 city_fish_queue:'玛拉把两只小凳子踢过来：「坐。别站着说很快就好，听见这句我现在就想检查锅。」她嘴角翘了一下，又低头多装了两条鱼。',
 city_fish_fast:'玛拉从柜子里拿出留给自己的碗，朝你们晃了晃。「没把这份卖出去，我记着呢。」她往你们的纸包里添鱼，嘴上仍说：「记着不等于打折。」'
};
const clockCallbacks={
 city_clock_pot:'赫尔特翻到有锅形小画的那页，立刻把本子合上：「两位锅师傅。」TA 想解释，他摆手：「记得住就行。我这儿记性紧张，称呼先不改。」',
 city_clock_band:'赫尔特见到你们，下意识敲了两下桌子。你们一起摇头。他赶紧翻本子，找到那行「别照着做」，郑重点头，把手收了回去。',
 city_clock_translator:'赫尔特把本子上那只八条腿的小蟹给你们看：「这回没画错。」你们点头。他显得很高兴，又小声问：「水沟那只今天不理我，是不是你们忘了教我什么？」',
 city_clock_dialect:'赫尔特在本子里找到你们，先念了一遍「有口音」，随后自己也笑了。「后来我问过卖鱼的。她说那只蟹从小就住这儿。」'
};
function chosenFlag(a,prefix){return (a?.flags||[]).find(f=>f.startsWith(prefix));}
function callback(a,person){
 const fish=chosenFlag(a,'city_fish_'),clock=chosenFlag(a,'city_clock_'),birthday=chosenFlag(a,'city_birthday_');
 if(person==='mara')return fishCallbacks[fish]||'';
 if(person==='holt')return clockCallbacks[clock]||'';
 if(person==='quill'){
  if(birthday==='city_birthday_fishaward')return '奎尔把「只来五分钟」那张纸从桌上撤了。「皮普那个奖名太长，影响我声誉。」她把它夹进最常用的书，夹得十分平整。';
  if(birthday==='city_birthday_noodleaward')return '奎尔给待办清单添了一行「解释本来很忙现在不忙奖」。她看了两遍，自己笑出来，又把这一行划掉：「算了，今天确实不想忙。」';
  return fish?'奎尔说起鱼摊那天的事，准确记得每位客人讲过什么，唯独不记得自己喝了几碗汤。「别纠结支线。」她把一摞待整理的书往旁边推了推。':'';
 }
 if(person==='pip')return birthday?'皮普还留着生日那天的纸。他说只是纸质不错，随即问你们：上面的名字有没有写得很大。':fish?'皮普已经听玛拉讲过你们看鱼摊的事。他说自己也能做，起码不会把围裙系反。TA 看向你，你决定先问他今天吃了什么。':'';
 if(person==='quiet')return birthday?'静默者把一只杯垫放到你们面前。背面多了一行很小的字：「皮普的生日」。他写完又擦过一次，最后还是留着。':' ';
 if(person==='archive'){
  if(!birthday)return '';
  return birthday.includes('fish')?'卷宗旁还夹着一张带鱼香的纸。皮普的名字写得很大，压住了一点油印。奎尔没让你们换纸：「他认得这张。放着吧。」':'那张装过热面的小盒盖被擦干净，夹进了共同笔记。皮普的名字留在上面。你们翻过去时，都放轻了一点。';
 }
 return '';
}
const archive=G.events.find(e=>e.id==='a3_8_zero_archive');
if(archive){originals.events[archive.id]=archive.text;archive.text+='\n\n{CITY:archive}';}
function resolve(text,a){return String(text||'').replace(/\{CITY:([a-z_]+)\}/g,(_,key)=>callback(a,key)).replace(/^\s+|\s+$/g,'');}
G.livelyCity={version:1,originals,sceneIds:scenes.map(d=>d.id),flagLabels,resolve,callback};
// Each choice combination sets its own persistent fact; no random or inferred callbacks.
const complete=completeScene;
completeScene=function(a,d,text,effects){
 if(scenes.some(scene=>scene.id===d.id)&&!a.interlude.done){
  const result=d.results[a.interlude.picks.host*2+a.interlude.picks.guest];
  if(result?.flag)effects=[...(effects||[]),{op:'flag',k:result.flag}];
 }
 return complete(a,d,text,effects);
};
const format=advText;
advText=function(text){return format(resolve(text,typeof S==='undefined'?null:S.adv));};
// Freeze resolved callbacks when the player puts a conversation into the journal.
// A later playthrough cannot rewrite what happened in an older saved entry.
const reduce=advReduce;
advReduce=function(a,ac,r,names){
 const journalStart=a?.journal?.length||0;
 const value=reduce(a,ac,r,names);
 if(!a)return value;
 for(const entry of a.npc?.trail||[])if(entry.text?.includes('{CITY:'))entry.text=resolve(entry.text,a);
 for(const entry of (a.journal||[]).slice(journalStart)){
  if(entry.text?.includes('{CITY:'))entry.text=resolve(entry.text,a);
  for(const step of entry.trail||[])if(step.text?.includes('{CITY:'))step.text=resolve(step.text,a);
 }
 if(a.npc?.lastText?.includes('{CITY:'))a.npc.lastText=resolve(a.npc.lastText,a);
 return value;
};
// Use the existing private-clue design. Each online role gets only its own text.
const interlude=interludeView;
interludeView=function(a){
 const html=interlude(a),d=G.interludes.find(x=>x.id===a.interlude?.id);
 if(!d?.clues||d.kind!=='duo'||a.interlude.done||!readDone())return html;
 const r=session.role,clue=d.clues[r];if(!clue)return html;
 const panel=`<section class="private-clue lively-clue"><div>${icon('lock')} ${esc(S.players[r].name)}这边的情况</div>${prose(clue,false)}<small>把关键信息告诉 TA。先聊一聊，再各自锁定；配合不一样也有完整后续。</small></section>`;
 return html.replace('<div class="choices">',panel+'<div class="choices">');
};
})(window.GAME_DATA);
