/* The library and the tea stall: dialogue-only revision.
   Branches, requirements and gameplay effects remain in the original manuscript. */
(function (G) {
  'use strict';
  const revisions = {
  "quill": {
    "1": {
      "start": {
        "text": "图书馆门口写着「禁止喧哗」。门后，奎尔正贴着墙听隔壁吵架。\n\n见你们进来，她立刻坐回桌前，拿一本书倒着看。\n\n「请小声。隔壁正在说关键部分。」\n\n她查看你们的卷宗：零号，共同签名，缺了三页。查档需要时间，她先把一张技能卡摆在桌上。\n\n「小交易。写一句自己说过的谎话，换卡。不用大事。」\n\nTA 问：「‘快到了’，其实还没出门，算吗？」\n\n奎尔抽出一大摞纸：「这一类单独占了两个架子。」",
        "labels": [
          "拿笔，写一句小谎话",
          "先查零号档案",
          "翻翻桌边的书"
        ]
      },
      "small_lie": {
        "text": "【quill:neutral】写一句你说过的谎话，换卡。不用写作文。\n\n【host:neutral】现编行吗？\n\n【quill:neutral】不行，我还得收拾假档案。\n\n【guest:neutral】你不是专收谎话？\n\n【quill:annoyed】你说过的谎！两码事，别抬杠。",
        "labels": [
          "写「我很好」",
          "写「我从不害怕」",
          "不写了，把笔放下"
        ]
      },
      "record_good": {
        "text": "【guest:neutral】“我很好。”就这三个字，能换卡？\n\n【quill:neutral】能。昨天还有人断着腿来写这一句。\n\n【host:neutral】你腿边那本怎么不放进去？\n\n【quill:neutral】……私人物品。卡在桌上。",
        "labels": [
          "收下卡牌",
          "问问她藏着的那本书"
        ]
      },
      "record_fear": {
        "text": "【host:neutral】我从不害怕。\n\n【quill:neutral】那把脚边的螃蟹捡出去。\n\n【guest:neutral】我靠，哪来的！\n\n【quill:neutral】行，验过了，是谎话。卡拿着，顺便把蟹弄走，我也不敢碰。",
        "labels": [
          "收下卡牌，绕开螃蟹",
          "问她为什么也怕这东西"
        ]
      },
      "ask_own_lie": {
        "text": "【host:neutral】你自己的谎话，也收吗？\n\n【quill:neutral】收。归档了。\n\n【guest:neutral】那借来看看。\n\n【quill:annoyed】不外借。你们能不能换本书挑？馆里这么多呢。",
        "labels": [
          "不再追问，告别"
        ]
      },
      "fear_door": {
        "text": "【quill:neutral】小时候被夹过，指甲都掉了。别笑，拿杯子帮我扣住它。\n\n【stage:neutral】你们把蟹扣住，旅伴一端杯子，它又跑了。\n\n【quill:annoyed】底下垫个碟子啊！\n\n【guest:neutral】你早说啊！",
        "labels": [
          "帮她捡起书，再离开"
        ]
      },
      "refuse_lie": {
        "text": "【host:neutral】不写了。\n\n【quill:neutral】那卡收回。别画乌龟，这纸真会归档。\n\n【guest:neutral】我才画个头。\n\n【quill:neutral】擦了。还有什么要查的，趁我没收桌子。",
        "labels": [
          "继续问零号档案",
          "离开图书馆"
        ]
      },
      "archive_zero": {
        "text": "【quill:neutral】零号，缺三页。申请原因刮掉了，谁干的？\n\n【host:neutral】我们就是来查这个。\n\n【quill:neutral】签字是你们，出事也找你们，这值的什么破夜班。\n\n【quill:neutral】想再查得看底稿。我有斜灯，你们有人会修复吗？",
        "labels": [
          "用修复师的办法查底稿",
          "收好卷宗，离开"
        ]
      },
      "seer_help": {
        "text": "【host:neutral】照这边，旧字出来了。材料拆开存的，原始记录在海床。\n\n【quill:neutral】你会查这个？那这七本也——\n\n【guest:neutral】停。我们还赶着回家。\n\n【quill:neutral】行行，就这一份。五枚查档费，外加张空白纸，拿着。",
        "labels": [
          "收下查档费和空白纸"
        ]
      },
      "read_page": {
        "text": "【guest:neutral】上面写“不介意”，背后怎么列了两页？\n\n【quill:neutral】嘴上不介意呗。无主副本，要留要烧都行。\n\n【host:neutral】夹着三枚钱。\n\n【quill:neutral】修书的。你连原页一块儿拿走，我可要记账。",
        "labels": [
          "把无主副本烧掉",
          "把书放回原处",
          "撕下书页，连三枚星砂一起拿走"
        ]
      },
      "burn_page": {
        "text": "【stage:neutral】纸往火盆外翘。你们伸手去按，都被盆沿烫了一下。\n\n【quill:annoyed】用火钳！两个大活人，非拿手按？\n\n【guest:neutral】刚才没看见。\n\n【quill:neutral】凉水在这儿。烧剩这张纸也等凉了再拿，求你们了。",
        "labels": [
          "等纸凉透，再收下"
        ]
      },
      "keep_page": {
        "text": "【host:neutral】不动了，放回去吧。\n\n【quill:neutral】行，省得有人回来找，我翻半宿。\n\n【guest:neutral】刚才那第二页——\n\n【quill:neutral】写了什么？\n\n【guest:neutral】没事，你不是忙吗。\n\n【quill:neutral】……现在不忙。",
        "labels": [
          "把书放好，离开"
        ]
      }
    },
    "2": {
      "start": {
        "text": "奎尔的主馆比楼上整齐。你很快知道原因：她把杂物全塞到了访客椅上。\n\n她抱走最上面三本书，露出一本写着「你们」的薄册。\n\n「城里收来的副本。说出口的话在上面，省掉的部分挤在行缝里。」\n\nTA 翻了眼封面：「这也能出书？」\n\n「能，纸不够了才装这么薄。」\n\n奎尔把火盆、笔和卡牌摆开，随后将一本无标题的小册往胳膊下面藏。那册子露出一角，被她用茶杯压住。",
        "labels": [
          "翻开副本",
          "把这本副本烧掉",
          "先问她藏着的那本"
        ]
      },
      "read_open": {
        "text": "【guest:neutral】谁把我们吃饭时说的也记了？烦不烦啊。\n\n【quill:neutral】别问我，城里收来的副本。想改就现在改。\n\n【host:neutral】改一句给多少？\n\n【quill:neutral】“我很好”那项五枚，“我不介意”换卡。不改也行，往后自己看。",
        "labels": [
          "划掉「我很好」，补上实话",
          "划掉「我不介意」，补上实话",
          "一字不改，把全本读完"
        ]
      },
      "read_confession": {
        "text": "【host:neutral】划了怎么还往回长？\n\n【quill:neutral】光划掉有什么用，把后半句写上。\n\n【guest:neutral】这跟当面重说一遍有区别吗？\n\n【quill:neutral】没有。嫌麻烦就到这儿，线索抄录费三枚也能拿。",
        "labels": [
          "写「我怕你离开」",
          "写「我累了」",
          "不再填写，带走线索和抄录费"
        ]
      },
      "read_all": {
        "text": "【guest:neutral】服了。半夜没回消息，它都给我编了个号。\n\n【host:neutral】那晚我睡着了。\n\n【quill:neutral】你们出去再吵。高级卡在这儿，书留下。\n\n【quill:neutral】末页那八枚是修书费。别装没听见，撕走我真记借阅事故。",
        "labels": [
          "收下高级卡牌，让她收书",
          "撕下末页，连八枚星砂一起带走"
        ]
      },
      "burn_open": {
        "text": "【quill:annoyed】慢点扔！你烧自己的副本，别把我一屋子书点了。\n\n【guest:neutral】行，火钳给我。\n\n【quill:neutral】要换卡就写句实话。卖过名字的可以封好灰领五枚补偿。\n\n【host:neutral】烧了就不算数了？\n\n【quill:neutral】你说出去的话，烧本书能收回来？",
        "labels": [
          "写「我总在等你先说」",
          "写「我其实很累」",
          "封好灰烬，领取五星砂补偿"
        ]
      },
      "ask_self": {
        "text": "【guest:neutral】那本为什么藏着？\n\n【quill:neutral】工作资料。\n\n【host:neutral】封面还写“谁都不许看”？\n\n【quill:neutral】我写的工作资料。\n\n【guest:neutral】懂了，问我们的时候你倒挺起劲。\n\n【quill:neutral】……你到底要问什么？",
        "labels": [
          "问：那谁来记录你的谎话？",
          "不追问，先谈换卡",
          "把半块馒头递给她"
        ]
      },
      "self_book": {
        "text": "【quill:neutral】就第一页，后面不能看。\n\n【stage:neutral】书边的墨线缠住了你们的手。奎尔掏出剪刀，又缩了回去。\n\n【host:neutral】你给书上锁，怎么还夹读者？\n\n【quill:neutral】我自己封的。忘了怎么解。\n\n【guest:neutral】那你先别剪！",
        "labels": [
          "忍着墨线勒手，读第一页",
          "合上书，还给她",
          "坚持让她把自己的书烧掉"
        ]
      },
      "self_tear": {
        "text": "【stage:neutral】墨线勒出了红痕。第一页写着“我也害怕”，下面全是日期。\n\n【guest:neutral】你怎么天天记这一句？\n\n【quill:neutral】因为天天都怕。手伸过来，我给你们包一下。\n\n【quill:neutral】今天看到这儿，别往后翻了。你们自己的话，想补就补。",
        "labels": [
          "写「我怕你离开」，记住她这一页",
          "写「我总在等你先说」，不再提这页",
          "不再写了，把手套还她"
        ]
      },
      "card_handover": {
        "text": "【quill:neutral】填一行交换记录，拿稀有卡。不填也能拿普通的。\n\n【guest:neutral】你会偷看吧？\n\n【quill:neutral】我得校对。\n\n【host:neutral】那就是会。\n\n【quill:neutral】……我又不往外说。要不笔给我，我也写一句？",
        "labels": [
          "填写交换记录，拿稀有卡牌",
          "不填写，拿普通卡牌",
          "把笔递给奎尔，请她也写一句"
        ]
      },
      "end_read": {
        "text": "【quill:neutral】哎，椅子底下还有本书，帮我捡一下。\n\n【guest:neutral】给。我们走了。\n\n【quill:neutral】对了，隔壁是不是跟你们说过——\n\n【host:neutral】下次！真得走了。\n\n【quill:neutral】行吧。别把书踩坏，比什么都强。",
        "labels": []
      },
      "end_burn": {
        "text": "【stage:neutral】外面有人问谁家烧东西。奎尔推开窗，刚要回答，对方又问烧了谁的。\n\n【quill:annoyed】关你什么事！\n\n【guest:neutral】你刚才不也想问别人？\n\n【quill:neutral】门给你们开了，赶紧走。",
        "labels": []
      },
      "end_self": {
        "text": "【quill:neutral】“我想早点下班。”……怎么没反应？\n\n【guest:neutral】你自己都不信吧。\n\n【quill:neutral】好吧，有人来，我又不想他们马上走。\n\n【host:neutral】那我们？\n\n【quill:neutral】你们得走，出口还没找着。到了底库来敲门。",
        "labels": []
      }
    },
    "3": {
      "start": {
        "text": "底库进水了。奎尔把书垫在椅子上，自己站在一只倒扣的木箱上收拾行李。\n\n「今天提前关门。」\n\n你们说路上出了点事。她把系好的包又解开：「哪件事？从头说，废话省一点。」\n\n听完，她拿出你们的谎话合集，也拿出自己的那本小册。后者夹着未填完的离馆申请。\n\n「你们的副本到齐了。要整理，就这次一起理清楚。」\n\n水已经漫到箱底，她却还在把那张申请往书里塞。",
        "labels": [
          "把所有隐瞒的内容写完",
          "只写现在愿意说的部分",
          "先看奎尔自己的书",
          "问她最后一页为什么空着"
        ]
      },
      "offer": {
        "text": "【quill:neutral】对上了。零号最早也是你俩写的，看这两个签名。\n\n【host:neutral】这改字的毛病……还真是我。\n\n【guest:neutral】先别认笔迹了，水到鞋了。奎尔，你走不走？\n\n【quill:neutral】最后这一摞。还有杯子。还有——\n\n【guest:neutral】没完了是吧？",
        "labels": [
          "请她带上行李，一起离馆",
          "让她自己决定什么时候走",
          "把整理好的谎话副本烧掉"
        ]
      },
      "refuse": {
        "text": "【quill:neutral】不想写就先停，这本暂时结不了案。\n\n【stage:neutral】木箱晃了一下，三个人同时伸手扶住。\n\n【host:neutral】先搬东西。\n\n【quill:neutral】我自己那本也湿了……算了，你们想先办哪件？",
        "labels": [
          "展开纸，把剩下的话写完",
          "先离开底库",
          "请她先翻自己的书",
          "留下来帮她收拾书页"
        ]
      },
      "read_self": {
        "text": "【guest:neutral】玛拉没还书，皮普乱画，隔壁又吵架。你自己的事呢？\n\n【quill:neutral】后面。\n\n【host:neutral】就两个字，“照常”？\n\n【quill:neutral】不然写什么？我一关门，谁还来找我。\n\n【guest:neutral】所以离馆申请一直没交？",
        "labels": [
          "继续读，帮她把离馆申请写完",
          "合上书，让她留着",
          "递块干布，问她怎么哭了"
        ]
      },
      "ask_tears": {
        "text": "【quill:neutral】布拿反了，脸上全是墨。\n\n【guest:neutral】你先别擦书了，擦脸。\n\n【quill:neutral】我不是舍不得这破库房。关了门，人家有事去哪儿找我？\n\n【host:neutral】你那本地址簿白记的？挨个告诉一声不就行了。\n\n【quill:neutral】……也是。我还真没往这边想。",
        "labels": [
          "陪她把书读完，办理离馆",
          "答应不提这本书，让她收起来",
          "先把你们隐瞒的部分写完"
        ]
      },
      "join_ask": {
        "text": "【stage:neutral】奎尔走出门，又突然折了回去。\n\n【guest:neutral】又怎么了？\n\n【quill:neutral】杯子。锁了门我可不想回来捞。\n\n【quill:neutral】好了，玛拉现在在哪儿？她有本书过期了。\n\n【host:neutral】你就说想找她聊聊呗。",
        "labels": []
      },
      "stay_write": {
        "text": "【quill:neutral】你们先走，我再收这一摞。\n\n【guest:neutral】通往钟楼那条路，别记反了。\n\n【quill:neutral】写下来了。哎，卷宗拿好，差点落我这儿。\n\n【host:neutral】你也快点，水还在涨。",
        "labels": []
      },
      "burn": {
        "text": "【quill:annoyed】早知道要烧，我费什么劲给你们改错字。\n\n【guest:neutral】烧的是副本吧？\n\n【quill:neutral】嗯，去钟楼的原始记录还在卷宗里。别连那个也顺手扔了。\n\n【host:neutral】火我看着，你去拿水吧。",
        "labels": []
      },
      "final_read": {
        "text": "【quill:neutral】离馆原因……“想出去看看”。就这样？\n\n【guest:neutral】就这样。你还想给自己写个奖状？\n\n【stage:neutral】奎尔交了申请，鞋带系到一半，忽然笑了一声。\n\n【quill:neutral】谁来找，就说我出去了，明天也不一定回来。",
        "labels": []
      },
      "final_stay": {
        "text": "【quill:neutral】今天先这样，书我留着。\n\n【stage:neutral】门外有人喊了一声，她立刻转头。\n\n【guest:neutral】去吧，别憋着了。\n\n【quill:neutral】万一是来还书的呢？\n\n【host:neutral】谁问你为什么了。",
        "labels": []
      },
      "last_page": {
        "text": "【host:neutral】最后一页为什么空着？\n\n【quill:neutral】离馆申请。想交的时候总有人来，聊完就晚了。\n\n【guest:neutral】日期都刮穿了，你准备了多少回？\n\n【quill:neutral】别数。沿虚线撕下来就能填，要撕就现在。",
        "labels": [
          "取下申请页，陪她办理离馆",
          "把空白页留在书里",
          "先整理完你们的谎话"
        ]
      },
      "quiet_exit": {
        "text": "【guest:neutral】递过来，湿的放这边。\n\n【stage:neutral】最后一本书里掉出皮普画的小人，戴眼镜，长着八只手。\n\n【quill:neutral】他说我一只手搬书，一只手抄话，还得腾手偷翻别人那页。\n\n【host:neutral】挺了解你。\n\n【quill:neutral】行了，没什么挡路了。你们等我收个包。",
        "labels": [
          "请她带上行李，一起走",
          "让她留在底库",
          "先陪她看完自己的书"
        ]
      }
    }
  },
  "quiet": {
    "1": {
      "start": {
        "text": "白帆底下摆着茶摊，招牌写「忘掉烦恼，首杯免费」。后面坐着戴石面具的静默者。\n\nTA 问：「续杯多少钱？」\n\n他举起石板：「不卖茶。」\n\n隔壁的客人端着空杯，已经第三次问自己为什么坐在这儿。静默者没回答，把两杯茶推过来，补写：「会忘一点小事。想清楚再喝。」\n\n你正要拿杯，他忽然按住杯底。原来杯垫放反了。他仔细翻回来，将磨掉半边的花纹摆正，才肯松手。",
        "labels": [
          "各喝一口茶",
          "把茶推回去",
          "问清楚他为什么劝人遗忘"
        ]
      },
      "drink": {
        "text": "【guest:neutral】挺甜。像那个……叫什么来着？\n\n【host:neutral】你刚才还说想吃，怎么就忘了。\n\n【stage:neutral】静默者收走茶壶，写：“第一杯够了。”\n\n【guest:neutral】靠，真不是吓唬人的。下次给我白水。",
        "labels": [
          "看看他写的用茶说明",
          "放下杯子，离开"
        ]
      },
      "refuse": {
        "text": "【host:neutral】不喝了，你倒回去吧。\n\n【stage:neutral】静默者倒掉茶，把一张破杯垫仔细塞进袖子。\n\n【guest:neutral】你这东西都起毛了，还留着？\n\n【stage:neutral】他按住袖口，没答，拿起石笔等你们问下一句。",
        "labels": [
          "继续问他为什么要忘",
          "离开茶摊"
        ]
      },
      "ask": {
        "text": "【stage:neutral】静默者写：“忘了等谁，就不用天天问邮差。”\n\n【guest:neutral】那信来了呢？\n\n【stage:neutral】他停了一会儿，换了块石板：“如果你们也忘了彼此，就不用再吵。”\n\n【host:neutral】吵两句就劝人拆伙，你这茶摊管得够宽的。",
        "labels": [
          "「我还想让 TA 记得我。」",
          "「我还想跟 TA 过日子。」",
          "不回答这个问题"
        ]
      },
      "remember": {
        "text": "【host:neutral】我还想让这家伙记得我。\n\n【guest:neutral】不然借你的钱找谁要。\n\n【stage:neutral】静默者写：“借据留着。”\n\n【host:neutral】不是，你还真给出主意啊？",
        "labels": [
          "道别，离开茶摊",
          "问喝茶后还能找回记忆吗"
        ]
      },
      "love": {
        "text": "【host:neutral】我还想跟这家伙过日子。\n\n【guest:neutral】那今晚谁洗碗？\n\n【host:neutral】能不能晚点再算这个。\n\n【stage:neutral】静默者把茶换成白水，写：“这个不忘事。”",
        "labels": [
          "谢过白水，离开",
          "问第二壶茶还会忘掉什么"
        ]
      },
      "silent": {
        "text": "【guest:neutral】咱不答也行吧？\n\n【stage:neutral】静默者翻过石板。棚顶一滴水，正落进你领口。\n\n【host:neutral】嘶——先别问了，桶呢？\n\n【stage:neutral】他递来空桶，你们一起把桌子挪到了干处。",
        "labels": [
          "收好东西，告别"
        ]
      },
      "read": {
        "text": "【guest:neutral】第二壶能解乏，也会继续忘事。忘哪件？\n\n【stage:neutral】静默者写：“选不了。”\n\n【host:neutral】那我把回家的路忘了怎么办？\n\n【stage:neutral】他没续茶，指了指说明上的同一句话。",
        "labels": [
          "续一杯，换取恢复",
          "不再喝了"
        ]
      },
      "accept_calm": {
        "text": "【guest:neutral】腿真不酸了。刚才咱俩吵什么来着？\n\n【host:neutral】你说我……等会儿，我也忘了。\n\n【stage:neutral】静默者要拿茶壶，你们一起按住了杯口。\n\n【guest:neutral】够了，不续。",
        "labels": [
          "离开茶摊"
        ]
      },
      "reject_calm": {
        "text": "【host:neutral】不喝了。这个“选不了”，你怎么不写招牌上？\n\n【stage:neutral】静默者把招牌拉回自己膝上。\n\n【guest:neutral】问一句就护着，生怕我们砸摊是吧。\n\n【stage:neutral】他低头拿起石笔，没有再递茶。",
        "labels": [
          "拿好东西，离开"
        ]
      },
      "leave_peace": {
        "text": "【guest:neutral】走了，棚子这边低，你扶一下。\n\n【stage:neutral】静默者抬起帆布，等你们钻出去。\n\n【host:neutral】那只空杯还摆着呢。\n\n【guest:neutral】别动，可能等人。",
        "labels": []
      },
      "leave_cold": {
        "text": "【guest:neutral】以后想解乏，找个凳子坐会儿得了。\n\n【host:neutral】同意。地图给我，下一条往左。\n\n【guest:neutral】右。\n\n【host:neutral】……你拿反了。\n\n【stage:neutral】身后响起石笔刮招牌的声音。",
        "labels": []
      }
    },
    "2": {
      "start": {
        "text": "镜层的殿堂里摆满铜镜，静默者把茶桌搬到正中，桌腿仍有一条短了半寸。\n\nTA 拿起一块旧杯垫想垫桌脚，他立刻伸手拦住，换了一块新石板。\n\n旧杯垫被他放回袖袋，摸过两遍才坐下。\n\n桌上堆着写满字的石板。最近的一块写「不必执着旧物」。你看看石板，又看看他的袖袋，他将那块石板翻了个面。\n\n这次没有端茶。他留出一把椅子，让你们坐近些看。",
        "labels": [
          "看看桌上的石板",
          "先看殿堂里的镜子",
          "问他还记不记得茶摊上的见面"
        ]
      },
      "see_board": {
        "text": "【guest:neutral】正面写让人忘，背面怎么刻着“我想记住”？\n\n【stage:neutral】静默者拿起另一块板想盖住，举到一半停了。\n\n【host:neutral】你自己的？\n\n【stage:neutral】他没点头，也没摇头。桌边的干布刚好能遮住那行字。",
        "labels": [
          "放下石板，读他递来的说明",
          "用干布把那行字盖好"
        ]
      },
      "observe_mirrors": {
        "text": "【host:neutral】镜子里那个我怎么又在赔不是？\n\n【guest:neutral】我这个更怪，出门三趟，一趟没走成。\n\n【stage:neutral】静默者写：“别贴太近。最里面那面是你们的。”\n\n【guest:neutral】还有专门的？我可没订过。",
        "labels": [
          "回到茶桌旁",
          "看完屋顶上的那段画面"
        ]
      },
      "ask_first_meet": {
        "text": "【host:neutral】茶摊上见过，记得吧？\n\n【stage:neutral】静默者翻出登记册，写：“两个人，湿卷宗，问了茶价。”\n\n【guest:neutral】合着不是记得，是查出来的。\n\n【stage:neutral】他低下头，笔停在该写你们名字的地方。",
        "labels": [
          "告诉他：我们也记得你",
          "陪他等一会儿，不再追问"
        ]
      },
      "cover_board": {
        "text": "【guest:neutral】别藏了，我给你盖上。不看。\n\n【stage:neutral】静默者扶住那块石板，写：“谢谢。”\n\n【host:neutral】这儿漏水，往里挪点。\n\n【stage:neutral】他搬开旁边的杂物，给你们空出两个座位。",
        "labels": [
          "坐下，看他接下来要说什么"
        ]
      },
      "mirror_self": {
        "text": "【guest:neutral】饭都凉了，镜子里这俩怎么还不吃？\n\n【host:neutral】等谁先开口呗。看着就来气。\n\n【stage:neutral】静默者写：“没发生的也会照出来，不必当真。”\n\n【guest:neutral】那还行，我不记得自己干过这么蠢的事。",
        "labels": [
          "离开镜子，回到桌旁"
        ]
      },
      "silent_stand": {
        "text": "【host:neutral】这个盆满了，我去倒。\n\n【stage:neutral】回来时，静默者已摆好三张椅子，把旧杯垫摊在桌上。\n\n【guest:neutral】你想让我们看？\n\n【stage:neutral】他写：“放眼前也没用，第二天还是认不出。”",
        "labels": [
          "继续留下，听他的提议"
        ]
      },
      "mirror_offer": {
        "text": "【stage:neutral】静默者把杯垫的半截绣字抄下，请你们收进卷宗，找人认认。\n\n【guest:neutral】这个我们能问。旁边这张路线图呢？\n\n【stage:neutral】他写：“一个名字换一张图。有关的烦恼会少些。”\n\n【host:neutral】名字什么时候还？\n\n【stage:neutral】他又写：“还不了。”",
        "labels": [
          "不交名字",
          "交出名字，带走路线图",
          "先问清楚会失去什么",
          "问他自己是否愿意重来一次"
        ]
      },
      "refuse_offer": {
        "text": "【host:neutral】不换。名字留着。\n\n【stage:neutral】静默者把交易石板翻了过去，写：“知道了，不再问。”\n\n【guest:neutral】还以为你要接着劝。\n\n【stage:neutral】他摇头，把空椅子往外推了一点。走或再坐一会儿，都随你们。",
        "labels": [
          "告别，离开殿堂",
          "再陪他坐一会儿"
        ]
      },
      "sacrifice_name": {
        "text": "【guest:neutral】喂……我刚才想叫你什么来着？\n\n【host:neutral】等会儿，把那块板翻回来！\n\n【stage:neutral】石板两面已经空了。静默者递来路线图，旁边另放了五枚路费。\n\n【guest:neutral】真没了。不是说感觉轻一点吗，怎么连称呼都没了？",
        "labels": [
          "抓住 TA 的袖子，试着想起名字",
          "拿上路线图和五枚星砂，离开"
        ]
      },
      "question_bond": {
        "text": "【guest:neutral】好的坏的，一块儿忘？\n\n【stage:neutral】静默者写：“分不开。”\n\n【host:neutral】那你老护着那破杯垫干什么，自己怎么不扔？\n\n【stage:neutral】他的手按紧袖口，过了一会儿才写：“不知道。就是不想扔。”",
        "labels": [
          "拒绝这笔交易",
          "不交名字，留下陪他一会儿"
        ]
      },
      "ask_himself": {
        "text": "【host:neutral】重来一次，你还交名字吗？\n\n【stage:neutral】静默者写了一个“不”。\n\n【guest:neutral】那你还劝别人？\n\n【stage:neutral】他把交易招牌转向墙，写：“我一直说，过阵子就习惯了。”\n\n【host:neutral】这话你自己信吗？",
        "labels": [
          "请他收起这块招牌，今天别再劝人了",
          "明确告诉他：我们不交名字"
        ]
      },
      "end_refuse": {
        "text": "【guest:neutral】走了，名字还是自己的好。\n\n【stage:neutral】静默者点头，把路线图卷回去。交易招牌仍朝着墙。\n\n【host:neutral】明天别又翻回来啊。\n\n【stage:neutral】他手停了一下，没答。",
        "labels": []
      },
      "end_understand": {
        "text": "【stage:neutral】静默者写：“杯垫，忘了谁缝的。”\n\n【guest:neutral】这线走得挺歪啊。\n\n【stage:neutral】他很快添了句：“用了这么久，没散。”\n\n【host:neutral】行，没说扔。先装好，下次接着找。",
        "labels": []
      },
      "end_sacrifice_cling": {
        "text": "【host:neutral】不行，一想就头疼。刚才还记得的。\n\n【guest:neutral】先停，你脸我认得。袖子抓好了，别再走散。\n\n【stage:neutral】静默者刚走近，你们抬手让他停下。路费还留在桌上。\n\n【guest:neutral】我们自己缓缓。",
        "labels": []
      },
      "end_sacrifice_silent": {
        "text": "【guest:neutral】图和五枚都在。左边，跟上。\n\n【host:neutral】你刚才叫我什么？\n\n【guest:neutral】没叫。我想不起来了。\n\n【stage:neutral】你们走出门，静默者没有再招呼下一位客人。",
        "labels": []
      },
      "end_crack": {
        "text": "【stage:neutral】静默者掀起面具一点，疼得缩回手。下面仍是灰色硬壳。\n\n【guest:neutral】别硬拽，给你布。\n\n【stage:neutral】他接过布，在石板上写：“我连原来长什么样都忘了。”\n\n【host:neutral】先放下。咱不是非得今天全弄明白。",
        "labels": []
      }
    },
    "3": {
      "start": {
        "text": "海床的廊下，静默者正在收行李。袍子和茶叶随手卷着，几张旧杯垫却一层层包在干布里。\n\n他发现你们看见了，想拿笔解释，摸遍口袋也没找到。笔就在他脚边。\n\nTA 替他捡起来。他接过笔，握了很久，没有写字。面具下发出一点含混的声音，他试了两次，都没说完整。\n\n你们放下卷宗。这里没有茶桌挡着，他身边空着一截石阶，可以坐过去，也可以等他自己准备好。",
        "labels": [
          "坐到他旁边",
          "站在原处，等他开口",
          "递一枚星砂，供他借潮汐石写字"
        ]
      },
      "quiet_speak": {
        "text": "【stage:neutral】你们坐下。静默者写：“我参与建城。名字也是自己划掉的。”\n\n【guest:neutral】你干的？现在想找回来了？\n\n【stage:neutral】他点头，翻到背面：“先找什么？”\n\n【host:neutral】你手头还留了哪些东西，拿出来看看。",
        "labels": [
          "先找能证明你是谁的东西",
          "先找愿意和你相处的人",
          "名字和人，都慢慢找"
        ]
      },
      "quiet_wait": {
        "text": "【stage:neutral】静默者终于把石板举起来：“建城的名册，我签过。后来名字自己划的。”\n\n【host:neutral】以为忘完就没事了？\n\n【stage:neutral】他写：“现在每天醒来，连自己的杯子都要看纸条认。”\n\n【guest:neutral】行，那先找。你别把剩下那点东西也扔了。",
        "labels": [
          "先找能证明你是谁的东西",
          "先找愿意和你相处的人",
          "名字和人，都慢慢找"
        ]
      },
      "quiet_stone": {
        "text": "【stage:neutral】星砂嵌进潮汐石。静默者写：“我建过这座城。名字自己划的，我想找回来。”\n\n【guest:neutral】这回字没消失，能留着了。\n\n【host:neutral】你看，事情还没坏透。先查哪一头？\n\n【stage:neutral】他把石板转向你们，等着答复。",
        "labels": [
          "先找能证明你是谁的东西",
          "先找愿意和你相处的人",
          "名字和人，都慢慢找"
        ]
      },
      "quiet_remember": {
        "text": "【stage:neutral】静默者拿出杯垫、纸条和旧钥匙，写：“怕认错，把别人的当自己的。”\n\n【guest:neutral】那就一件件查，别先给自己编个来历。\n\n【stage:neutral】他摸到面具后面的绳结，写：“脸呢？这个结，我够不到。”\n\n【host:neutral】要我们帮你解？",
        "labels": [
          "帮他解开系带，取下面具",
          "暂时不摘，先让他歇会儿",
          "先告诉他赫尔特的事"
        ]
      },
      "quiet_love": {
        "text": "【host:neutral】先找愿意跟你待着的人，不用上来就把老底全交代了。\n\n【stage:neutral】静默者写：“以前有人陪我喝茶。想不起是谁。”\n\n【guest:neutral】那先把你自己认出来。\n\n【stage:neutral】他指了指面具后面打死的结。",
        "labels": [
          "帮他解开系带，取下面具",
          "暂时不摘，先让他歇会儿",
          "先告诉他赫尔特的事"
        ]
      },
      "quiet_both": {
        "text": "【guest:neutral】东西查，人也找。我给你列个单。\n\n【stage:neutral】静默者按住纸，写：“别答应太多，我可能又想躲。”\n\n【host:neutral】那今天只办一件，你挑。\n\n【stage:neutral】他指向面具，又指向旁边的水杯：“先让我喝口水。”",
        "labels": [
          "帮他解开系带，取下面具",
          "暂时不摘，先让他歇会儿",
          "先告诉他赫尔特的事"
        ]
      },
      "quiet_open_face": {
        "text": "【stage:neutral】系带松开，灰壳剥落，下面是一张年轻的脸。\n\n【quiet:neutral】赫尔特……是我祖父。这杯垫，他缝的。\n\n【guest:neutral】守桥那个？他也在找人。\n\n【quiet:neutral】他还找着呢？……名字我还想不全，你再给我讲讲他。",
        "labels": [
          "把他的身份和线索记下来",
          "答应替他给赫尔特带话",
          "告诉他：先喝水，接着慢慢想"
        ]
      },
      "quiet_no_open": {
        "text": "【stage:neutral】你们松开系带。静默者写：“今天先这样。”\n\n【guest:neutral】这张记录放哪儿，你自己选，别下回又找不着。\n\n【stage:neutral】他把纸塞进装杯垫的袋子，补写：“下次不认得你们，就给我看这个。”\n\n【host:neutral】行，日期写上。",
        "labels": [
          "答应下次带着记录来",
          "把今天的话再给他读一遍",
          "答应去找赫尔特核对线索"
        ]
      },
      "quiet_holt_link": {
        "text": "【stage:neutral】听见赫尔特的名字，静默者把杯垫翻了过来，急着写：“我祖父，他缝的。”\n\n【guest:neutral】他也一直在找线索。\n\n【stage:neutral】他又写：“告诉他，我还在。别说全想起来了，我没有。”\n\n【host:neutral】知道。要带什么给他，你放这儿。",
        "labels": [
          "帮他取下面具，继续确认",
          "先不摘面具，让他歇会儿",
          "带着线索，答应给赫尔特传话"
        ]
      },
      "quiet_end_reveal": {
        "text": "【quiet:neutral】脸上是不是全是印子？\n\n【guest:neutral】有一圈。要遮一下吗？\n\n【quiet:neutral】算了，先这么着。\n\n【host:neutral】刚才说的我记了，你看一遍。\n\n【quiet:neutral】嗯。别给我添想不起来的，我自己再慢慢找。",
        "labels": [
          "收好记录，继续去钟楼"
        ]
      },
      "quiet_end_silent": {
        "text": "【stage:neutral】你们刚走出两步，静默者敲响石阶，指向落下的卷宗。\n\n【guest:neutral】哎，差点忘了。谢谢。\n\n【host:neutral】咱还让他记东西，自己先丢了。\n\n【stage:neutral】他把卷宗递来，拍了拍装着记录的小袋。",
        "labels": [
          "收好记录，继续去钟楼"
        ]
      },
      "quiet_end_memory": {
        "text": "【host:neutral】“已经想起来了，准备去找您……”\n\n【stage:neutral】静默者连忙摇头，划掉前半句，改成：“还在找。”\n\n【guest:neutral】行，照实带话。杯垫也带上？\n\n【stage:neutral】他包好杯垫，补写：“别给他垫桌脚。”",
        "labels": [
          "带上口信，继续去钟楼"
        ]
      }
    }
  }
};

  const originals = {};
  let count = 0;
  for (const [npcId, acts] of Object.entries(revisions)) {
    const npc = G.npcs.find(item => item.id === npcId);
    if (!npc) throw new Error(`Missing NPC for scholar dialogue: ${npcId}`);
    originals[npcId] = {};
    for (const [act, nodes] of Object.entries(acts)) {
      const meeting = npc.meetings.find(item => item.act === Number(act));
      if (!meeting) throw new Error(`Missing scholar meeting: ${npcId}/${act}`);
      originals[npcId][act] = {};
      for (const [nodeId, revision] of Object.entries(nodes)) {
        const node = meeting.nodes[nodeId];
        if (!node || node.choices.length !== revision.labels.length) {
          throw new Error(`Scholar dialogue structure changed: ${npcId}/${act}/${nodeId}`);
        }
        originals[npcId][act][nodeId] = JSON.parse(JSON.stringify(node));
        // City callbacks depend on prior visits. Keep the source's exact tokens.
        const callbacks = node.text.match(/\{CITY:[^}]+\}/g) || [];
        node.text = [...callbacks, revision.text].join('\n\n');
        node.choices.forEach((choice, index) => {
          choice.label = revision.labels[index];
          // The UI derives actual effects already; old metaphorical hints mislead.
          if (Object.prototype.hasOwnProperty.call(choice, 'hint')) delete choice.hint;
        });
        count += 1;
      }
    }
  }
  window.NPC_SCHOLAR_ORIGINALS = originals;
  window.NPC_SCHOLAR_REVISION = { version: 1, nodes: count };
})(window.GAME_DATA);
