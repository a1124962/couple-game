/* Short, spoken openings. Long originals and every branch remain available. */
(function(G){
'use strict';
if(G.dialogueScenes)return;
const originals={intro:JSON.parse(JSON.stringify(G.intro)),actIntros:JSON.parse(JSON.stringify(G.actIntros)),openings:{}};
G.intro.title='把卷宗还我！';
G.intro.text=`【stage】刚签下“零号卷宗”，地板就塌了。你们落在骨桥上，一只回声蟹夹走了卷宗。

【host:annoyed】他大爷的，我包还没捡呢！纸给我放下！

【guest:neutral】你踩它钳子了。

【host:annoyed】我还摔了一屁股呢，谁找谁赔啊？

【holt:neutral】回声蟹，跟它讲不通。赶紧拿回来，纸撕了可补不了。

【guest:neutral】行，你上，我堵它。别连我一起打啊。`;
const actTexts=[
`【holt:neutral】卷宗缺三页。外滩钟楼、镜城、海底，一处一页。找齐了去海底钟楼，才能回家。

【host:neutral】那先去外滩。门在哪儿？

【holt:neutral】问卖鱼的玛拉。奎尔能查档案，不过她话多，饿着别去。

【guest:neutral】听见没有？先办事。你要再看热闹，晚饭就啃卷宗吧。`,
`【host:annoyed】靠，镜子里那个把我的话掐了一半！我后头明明还说了——

【guest:neutral】我听见了。先别跟它吵，你越吵它越来劲。

【quill:neutral】第二页在镜影手里。它爱拿半句话唬人，完整记录来主馆查。

【host:neutral】行。我倒要看看，它敢不敢把后半句放出来。`,
`【host:annoyed】拉我一下，鞋拔不出来了！

【mara:neutral】走石阶！我刚喊完，你就往泥里踩，耳朵落船上了？

【guest:neutral】起来。最后一页在海底钟楼，咱们就差这一步。

【mara:neutral】遗忘之神在那儿守着呢。它要拿你们的记忆换原件，别一听“省心”就点头。

【host:neutral】跑了这么远，还要倒贴？走，找它说说。`
];
G.actIntros=G.actIntros.map((d,i)=>({...d,text:actTexts[i]}));
G.chapters.forEach((d,i)=>{d.text=actTexts[i];});
const openings={
holt:[
`【holt:neutral】卷宗拿来，我看看。哎，一个递就行，别往我脸上怼。

【host:neutral】都打了一架了，还得查这个？

【holt:neutral】查。上回有人拿菜单糊弄我，我给四份烤鱼盖了通行章。

【guest:smile】鱼过去了？

【holt:neutral】过去了。还没人给我钱。你俩叫什么？`,
`【stage】赫尔特扶着墙，帽子掉在脚边。

【holt:neutral】第七层，开闸……等会儿，我下来干什么来着？

【host:neutral】找帽子？就在您脚边。

【holt:neutral】不是帽子。有人没过桥，我得……几个人来着？

【guest:neutral】您先坐，别硬撑。喂，听得见我说话吗？`,
`【holt:neutral】往后站，待会儿出水。

【host:annoyed】您可看清楚啊！水位那条线都画到城顶了！

【holt:neutral】看清了。城一沉，名字、账本，一起没。省得找了。

【guest:annoyed】您找不着人，就要把别人全淹了？先把手松开。`
],
mara:[
`【stage】背包勾翻鱼筐。两条鱼掉在脚边，还有一条钻到了猫肚子底下。

【mara:annoyed】站住！谁碰的？

【host:neutral】我就退了半步，没——

【guest:neutral】你包有半个人宽。

【mara:annoyed】行了，鱼捡回来再分谁的锅。那只猫！嘴松开！`,
`【mara:annoyed】谁又把沙漏翻了？我才来多会儿！

【guest:neutral】车歪了。你别动，我扶着。

【stage】镜子里的女孩低着头洗衣服。玛拉往前凑，手里的抹布拧出了水。

【host:neutral】你认识她？

【mara:neutral】……别挡着，我再看一眼。`,
`【stage】玛拉一锤下去，钉子弯了。

【mara:annoyed】又弯了。那混蛋还跟我说是好铁，回去非找他算账。

【guest:neutral】我们从哪儿上船？

【mara:neutral】右边。左边那块板，我都不敢站。会扶木头的过来搭把手，别光看。

【host:neutral】船舱开着呢？

【mara:neutral】嗯。船头还有掉出来的星砂，谁去捡捡？别滚海里了。`
],
quill:[
`【quill:neutral】嘘。隔壁两口子还没吵完。

【host:neutral】您这儿不是图书馆吗？

【quill:neutral】所以我在这儿听，没过去。你们查什么？

【guest:neutral】零号卷宗。

【quill:neutral】能查。桌上有笔，随便写句撒过的谎，这张卡就给你们。“马上到”别写了，我看腻了。`,
`【quill:neutral】你们那本在椅子上，自己拿。

【guest:neutral】这上头怎么连我们吵架都记了？

【quill:neutral】副本嘛。想看就看，想烧，火盆在那儿。别碰原件。

【host:neutral】你胳膊底下也压了一本。谁的？

【quill:neutral】你们自己那本还没看呢，管我的干吗？`,
`【quill:neutral】今天关门，明天也不开。行李都捆好了。

【host:neutral】那我们这本怎么办？

【quill:neutral】拿来。还有没说完的话，就在这儿写，省得跑第二趟。

【guest:neutral】你自己的最后一页也空着。

【quill:neutral】我知道！我这不还没走吗？`
],
pip:[
`【stage】皮普拿馒头砸核桃，核桃没开，桌子倒晃了一下。

【pip:neutral】要不要来一口？免费。

【host:neutral】你刚拿它砸过东西。

【pip:neutral】另一边没砸。哎，你们坐不坐？问路收钱，聊天不收。

【guest:smile】那我们聊聊路。`,
`【pip:neutral】你们陪我去那边，行不行？不远。

【guest:neutral】镜子那儿？你刚不是去过了？

【pip:neutral】我妈妈在里头。她给别的小孩分吃的，没看见我。

【host:neutral】你叫她了吗？

【pip:neutral】……没。你们陪我，我就叫。`,
`【pip:neutral】就这家。人家说她住这儿。

【guest:neutral】那敲门啊，衣领你都理八回了。

【pip:neutral】我知道。你们站后边，别抢着说。

【stage】他的手抬起来，又缩回袖子里。

【pip:neutral】她要是不认得我……你们别笑啊。

【host:neutral】谁笑你。我们就在这儿。`
],
quiet:[
`【guest:neutral】头一杯不要钱？那后面怎么收？

【quiet:neutral】〔石板〕不收钱。会忘掉一些事。

【host:neutral】你这可比收钱贵。忘什么，能挑吗？

【quiet:neutral】〔石板〕不能。

【guest:neutral】杯子先放下，咱俩商量。别又端起来就喝。`,
`【guest:neutral】这桌子晃得我想吐。借块杯垫，垫一下。

【stage】静默者一把按住旧杯垫，另递来一块石板。

【host:neutral】怎么，这块不能碰？

【quiet:neutral】〔石板〕那块薄。

【guest:neutral】我还没量呢，你倒替我量完了。行，用这块。`,
`【stage】静默者坐在石阶上，行李捆好了，茶摊还摆着。

【host:neutral】真要走啊？茶壶不要了？

【stage】他摇头，把旧杯垫往怀里塞了塞。

【guest:neutral】行，不问。我们坐会儿，腿都跑软了。

【stage】他挪出一点地方，抬手像要叫住你们，又放下了。`
]
};
let count=0;
for(const npc of G.npcs)for(const meeting of npc.meetings){
 const node=meeting.nodes.start,key=npc.id+':'+meeting.act;
 originals.openings[key]=node.text;
 const callbacks=node.text.match(/\{CITY:[^}]+\}/g)||[];
 node.text=[...callbacks,openings[npc.id][meeting.act-1]].join('\n\n');count++;
}
G.dialogueScenes={version:2,openings:count,originals};
})(window.GAME_DATA);
