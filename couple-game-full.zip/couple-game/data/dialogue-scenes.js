/* Dialogue-first openings. Previous prose and all branch mechanics are preserved. */
(function(G){
'use strict';
if(G.dialogueScenes)return;
const originals={intro:JSON.parse(JSON.stringify(G.intro)),actIntros:JSON.parse(JSON.stringify(G.actIntros)),openings:{}};
G.intro.text=`【guest:neutral】最后一箱。我数完了。你别再开新的。

【host:neutral】这份收件人是咱俩。

【guest:neutral】催缴的？

【host:neutral】零号档案。退件原因：缺三页。

【guest:annoyed】我连这一份都没见过，哪来的三页。

【stage】夹层掉出一张画着破伞的字条。

【host:neutral】这把伞，你画的？

【guest:neutral】下面的字是你写的。买来那天就坏了，你非说能修。

【host:neutral】先签收，看看里面还有什么。

【guest:neutral】签完真下班。

【stage】最后一笔落下，桌子下面空了。

【host:annoyed】地板呢？

【guest:annoyed】别问了，抓外套！

【stage】你们落在窄桥上。头顶还有东西往下掉。

【holt:neutral】站着的两个，往里挪！

【stage】椅子砸在刚才的位置。

【guest:neutral】您这儿接人不铺个垫子？

【holt:neutral】上回铺了。垫子掉下去比人早。

【host:neutral】怎么回去？

【holt:neutral】赫尔特，守桥的。卷宗给我看一眼。

【holt:neutral】缺三页。外滩钟楼一页，镜城一页，海底原件一页。齐了去海底钟楼结档。

【guest:neutral】能退件吗？就说收件人不在。

【holt:neutral】你俩都站这儿了。

【host:neutral】……那现在先去哪？

【holt:neutral】先帮我捡椅子。夜班澡堂还有空床，晚了只剩搓背板。`;
const actTexts=[
`【stage】远处的钟响了两遍，街口也吵了两遍。

【guest:neutral】那个人刚才是不是已经摔过一次盆？

【holt:neutral】潮声夫人的歌卡住了。每天到这儿，都要再吵一遍。

【host:neutral】所以先关钟？

【holt:neutral】先找门。卖鱼的玛拉知道侧门，奎尔能查卷宗。

【guest:neutral】路上有吃的吗？

【holt:neutral】澡堂后厨。唐掌柜肯管饭，条件是干活。

【host:neutral】我们刚下班。

【guest:neutral】你先别告诉她，等饭盛出来。

【holt:neutral】还有，看见东西自己在动，别上手。尤其那条围裙。`,
`【stage】镜城入口，两道倒影抢先打了招呼。

【host:neutral】往左吧。

【guest:neutral】你先看路牌。

【host:annoyed】刚才这句有回音。

【guest:neutral】不全是回音。我也说了。

【stage】有人从门缝递出奎尔主馆的地址。

【quill:neutral】第二页在镜影手上。它拿着半份记录，专挑你们不想听的放。

【host:neutral】你怎么不出来？

【quill:neutral】刚擦的地。外面全是脚印。

【guest:neutral】我们想借完整记录。

【quill:neutral】带卷宗来。澡堂送饭的也走这条路，别跟着饭盒进错门。`,
`【stage】潮汐石撑开气泡，鞋却陷进了海泥。

【host:annoyed】帮我拽一下。

【guest:neutral】拽人还是拽鞋？

【host:annoyed】最好一起。

【stage】鞋出来了，人坐了回去。

【guest:neutral】先走石阶。那边有灯。

【mara:neutral】左边是我船上，右边通海底钟楼。别踩烂板子。

【host:neutral】最后一页就在钟楼？

【mara:neutral】原件被遗忘之神扣着。它让人拿自己的记忆换省心。

【guest:neutral】我们前两页都找回来了，不能到这儿又送出去。

【mara:neutral】那就把纸拿稳。澡堂的夜班还没散，有人也在等最后一趟船。`
];
G.actIntros=G.actIntros.map((d,i)=>({...d,text:actTexts[i]}));
G.chapters.forEach((d,i)=>{d.text=actTexts[i];});
const openings={
holt:[
`【stage】赫尔特坐下，椅子往左歪了一点。

【holt:neutral】这把没坏，地不平。

【guest:neutral】换边坐呢？

【stage】椅子又往右歪了一点。

【holt:neutral】两边都不平。卷宗拿来，刚才没核签名。

【host:neutral】您不是看过了吗？

【holt:neutral】看封皮。验签是另一项。上回有人递张菜单，我放过去四份烤鱼。

【guest:neutral】所以您现在数我们？

【holt:neutral】单子写了，两个人都要在。别动，我还没数完。`,
`【stage】赫尔特在同一块砖上转了半圈。

【holt:neutral】第七层，水闸。潮涨，开门……

【host:neutral】赫尔特，帽子掉了。

【holt:neutral】帽子。对，我下来拿……拿什么？

【guest:neutral】先坐下，墙边这儿。

【holt:neutral】第七层……我刚才是不是查过门闩？

【stage】他捏不住笔，纸页一直抖。

【host:neutral】别查了。您看着我们，能听见吗？`,
`【stage】闸门前，赫尔特拧松了最后一只螺帽。

【holt:neutral】别站门缝前。一会儿出水。

【guest:neutral】您要开哪道闸？

【holt:neutral】这一道。

【host:neutral】墙上写着，水会过城顶。

【holt:neutral】我看见了。

【guest:neutral】谁让您开的？

【stage】老人翻到本子里一张折角的纸。

【holt:neutral】是我自己的字。城沉了，欠下的名字就不用找了。

【host:neutral】先松手。那句话什么时候写的？`
],
mara:[
`【stage】背包勾住鱼筐，两条鱼落了地。

【mara:annoyed】别退！后边那筐是我的晚饭。

【guest:neutral】我扶着了。另一条呢？

【host:neutral】猫那儿。

【mara:annoyed】它没付钱，拦住。

【host:neutral】刚才其实是——

【mara:neutral】先捡鱼。谁碰的，等鱼回来了再吵。

【guest:neutral】我们是来问钟楼地图的。

【mara:neutral】就在我肘底下。你先别看地图，看你脚边。`,
`【stage】玛拉把鱼车顶在镜铺门口。

【mara:annoyed】我才站一会儿，你换什么沙漏？

【guest:neutral】要我们帮你推车吗？

【mara:neutral】先别。轮子下面有砖。

【stage】镜里的女孩又整理了一次袖口。

【host:neutral】她一直站在水里？

【mara:neutral】从我来就这样。

【guest:neutral】你手里的抹布都攥干了。

【mara:neutral】……放车上吧。别挡住镜子。`,
`【stage】一锤下去，钉子弯了。

【mara:annoyed】说是新货。新弯的吧。

【guest:neutral】我们从哪儿上？

【mara:neutral】右边踏板。左边那块，已经只是长得像板了。

【host:neutral】船舱能进去吗？

【mara:neutral】门开着，纸别弄湿。船头还有几枚星砂，别让它滚进缝里。

【guest:neutral】你自己就补这么大条船？

【mara:neutral】所以别光问。会扶木板就过来。`
],
quill:[
`【stage】奎尔贴墙听了片刻，立刻坐回桌前。

【quill:neutral】小声。隔壁还没说完。

【host:neutral】门上写着禁止喧哗。

【quill:neutral】我没喧哗。我听。

【guest:neutral】零号卷宗，能查吗？

【quill:neutral】能。缺三页，共同签名。先写句说过的谎话，桌上这张卡归你们。

【host:neutral】“快到了”，其实还没出门？

【quill:neutral】那类两个架子都满了。还能写，别拿错别人的。`,
`【guest:neutral】坐哪儿？

【quill:neutral】椅子上。

【host:neutral】椅子上都是书。

【quill:neutral】我知道。你们等一下。

【stage】她抱走三本，露出封面写着“你们”的薄册。

【guest:neutral】我们也出书了？

【quill:neutral】副本。说过的、没说全的，都在里面。

【host:neutral】你胳膊底下那本呢？

【quill:neutral】先看自己的。火盆在边上，别碰其他原件。`,
`【stage】奎尔站在倒扣的箱子上捆行李。

【quill:neutral】今天关门。

【guest:neutral】我们路上出了点事。

【quill:neutral】哪件？

【host:neutral】不是说关门了吗？

【quill:neutral】锁还没扣。讲吧，长话分着讲。

【stage】她把你们的副本和自己的小册并排放好。

【quill:neutral】纸到齐了。要补的话，就在这儿补。

【guest:neutral】你那张离馆申请还空着。

【quill:neutral】……你的眼睛可以先看这边。`
],
pip:[
`【stage】皮普用馒头敲了两下核桃。

【pip:neutral】试试新货结不结实。

【guest:neutral】很结实。

【host:neutral】核桃没开。

【pip:neutral】我没说试核桃。

【stage】他把核桃踢到箱底，翻了翻馒头。

【pip:smile】这边没碰过。吃吗？不收钱。

【guest:neutral】你牌子上不是写问路一枚星砂？

【pip:neutral】吃东西算聊天。坐下，别挡我招牌。`,
`【stage】皮普敲了三下镜框，又拉正衣领。

【pip:neutral】这里的镜子归我检查。

【guest:neutral】查出什么了？

【pip:neutral】……那边有我妈妈。

【host:neutral】那个给孩子分吃的女人？

【pip:neutral】嗯。现实里她不记得我，镜子里倒有别的小孩。

【guest:neutral】要过去吗？

【pip:neutral】你们陪一下。我知道路，不收你们钱。

【host:neutral】这次也算聊天。`,
`【pip:neutral】她住这儿。我已经问过了。

【stage】皮普把两边翘起的衣领塞进外套。

【guest:neutral】要敲门吗？

【pip:neutral】鞋上还有泥。

【host:neutral】擦好了。我们陪你？

【pip:neutral】你们站后面。我先说。

【stage】他的手停在门板前。

【pip:neutral】要是她问我是谁……你们别也跟着问。

【guest:neutral】好。`
],
quiet:[
`【guest:neutral】首杯免费。续杯多少？

【quiet:neutral】〔石板〕不卖茶。

【host:neutral】那这两杯是？

【quiet:neutral】〔石板〕忘一点烦心事。也会忘一点小事。先想清楚。

【guest:neutral】旁边那个人怎么又问自己坐哪儿？

【stage】静默者将石板推近了些。

【host:neutral】明白了。杯子能动吗？

【stage】他翻正旧杯垫，这才松开手。

【guest:neutral】行。喝不喝，我们商量一下。`,
`【stage】茶桌晃了一下。

【guest:neutral】杯垫借我，垫桌脚。

【stage】静默者立刻拦住，另塞来一块新石板。

【host:neutral】旧的舍不得？

【quiet:neutral】〔石板〕这个厚。

【guest:neutral】我还没量呢。

【stage】他把旧杯垫收进袖袋。

【host:neutral】桌上这块写着“不必执着旧物”。

【quiet:neutral】〔石板〕……坐。

【stage】那块写着旧物的石板被翻了面。`,
`【stage】静默者把旧杯垫裹了三层布。

【guest:neutral】茶叶也要包吗？

【stage】他摇头，摸遍口袋找笔。

【host:neutral】脚边。刚才掉的。

【stage】笔递过去，他握着，没写。

【guest:neutral】我们先坐这儿？

【stage】面具后有一点声音，又停了。

【host:neutral】不急。卷宗我先放下。

【stage】他挪开行李，空出半截石阶。`
]
};
let count=0;
for(const npc of G.npcs)for(const meeting of npc.meetings){
 const node=meeting.nodes.start,key=npc.id+':'+meeting.act;
 originals.openings[key]=node.text;
 const callbacks=node.text.match(/\{CITY:[^}]+\}/g)||[];
 node.text=[...callbacks,openings[npc.id][meeting.act-1]].join('\n\n');count++;
}
G.dialogueScenes={version:1,openings:count,originals};
})(window.GAME_DATA);
