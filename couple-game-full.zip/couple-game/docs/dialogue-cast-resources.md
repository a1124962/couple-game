# 对话主角立绘与资源参考

本次为四位主角补独立的对话长立绘，不再放大战斗图集代替。以已有 `heroes-v2.webp` 的四个人物为身份参考，每职业一张 1536×1024 透明图集，三列分别为自然站立、闭眼、抬手说话。绘画由内置图像工具生成，只有 WebP 编码转换；提示词见 `assets/portraits/dialogue-prompts.json`。

| 职业 | 保留的辨识特征 | 资产 |
|---|---|---|
| 切骨者 | 黑发、脸颊旧疤、暗红围巾、佩剑 | `dialogue-blade.webp` |
| 守门人 | 深色长辫、花枝、木门盾、腰灯 | `dialogue-warden.webp` |
| 织声者 | 深青长发、黄铜花簪、米白衬衣、线轴 | `dialogue-weaver.webp` |
| 见隙者 | 淡紫发、圆框眼镜、深紫长披风、牌袋 | `dialogue-seer.webp` |

两位主角聊天时保持固定左右位置；NPC 加入时出现在右侧，左侧保留最近发言的主角。带说话人标签的对白必须将当前说话人带到前景，与姓名牌保持一致。主角职业取自当前存档，不根据连接角色猜测。旧正文同样使用新主角立绘，旧 NPC 表情仍按剧情节点切换。

参考了以下资源的组织和演出方法：

- [OpenGameArt · Animated Portraits](https://opengameart.org/content/animated-portraits)：18 帧的说话、眨眼肖像示例，说明闭眼和说话应使用各自画好的帧。本项目没有导入它的科幻像素人物图。
- [Ren’Py 官方 Transforms 文档](https://www.renpy.org/doc/html/transforms.html)：舞台位置、透明度与动作分别控制，动作按时间与场景事件启动。这里实现为浏览器本地表现层。
- [Kenney 资源使用说明](https://kenney.nl/support)：检索了其可复用角色资源；本次仍沿用本项目人物身份，避免引入不同画风和比例。

四主角有真正的闭眼帧和抬手姿势。八位 NPC 使用已有表情加轻微呼吸、重心摆动与说话点头，未声称为 NPC 新画了眨眼帧或逐帧挥手。具体时长、开关与清理规则见 `dialogue-motion.md`。
