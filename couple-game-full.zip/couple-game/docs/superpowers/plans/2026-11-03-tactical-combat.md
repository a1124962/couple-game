# Tactical Combat Implementation Plan

> **For agentic workers:** Use the existing project and preserve its deployment path. User authorized execution; parallelize independent UI and verification tasks.

**Goal:** Ship playable cooperative grid tactics with one action per player and environmental chains.
**Architecture:** Add deterministic board rules around existing combat/reducer APIs; render with responsive DOM and existing artwork. Keep old active combats compatible.
**Tech Stack:** Plain JavaScript, CSS, Node VM tests, Playwright.
**Spec:** docs/superpowers/specs/2026-11-03-tactical-combat-design.md

## Global Constraints
- Preserve v3 saves, original story, 24 existing WebP assets, offline bundle and GitHub Pages URL.
- One action per player; three primary buttons; automatic resolution; shared visible queue; authoritative host, no UI-only state changes.
- 5x4 board, 44px minimum touch cells at 320px; no new dependencies or paid services.

## Review Focus
- Queued target dies or moves: fail honestly without retarget or negative energy.
- One participant is down or stunned: round must remain completable.
- Late/double commands after round advances: must not run in next round.
- Forecast and enemy intent must match actual threatened cells and effects.
- Preview and replay must not mutate live RNG, rewards, presentation or saves.

### Task 1: Rules
- [x] Write failing Node tests for board initialization and queue/lock invariants.
- [x] Implement tactical-board.js and additional tests for spatial/environment resolution and preview purity.
- [x] Run full Node suites; retain old direct combat functions for legacy tests.
### Task 2: Interface
- [x] Add tactical-ui.js/CSS and route board combat from R.js.
- [x] Add mobile controls, public sequence and effect preview; test main actions at 320/390/768/1440.
### Task 3: Integration
- [x] Wire app input, solo assistant, script loading and font build; add safe training entry if practical.
- [x] Test two-client queue/lock/resolve/save/rejoin, legacy saves and offline/published bundle.
### Task 4: Review and delivery
- [x] Independent code review and fix meaningful findings.
- [ ] Update README, rebuild and save offline/source artifacts, publish existing repository, verify live site.

### Task 5: Grounded narrative
- [x] Replace three duo scenes with asymmetric fish stall, bluff rescue and birthday choices; preserve source content.
- [x] Verify all 12 results, persistent callbacks and private clues.
