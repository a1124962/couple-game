# 场景对白格式

正文仍保存在原有字符串字段里，不新增共享阅读状态。

```text
【stage】锅盖响了两下。

【host:neutral】我还没动它。

【innkeeper:annoyed】那就把手收回来。
```

- `host` / `guest` 使用本局玩家名称；`stage` 只显示简短环境动作。
- 人物：`mara`、`quill`、`holt`、`pip`、`quiet`、`innkeeper`、`porter`、`laundress`。
- 表情：`neutral`、`smile`、`annoyed`。新配角对应三列透明图集。旧人物没有愤怒帧时保持平静；静默者的摘面具帧仍由原揭示节点控制。
- 一页只有一位说话人；短动作可附在下一句前。长句按 Unicode 字符分页，不拆断 emoji。
- 全文和手记显示每句的姓名，不展示原始标记；人物名、正文、动作均经过 HTML 转义。
- 可在序章、幕开场、事件、互动、NPC 会面上添加 `stage:{background:'bathhouse'|'kitchen'|'laundry'|'workshop',cast:['innkeeper']}`。未标场景继续使用原来的三幕背景。
- 阅读页仍为设备本地的 `ui.readPages`，共识、锁定答案与奖励规则保持不变。

验证：`node --test tests/dialogue-stage.test.cjs`；完整素材与场景接入后执行 `node browser-tools/dialogue-stage-test.cjs`（工作区根目录）。后者使用现有 8765/9000 测试服务，不能与其他浏览器脚本同时启动。
