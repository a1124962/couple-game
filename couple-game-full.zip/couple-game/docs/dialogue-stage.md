# 场景对白格式

正文仍保存在原有字符串字段里，不新增共享阅读状态。

```text
【stage】锅盖响了两下。

【host:neutral】我还没动它。

【innkeeper:annoyed】那就把手收回来。
```

- `host` / `guest` 使用本局玩家名称；`stage` 只显示简短环境动作。
- 人物：`mara`、`quill`、`holt`、`pip`、`quiet`、`innkeeper`、`porter`、`laundress`。
- 表情：`neutral`、`smile`、`annoyed`。新配角对应三列透明图集。旧人物没有愤怒帧时保持平静；静默者的摘面具帧仍由原揭示节点控制。
- 一页只有一位说话人；短动作可附在下一句前。长句按 Unicode 字符分页，不拆断 emoji。
- 全文和手记显示每句的姓名，不展示原始标记；人物名、正文、动作均经过 HTML 转义。
- 可在序章、幕开场、事件、互动、NPC 会面上添加 `stage:{background:'bathhouse'|'kitchen'|'laundry'|'workshop',cast:['innkeeper']}`。未标场景继续使用原来的三幕背景。
- 阅读页仍为设备本地的 `ui.readPages`，共识、锁定答案与奖励规则保持不变。
- 双主角互聊时固定 `host` 在左、`guest` 在右，不随本机身份交换。与 NPC 对话时，最近发言的主角留在左边，当前 NPC 在右边；当前说话人即使不在 `stage.cast` 里也会出场。新场景不会继承上一场景的陪场人物。
- 四主角立绘来自 `assets/portraits/dialogue-{blade,warden,weaver,seer}.webp`，每张透明 1536 × 1024 图分三等列：静立、闭眼、轻微手势。各列基线一致。CSS 图层 `.dialogue-hero-art[data-dialogue-atlas]` 用 `--dialogue-frame:0|1|2` 切换；动作模块负责眨眼和手势，不改正文情绪或共享状态。
- 旧的未标记正文也使用新主角立绘；旧 NPC 节点仍保留原本的情绪帧和摘面具条件。

验证：`node --test tests/dialogue-stage.test.cjs`；完整素材与场景接入后执行 `node browser-tools/dialogue-stage-test.cjs`（工作区根目录）。后者使用现有 8765/9000 测试服务，不能与其他浏览器脚本同时启动。
