# 回声与骨 · 视觉与动作改版

目标：保持轻量双人战棋，让角色、场景和决策成为画面中心。最终按用户选择采用暗酒红、炭黑、旧黄铜与羊皮纸，突出中世纪厚重材质。规则、原始长篇文本、房主权威同步和存档格式继续沿用。

## 参考观察

- [Hades II 官方展示](https://www.supergiantgames.com/games/hades-ii/)：借鉴角色肖像的强轮廓与职业识别色，使用自己的原创人物。
- [Darkest Dungeon II 官方媒体](https://www.darkestdungeon.com/darkest-dungeon-2/media/)：借鉴暗部留白、金属边缘、商店和营地中明确的视觉主次。
- [Sea of Stars 官方展示](https://seaofstarsgame.co/)：借鉴人物置于环境里的叙事呈现与动作接触时点。没有加入需要反应速度的额外操作。
- [Into the Breach 官方介绍](https://subsetgames.com/itb.html)：敌方预告、移动范围、机关结果采用可区分的红、青、金视觉语言。

以上均为视觉/交互方向参考，没有导入这些游戏的素材、文案或代码。

- [Baldur’s Gate 3 官方展示](https://baldursgate3.game/)及 [Larian 官方媒体](https://larian.com/press)：参考古典奇幻人物展示、暗底金属边缘与清晰的内容层次。

## 本项目资源

- 新增 `assets/portraits/heroes-v2.webp`：四位原主角的原创近景肖像，按切骨者/织声者/守门人/见隙者排列于 2×2 图集。通过 `heroPortrait()` 使用，不替代战斗姿势图集。
- 原有四职业、28种敌人和120个姿势继续使用。角色姿势、场上实际位置与命中目标由权威事件驱动。
- 移动、推退、油地滑行、碰撞分别记录可序列化事件；事件附当时的棋盘位置。预览只在副本上计算。
- 新界面分为角色素材、全局界面、战棋界面、动作演出、剧情场景五个独立样式文件，入口按序加载。
- 关闭战斗动作或系统要求减少动画时，仍保留伤害数字、台词和明确的最终状态。

## 肖像生成说明

使用内置图像生成工具，以项目现有 blade / weaver / warden / seer 动作图为身份参考。图像随后只做 WebP 编码，未改变绘画内容。生成提示：

> Create a polished production character portrait atlas for the existing original dark-fantasy cooperative RPG 回声与骨. Preserve the four original identities and clothing signatures. One exact 2-by-2 square grid, no gutters, no text, no border, no watermark. Head-to-mid-chest portraits, expressive charismatic faces, painterly anime storybook linework, rich signature colors, warm skin and dramatic rim light, atmospheric dark painted backdrops. Top left: black spiky-haired male swordsman, playful confident smirk, crimson scarf, charcoal coat, sword glint and scarlet embers. Top right: long wavy dark-teal-haired woman weaver, floral brass hair ornaments, cream blouse and teal fabric, warm mischievous smile, luminous cyan thread. Bottom left: broad-shouldered young woman guardian, dark braid and flowers, olive cloak, worn door-shield and warm lantern, kind determined grin, amber gold. Bottom right: pale lilac-haired androgynous male-presenting seer, round brass glasses, violet cloak and starlit cards, amused raised eyebrow, violet magenta. Similar face scale, eye and hairstyle fully inside each cell. Premium JRPG portrait art, original artwork.


## 石材与机关素材生成

均使用内置图像生成工具，后续只做 WebP 编码，无重绘：

- `assets/scenes/basalt.webp`：Seamless square orthographic dark charcoal basalt material, warm brown undertone, subtle pores and polished streaks, hairline cracks and worn scratches, evenly lit upper left, low contrast for UI readability. No objects, frame, tile grid, symbols, letters, vignette or gold veins.
- `assets/scenes/board-props.webp`：Transparent original medieval dark-fantasy prop atlas, equal 2×2 cells, warm upper-left lighting and strong 60px silhouette. Top left weathered oak explosive barrel with riveted iron hoops and glowing fuse; top right open circular dark iron jaw trap with seven silver teeth, bronze hinge and short chain; bottom left three-layer charcoal stone barricade with brass bands; bottom right slick black oil puddle with subtle amber/violet edge. No backdrop, text, grid, character or UI border.

## 简单玩法中的变化

正式旅程的后续战斗轮换漏油小巷、临时仓库和双岔便道。操作始终是出招、推怪、走位。机关台词按职业/怪物/情境轮换，预览只读，实际事件才推进计数。每轮最多两条精彩反馈，必须对应真实机关、接力或扑空事件，不发虚假奖励。
