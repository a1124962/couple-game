/* Contextual banter and a short recap of what actually happened; no reward or rule changes. */
function boardHighlight(a,id,title,text,tone='gold',priority=1){
 const b=a.combat?.board;if(!b)return;
 const list=(b.lastHighlights||[]).filter(item=>item.id!==id);
 list.push({id,title,text,tone,priority});
 b.lastHighlights=list.sort((x,y)=>y.priority-x.priority).slice(0,2);
}
(function(){
 const emit=battleEmit,resolve=boardResolve;
 battleEmit=function(a,event){
  const b=a.combat?.board;if(!b)return emit(a,event);
  let trigger=null;
  if(event.type==='attack'&&[BOARD_ACTIONS.push,BOARD_ACTIONS.pull].includes(event.label))trigger='push';
  else if(event.type==='move'&&event.motion==='slide'){
   trigger='slide';boardHighlight(a,'slide','油地保龄球','滑行多送一格，下一站由机关接待。','gold',1);
  }else if(event.type==='bump'){
   trigger='collision';boardHighlight(a,'collision','墙：这锅我背','碰撞已经结算，谁挡路谁挨撞。','gold',1);
  }else if(event.type==='say'&&event.line==='谁把这玩意放路中间的？！'){
   trigger='trap';boardHighlight(a,'trap','请君踩坑','陷阱触发，敌人本轮晕头转向。','gold',3);
  }else if(event.type==='coop'&&event.line?.startsWith('桶炸了')){
   trigger='barrel';boardHighlight(a,'barrel','这桌，桶掀了','爆炸已经结算；附近自己人也会中招。','gold',4);
  }else if(event.type==='coop'){
   trigger='coop';boardHighlight(a,'coop','漂亮，接上了','两个人打中同一目标，接力生效。','teal',2);
  }else if(event.type==='attack'&&event.enemy&&event.line?.startsWith('人呢？')){
   trigger='dodge';boardHighlight(a,'dodge','对面打了个寂寞','危险格里没留人，这一击扑了个空。','teal',3);
  }
  if(trigger&&typeof boardBanter==='function'){
   event={...event,line:boardBanter(a,trigger,event.actor,event.target||event.targets?.[0])};
   const p=battlePresentation(a),key=boardBanter.key?.(trigger,event.actor);
   if(p&&key)p.counts[key]=(p.counts[key]||0)+1;
  }
  return emit(a,event);
 };
 boardResolve=function(a){
  if(a.phase==='combat'&&a.combat?.board&&!a.combat.result&&!a.combat.board.resolving)a.combat.board.lastHighlights=[];
  return resolve(a);
 };
})();
