/* Contextual banter and a short recap of what actually happened; no reward or rule changes. */
function boardHighlight(a,id,title,text,tone='gold',priority=1){
 const b=a.combat?.board;if(!b)return;
 const list=(b.lastHighlights||[]).filter(item=>item.id!==id);
 list.push({id,title,text,tone,priority});
 b.lastHighlights=list.sort((x,y)=>y.priority-x.priority).slice(0,2);
}
(function(){
 const emit=battleEmit,resolve=boardResolve;
 battleEmit=function(a,event){
  const b=a.combat?.board;if(!b)return emit(a,event);
  let trigger=null;
  if(event.type==='hit'&&event.impact==='friendly-fire'&&event.value>0){
   boardHighlight(a,'friendly-fire','借刀打怪',battleIdentity(a,event.actor).name+'误伤同类 '+event.value+' 点。','gold',5);
  }else if(event.type==='hit'&&event.impact==='relay'&&event.value>0){
   boardHighlight(a,'relay','接力追击','推怪后的接力追击，追加 '+event.value+' 伤害。','teal',5);
  }else if(event.type==='attack'&&[BOARD_ACTIONS.push,BOARD_ACTIONS.pull].includes(event.label))trigger='push';
  else if(event.type==='move'&&event.motion==='slide'){
   trigger='slide';boardHighlight(a,'slide','油地滑行','受推后沿油地多滑了一格。','gold',1);
  }else if(event.type==='bump'){
   trigger='collision';boardHighlight(a,'collision','碰撞','位移被阻挡，已结算碰撞伤害。','gold',1);
  }else if(event.type==='say'&&event.line==='谁把这玩意放路中间的？！'){
   trigger='trap';boardHighlight(a,'trap','陷阱命中','陷阱伤害与眩晕已结算。','gold',3);
  }else if(event.type==='coop'&&event.line?.startsWith('桶炸了')){
   trigger='barrel';boardHighlight(a,'barrel','炸桶引爆','爆炸范围内的单位都会受到伤害。','gold',4);
  }else if(event.type==='coop'){
   trigger='coop';boardHighlight(a,'coop','双人配合','配合效果已结算。','teal',2);
  }else if(event.type==='attack'&&event.enemy&&event.line?.startsWith('人呢？')){
   trigger='dodge';boardHighlight(a,'dodge','躲过攻击','攻击区域内没有目标。','teal',3);
  }
  if(trigger&&typeof boardBanter==='function'){
   event={...event,line:boardBanter(a,trigger,event.actor,event.target||event.targets?.[0])};
   const p=battlePresentation(a),key=boardBanter.key?.(trigger,event.actor);
   if(p&&key)p.counts[key]=(p.counts[key]||0)+1;
  }
  return emit(a,event);
 };
 boardResolve=function(a){
  if(a.phase==='combat'&&a.combat?.board&&!a.combat.result&&!a.combat.board.resolving)a.combat.board.lastHighlights=[];
  return resolve(a);
 };
})();
